<?php

namespace App\Support;

/**
 * Reads a GPX file (export it from Komoot: Tour → ⋯ → Download GPX) and returns
 * distance, ascent/descent, highest/lowest point, a simplified route and an elevation profile.
 */
class Gpx
{
    public static function parse(string $xml): array
    {
        $doc = @simplexml_load_string($xml);
        if (! $doc) {
            throw new \InvalidArgumentException('This is not a valid GPX file.');
        }
        $nodes = $doc->xpath('//*[local-name()="trkpt"]') ?: $doc->xpath('//*[local-name()="rtept"]') ?: [];
        if (count($nodes) < 2) {
            throw new \InvalidArgumentException('The GPX file has no track points.');
        }

        $pts = [];
        foreach ($nodes as $n) {
            $ele = $n->xpath('*[local-name()="ele"]');
            $pts[] = [(float) $n['lat'], (float) $n['lon'], $ele ? (float) $ele[0] : null];
        }

        // cumulative distance
        $dist = [0.0];
        for ($i = 1; $i < count($pts); $i++) {
            $dist[$i] = $dist[$i - 1] + self::haversine($pts[$i - 1][0], $pts[$i - 1][1], $pts[$i][0], $pts[$i][1]);
        }

        // smoothed elevation + ascent/descent with a 3 m threshold (filters GPS noise)
        $eles = array_column($pts, 2);
        $hasEle = count(array_filter($eles, fn ($e) => $e !== null)) > 1;
        $ascent = $descent = 0.0;
        $smooth = [];
        if ($hasEle) {
            $n = count($eles);
            for ($i = 0; $i < $n; $i++) {
                $win = array_filter(array_slice($eles, max(0, $i - 2), 5), fn ($e) => $e !== null);
                $smooth[$i] = $win ? array_sum($win) / count($win) : ($smooth[$i - 1] ?? 0);
            }
            $ref = $smooth[0];
            foreach ($smooth as $e) {
                if ($e - $ref >= 3) {
                    $ascent += $e - $ref;
                    $ref = $e;
                } elseif ($ref - $e >= 3) {
                    $descent += $ref - $e;
                    $ref = $e;
                }
            }
        }

        $total = end($dist);
        $step = max(1, (int) ceil(count($pts) / 400));
        $route = [];
        $profile = [];
        $pStep = max(1, (int) ceil(count($pts) / 200));
        foreach ($pts as $i => $p) {
            $last = $i === count($pts) - 1;
            if ($i % $step === 0 || $last) {
                $route[] = [round($p[0], 5), round($p[1], 5)];
            }
            if ($hasEle && ($i % $pStep === 0 || $last)) {
                $profile[] = [round($dist[$i], 2), (int) round($smooth[$i])];
            }
        }

        return [
            'distance_km' => round($total, 1),
            'ascent_m'    => $hasEle ? (int) round($ascent) : null,
            'descent_m'   => $hasEle ? (int) round($descent) : null,
            'max_alt_m'   => $hasEle ? (int) round(max($smooth)) : null,
            'min_alt_m'   => $hasEle ? (int) round(min($smooth)) : null,
            'route'       => $route,
            'profile'     => $profile,
        ];
    }

    public static function haversine(float $lat1, float $lng1, float $lat2, float $lng2): float
    {
        $r = 6371.0;
        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);
        $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;

        return 2 * $r * asin(min(1, sqrt($a)));
    }
}
