<?php

namespace App\Support;

use League\CommonMark\Environment\Environment;
use League\CommonMark\Extension\CommonMark\CommonMarkCoreExtension;
use League\CommonMark\Extension\ExternalLink\ExternalLinkExtension;
use League\CommonMark\Extension\HeadingPermalink\HeadingPermalinkExtension;
use League\CommonMark\Extension\Table\TableExtension;
use League\CommonMark\MarkdownConverter;

/**
 * Markdown for articles: tables, heading anchors (for the table of contents),
 * and external links that open in a new tab with rel="noopener".
 */
class Markdown
{
    public static function render(?string $text, bool $anchors = false): string
    {
        if (! $text) {
            return '';
        }
        // [[photo: gallery/xxx.webp]] on its own line = a gallery photo or video, shown in the visitor's language
        $media = [];
        $text = preg_replace_callback('/^\[\[(?:photo|video):\s*([^\]|]+?)\s*\]\]\s*$/mi', function ($m) use (&$media) {
            $key = 'MCTMEDIA'.count($media).'X';
            $media[$key] = trim($m[1]);

            return "\n".$key."\n";
        }, $text);
        $config = [
            'html_input' => 'escape',
            'allow_unsafe_links' => false,
            'external_link' => [
                'internal_hosts' => array_filter([parse_url(config('app.url'), PHP_URL_HOST), 'moroccocyclingtours.com', 'www.moroccocyclingtours.com']),
                'open_in_new_window' => true,
                'html_class' => 'ext',
                'nofollow' => '',
                'noopener' => 'external',
                'noreferrer' => '',
            ],
            'heading_permalink' => [
                'html_class' => 'heading-anchor', 'id_prefix' => '', 'fragment_prefix' => '', 'insert' => 'after',
                'symbol' => '#', 'aria_hidden' => true, 'min_heading_level' => 2, 'max_heading_level' => 3, 'title' => '',
            ],
        ];
        $env = new Environment($config);
        $env->addExtension(new CommonMarkCoreExtension());
        $env->addExtension(new TableExtension());
        $env->addExtension(new ExternalLinkExtension());
        if ($anchors) {
            $env->addExtension(new HeadingPermalinkExtension());
        }

        $html = (string) (new MarkdownConverter($env))->convert($text);
        foreach ($media as $key => $path) {
            $html = str_replace("<p>{$key}</p>", self::mediaFigure($path), $html);
        }

        return $html;
    }

    /** HTML of one gallery item (photo or video) for an article; empty when the item no longer exists */
    private static function mediaFigure(string $path): string
    {
        static $cache = [];
        $item = $cache[$path] ??= \App\Models\GalleryImage::where('image', $path)->first();

        return $item ? view('partials.media-figure', ['p' => $item])->render() : '';
    }

    /** Table of contents from the H2 headings of rendered HTML: [[id, text]] */
    public static function toc(string $html): array
    {
        preg_match_all('/<h2>(.*?)<a [^>]*id="([^"]+)"[^>]*>.*?<\/a><\/h2>/s', $html, $m, PREG_SET_ORDER);

        return array_map(fn ($x) => [$x[2], trim(strip_tags($x[1]))], $m);
    }
}
