<?php

namespace App\Support;

/** asset() with a version number taken from the file date, so browsers can cache CSS/JS for a year */
class Asset
{
    public static function v(string $path): string
    {
        static $cache = [];
        $file = public_path($path);

        return asset($path).'?v='.($cache[$path] ??= is_file($file) ? filemtime($file) : '1');
    }
}
