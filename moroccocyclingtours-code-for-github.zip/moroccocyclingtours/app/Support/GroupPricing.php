<?php

namespace App\Support;

use App\Models\Setting;

/**
 * Price per person by group size. Each tour has a base price; every group-size tier
 * either adjusts it by a percentage or shows "price on request". Edited in Admin → Group pricing.
 */
class GroupPricing
{
    public const KEY = 'group_pricing';

    public static function defaults(): array
    {
        return [
            'enabled' => true,
            'rounding' => 1,
            'tiers' => [
                ['min' => 1, 'max' => 2, 'mode' => 'request', 'adjust' => 0],
                ['min' => 3, 'max' => 5, 'mode' => 'price', 'adjust' => 10],
                ['min' => 6, 'max' => 10, 'mode' => 'price', 'adjust' => -5],
                ['min' => 11, 'max' => 20, 'mode' => 'price', 'adjust' => -15],
            ],
        ];
    }

    public static function config(): array
    {
        return array_merge(self::defaults(), (array) Setting::get(self::KEY, []));
    }

    public static function enabled(): bool
    {
        return (bool) self::config()['enabled'];
    }

    public static function tiers(): array
    {
        $tiers = self::config()['tiers'];
        usort($tiers, fn ($a, $b) => $a['min'] <=> $b['min']);

        return $tiers;
    }

    /** Group sizes (from 1 up to the last row) that no row covers: [[from, to], …] */
    public static function gaps(?array $tiers = null): array
    {
        $tiers ??= self::tiers();
        usort($tiers, fn ($a, $b) => $a['min'] <=> $b['min']);
        $gaps = [];
        $next = 1;
        foreach ($tiers as $t) {
            if ($t['min'] > $next) {
                $gaps[] = [$next, $t['min'] - 1];
            }
            $next = max($next, $t['max'] + 1);
        }

        return $gaps;
    }

    public static function gapText(array $gaps): string
    {
        return implode(', ', array_map(fn ($g) => $g[0] === $g[1] ? (string) $g[0] : $g[0].'–'.$g[1], $gaps));
    }

    public static function maxGroup(): int
    {
        return (int) (collect(self::tiers())->max('max') ?? 20);
    }

    public static function tierFor(int $people): ?array
    {
        foreach (self::tiers() as $t) {
            if ($people >= $t['min'] && $people <= $t['max']) {
                return $t;
            }
        }

        return null;
    }

    /** Price per person for a tier, or null when the tier is "on request" */
    public static function tierPrice(float $base, array $tier): ?float
    {
        if ($tier['mode'] === 'request' || $base <= 0) {
            return null;
        }
        $r = max(1, (int) self::config()['rounding']);

        return round($base * (1 + $tier['adjust'] / 100) / $r) * $r;
    }

    /** Price per person for a group size: null = on request (or group larger than the last tier) */
    public static function priceFor(float $base, int $people): ?float
    {
        if (! self::enabled()) {
            return $base > 0 ? $base : null;
        }
        $tier = self::tierFor($people);

        return $tier ? self::tierPrice($base, $tier) : null;
    }

    /** Rows for the price table: every tier with its price per person (null = on request) */
    public static function table(float $base): array
    {
        return array_map(fn ($t) => $t + ['price' => self::tierPrice($base, $t)], self::tiers());
    }

    /**
     * The price table of one tour. Only group sizes the tour can take are shown (its maximum group size),
     * and the last row is cut at that maximum. Empty when pricing is switched off or the tour has no price.
     */
    public static function rows(float $base, ?int $capacity = null): array
    {
        if ($base <= 0 || ! self::enabled()) {
            return [];
        }
        $rows = [];
        foreach (self::table($base) as $r) {
            if ($capacity && $r['min'] > $capacity) {
                continue;
            }
            if ($capacity) {
                $r['max'] = min($r['max'], $capacity);
            }
            $rows[] = $r;
        }

        return $rows;
    }

    /** True when no group size this tour can take has a price (all "on request"), or the tour has no price */
    public static function isOnRequest(float $base, ?int $capacity = null): bool
    {
        if ($base <= 0) {
            return true;
        }

        return self::enabled() && self::pricesIn(self::rows($base, $capacity)) === [];
    }

    /** Lowest price per person this tour can reach (the "from" price) */
    public static function lowestFor(float $base, ?int $capacity = null): ?float
    {
        if ($base <= 0) {
            return null;
        }
        if (! self::enabled()) {
            return $base;
        }
        $p = self::pricesIn(self::rows($base, $capacity));

        return $p ? min($p) : null;
    }

    public static function highestFor(float $base, ?int $capacity = null): ?float
    {
        if ($base <= 0) {
            return null;
        }
        if (! self::enabled()) {
            return $base;
        }
        $p = self::pricesIn(self::rows($base, $capacity));

        return $p ? max($p) : null;
    }

    private static function pricesIn(array $rows): array
    {
        return array_values(array_filter(array_column($rows, 'price'), fn ($p) => $p !== null));
    }

    public static function lowest(float $base): ?float
    {
        return self::lowestFor($base);
    }

    public static function highest(float $base): ?float
    {
        return self::highestFor($base);
    }

    public static function label(array $tier): string
    {
        return $tier['min'] === $tier['max']
            ? trans_choice(':count person|:count people', $tier['min'])
            : __(':min–:max people', ['min' => $tier['min'], 'max' => $tier['max']]);
    }
}
