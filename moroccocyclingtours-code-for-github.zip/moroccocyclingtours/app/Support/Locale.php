<?php

namespace App\Support;

class Locale
{
    /** @return array<string,string> code => native name */
    public static function all(): array
    {
        return config('site.locales', ['en' => 'English']);
    }

    public static function codes(): array
    {
        return array_keys(self::all());
    }

    public static function fallback(): string
    {
        return self::codes()[0];
    }

    /** Languages that get their own translation tab in the admin (all except the base language). */
    public static function translatable(): array
    {
        return array_slice(self::all(), 1, null, true);
    }

    /** Same page in another language: swaps the first URL segment and keeps the query string. */
    public static function switchUrl(string $code): string
    {
        $segments = request()->segments();
        if ($segments && in_array($segments[0], self::codes(), true)) {
            $segments[0] = $code;
        } else {
            array_unshift($segments, $code);
        }
        $qs = request()->getQueryString();

        return url(implode('/', $segments)).($qs ? '?'.$qs : '');
    }
}
