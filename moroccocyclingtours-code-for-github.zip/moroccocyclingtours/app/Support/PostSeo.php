<?php

namespace App\Support;

use App\Models\Post;
use Illuminate\Support\Str;

/** The publishing checklist from the content guide, checked automatically for one language */
class PostSeo
{
    public static function check(Post $post, string $locale = 'en'): array
    {
        $kw = mb_strtolower(trim((string) $post->tr('focus_keyword', $locale)));
        $title = mb_strtolower((string) $post->tr('title', $locale));
        $body = (string) $post->tr('body', $locale);
        $summary = (string) $post->tr('summary', $locale);
        $public = mb_strtolower($post->publicText($body));
        $first = mb_strtolower(trim(strtok($summary ?: $post->publicText($body), "\n") ?: ''));
        preg_match_all('/^#{2,4}\s+(.+)$/m', $body, $h);
        $headings = mb_strtolower(implode(' ', $h[1] ?? []));
        $words = max(1, str_word_count(strip_tags($public)));
        $kwCount = $kw ? substr_count($public.' '.$title, $kw) : 0;
        $density = $kw ? round($kwCount * max(1, str_word_count($kw)) / $words * 100, 1) : 0;
        $metaT = (string) $post->tr('meta_title', $locale);
        $metaD = (string) $post->tr('meta_description', $locale);
        preg_match_all('/\]\((\/[^)]+|https?:\/\/[^)]+)\)/', $body, $links);
        $links = $links[1] ?? [];
        $toPosts = count(array_filter($links, fn ($l) => str_contains($l, '/blog/')));
        $booking = count(array_filter($links, fn ($l) => preg_match('~/(tours|contact|trips|bikes)~', $l)));
        $external = count(array_filter($links, fn ($l) => str_starts_with($l, 'http')));
        $paras = array_filter(preg_split('/\n\s*\n/', $post->publicText($body)), fn ($p) => ! preg_match('/^\s*(#|\||-|\*|\d+\.)/', $p));
        $long = count(array_filter($paras, fn ($p) => preg_match_all('/[.!?](\s|$)/', $p) > 3));
        $slugWords = explode('-', $post->slug ?? '');
        $kwWords = array_filter(explode(' ', Str::slug($kw, ' ')));
        $slugOk = $post->slug && count($slugWords) <= 6 && count(array_intersect($kwWords, $slugWords)) >= min(2, count($kwWords));
        $notes = $post->notes($locale);
        $genericAuthor = ! $post->author || str_contains(mb_strtolower($post->author), 'team');

        return [
            'Keyword & SEO' => [
                ['Focus keyword is set', (bool) $kw, $kw ?: 'Add the search phrase this post answers'],
                ['Keyword in the title', $kw && str_contains($title, $kw), null],
                ['Keyword in the first paragraph / quick answer', $kw && str_contains($first, $kw), null],
                ['Keyword in at least one heading', $kw && str_contains($headings, $kw), null],
                ['Short URL with the keyword', $slugOk, '/blog/'.$post->slug],
                ['Meta title filled, under 60 characters', $metaT !== '' && mb_strlen($metaT) <= 60, mb_strlen($metaT).' characters'],
                ['Meta description filled, under 155 characters', $metaD !== '' && mb_strlen($metaD) <= 155, mb_strlen($metaD).' characters'],
                ['Keyword sounds natural (not repeated too often)', $kw && $density <= 2.5, $density.'% of words'],
                ['Answer in the first 2–3 sentences (quick answer filled)', trim($summary) !== '', null],
            ],
            'Real experience & trust' => [
                ['No guide notes [[…]] left to complete', ! $notes, $notes ? count($notes).' note(s): '.Str::limit($notes[0], 90) : null],
                ['Author name and short bio', ! $genericAuthor && filled($post->author_bio), $genericAuthor ? 'Add the guide who wrote it, e.g. “Written by Rachid, guide since 2005”' : null],
                ['Own cover photo with alt text', $post->cover && filled($post->tr('cover_alt', $locale)), $post->cover ? null : 'Upload one of your own photos'],
                ['Prices, hours and dates checked in the last 12 months', ! $post->update_due, $post->updated_at?->diffForHumans()],
            ],
            'Readability' => [
                ['Paragraphs of 2–3 sentences', $long === 0, $long ? $long.' long paragraph(s)' : null],
                ['A heading every few paragraphs', count($h[1] ?? []) >= max(3, intdiv(count($paras), 4)), count($h[1] ?? []).' headings'],
                ['Ends with an invitation to book (link to tours or contact)', $booking >= 1, $booking.' link(s)'],
            ],
            'Links & images' => [
                ['Links to 2–3 related articles', $toPosts >= 2, $toPosts.' link(s)'],
                ['Outside sources or partner sites linked', $external >= 1, $external.' link(s)'],
                ['FAQ answers filled in', count($post->faqList($locale)) >= 2, count($post->faqList($locale)).' questions'],
            ],
        ];
    }

    public static function score(array $groups): array
    {
        $all = array_merge(...array_values($groups));
        $ok = count(array_filter($all, fn ($i) => $i[1]));

        return [$ok, count($all)];
    }
}
