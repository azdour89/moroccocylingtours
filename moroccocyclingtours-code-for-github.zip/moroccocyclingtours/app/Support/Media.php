<?php

namespace App\Support;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Symfony\Component\Process\ExecutableFinder;
use Symfony\Component\Process\Process;

/**
 * Image optimisation for every upload in the admin.
 *
 * Each photo is resized and saved as AVIF and WebP in 4 widths:
 *   tours/k3x9…-1920x1280_1920.webp   tours/k3x9…-1920x1280_1920.avif
 *   tours/k3x9…-1920x1280_1280.webp   … _800 … _480
 * The stored path is the largest WebP. The file name carries the original size,
 * so pages can set width/height (no layout shift) and build srcset without touching the disk.
 * Pages serve AVIF first (<picture>), WebP as the fallback.
 *
 * Encoders, tried in this order: GD (imagewebp / imageavif), Imagick, then the `avifenc` command-line tool
 * (libavif) for AVIF. Every encoder is tested with a real encode before it is used.
 */
class Media
{
    public const WIDTHS = [1920, 1280, 800, 480];

    private const RASTER = ['image/jpeg', 'image/pjpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif', 'image/bmp', 'image/x-ms-bmp'];

    private const PATTERN = '/^(.*)_(\d+)\.(webp|avif)$/';

    /* ------------------------------------------------------------------ */
    /*  Capabilities                                                       */
    /* ------------------------------------------------------------------ */

    /** Output formats this server can write, in the order they are offered to browsers */
    public static function formats(): array
    {
        static $formats;
        if ($formats !== null) {
            return $formats;
        }
        $wanted = (array) config('site.image_formats', ['avif', 'webp']);
        $formats = [];
        if (in_array('avif', $wanted, true) && self::canEncode('avif')) {
            $formats[] = 'avif';
        }
        if (self::canEncode('webp')) {
            $formats[] = 'webp';   // WebP is always kept as the fallback
        }

        return $formats;
    }

    public static function canEncode(string $format): bool
    {
        static $cache = [];

        return $cache[$format] ??= self::gdCan($format) || self::imagickCan($format) || ($format === 'avif' && self::cliCan());
    }

    /** Human-readable status for the admin dashboard */
    public static function status(): array
    {
        return [
            'webp'    => self::canEncode('webp'),
            'avif'    => self::canEncode('avif'),
            'engine'  => implode(' + ', array_filter([
                self::gdCan('webp') || self::gdCan('avif') ? 'GD' : null,
                self::imagickCan('webp') || self::imagickCan('avif') ? 'Imagick' : null,
                self::cliCan() ? 'avifenc' : null,
            ])) ?: 'none',
            'avif_engine' => self::gdCan('avif') ? 'GD' : (self::imagickCan('avif') ? 'Imagick' : (self::cliCan() ? 'avifenc' : null)),
            'formats' => self::formats(),
        ];
    }

    private static function gdCan(string $format): bool
    {
        $fn = 'image'.$format;
        if (! function_exists($fn) || ! function_exists('imagecreatetruecolor')) {
            return false;
        }
        // Some PHP builds expose imageavif() without a working encoder: test it once.
        try {
            $img = imagecreatetruecolor(8, 8);
            ob_start();
            $ok = $format === 'avif' ? @imageavif($img, null, 50, 10) : @imagewebp($img, null, 50);
            $data = ob_get_clean();
            imagedestroy($img);

            return $ok && strlen((string) $data) > 0;
        } catch (\Throwable) {
            if (ob_get_level()) {
                ob_end_clean();
            }

            return false;
        }
    }

    /** ImageMagick often lists AVIF as read-only, so test a real encode instead of trusting queryFormats() */
    private static function imagickCan(string $format): bool
    {
        static $cache = [];
        if (isset($cache[$format])) {
            return $cache[$format];
        }
        if (! extension_loaded('imagick') || ! class_exists(\Imagick::class) || \Imagick::queryFormats(strtoupper($format)) === []) {
            return $cache[$format] = false;
        }
        try {
            $im = new \Imagick();
            $im->newImage(8, 8, 'white');
            $im->setImageFormat($format);

            return $cache[$format] = strlen($im->getImageBlob()) > 0;
        } catch (\Throwable) {
            return $cache[$format] = false;
        }
    }

    /** `avifenc` from libavif (apt install libavif-bin, brew install libavif, or set SITE_AVIFENC to its path) */
    private static function avifenc(): ?string
    {
        static $bin = false;
        if ($bin === false) {
            $configured = config('site.avifenc_path');
            $bin = $configured && is_file($configured) ? $configured : (new ExecutableFinder())->find('avifenc');
        }

        return $bin ?: null;
    }

    private static function cliCan(): bool
    {
        static $ok;
        if ($ok !== null) {
            return $ok;
        }
        if (! self::avifenc() || ! class_exists(Process::class)) {
            return $ok = false;
        }
        try {
            $p = new Process([self::avifenc(), '--version']);
            $p->setTimeout(10)->run();

            return $ok = $p->isSuccessful();
        } catch (\Throwable) {
            return $ok = false;
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Storing                                                            */
    /* ------------------------------------------------------------------ */

    /** Optimise an uploaded image. Non-raster files (SVG, PDF…) are stored as they are. */
    /** Folders whose photos are shown full-screen get higher quality and up to 2560 px (the home slider) */
    private const HIGH_QUALITY_DIRS = ['slides'];

    private static bool $highQuality = false;

    public static function store(UploadedFile $file, string $dir, ?int $max = null): string
    {
        return self::storeFromPath($file->getRealPath(), (string) $file->getMimeType(), $dir, $max)
            ?? $file->store($dir, 'public');
    }

    /** Optimise an image file on disk; returns the new path or null if it can’t be processed */
    public static function storeFromPath(string $source, string $mime, string $dir, ?int $max = null): ?string
    {
        if (! in_array($mime, self::RASTER, true) || ! self::formats()) {
            return null;
        }
        self::raiseMemory();
        $img = self::load($source, $mime);
        if (! $img) {
            return null;
        }

        self::$highQuality = in_array(trim($dir, '/'), self::HIGH_QUALITY_DIRS, true);
        $max ??= self::$highQuality ? (int) config('site.image_max_width_hq', 2560) : (int) config('site.image_max_width', 1920);
        $w = imagesx($img);
        $h = imagesy($img);
        $main = min($w, $max);
        $mainH = (int) round($h * $main / $w);
        $base = trim($dir, '/').'/'.Str::lower(Str::random(12))."-{$main}x{$mainH}";

        self::writeSizes($img, $base, $main, self::formats());
        imagedestroy($img);
        self::$highQuality = false;

        return "{$base}_{$main}.".(in_array('webp', self::formats(), true) ? 'webp' : 'avif');
    }

    /** Adds the AVIF versions to an image that was optimised before AVIF was available */
    public static function addMissingAvif(string $path): bool
    {
        if (! self::canEncode('avif') || ! preg_match(self::PATTERN, $path, $m) || $m[3] !== 'webp' || self::hasAvif($path)) {
            return false;
        }
        $disk = Storage::disk('public');
        if (! $disk->exists($path)) {
            return false;
        }
        self::raiseMemory();
        $img = self::load($disk->path($path), 'image/webp');
        if (! $img) {
            return false;
        }
        self::writeSizes($img, $m[1], (int) $m[2], ['avif']);
        imagedestroy($img);

        return true;
    }

    private static function writeSizes(\GdImage $img, string $base, int $main, array $formats): void
    {
        $disk = Storage::disk('public');
        $targets = array_merge([$main], array_filter(self::WIDTHS, fn ($x) => $x < $main));
        foreach ($targets as $width) {
            $resized = $width === imagesx($img) ? $img : self::resize($img, $width);
            foreach ($formats as $format) {
                $data = self::encode($resized, $format);
                if ($data !== '') {
                    $disk->put("{$base}_{$width}.{$format}", $data);
                }
            }
            if ($resized !== $img) {
                imagedestroy($resized);
            }
        }
    }

    private static function load(string $path, string $mime): ?\GdImage
    {
        $img = @imagecreatefromstring((string) file_get_contents($path));
        if (! $img && extension_loaded('imagick')) {          // e.g. AVIF input without GD support
            try {
                $im = new \Imagick($path);
                $im->setImageFormat('png');
                $img = @imagecreatefromstring($im->getImageBlob()) ?: null;
            } catch (\Throwable) {
                $img = null;
            }
        }
        if (! $img) {
            return null;
        }
        if (in_array($mime, ['image/jpeg', 'image/pjpeg'], true) && function_exists('exif_read_data')) {
            $o = (int) (@exif_read_data($path)['Orientation'] ?? 1);
            $img = match ($o) { 3 => imagerotate($img, 180, 0), 6 => imagerotate($img, -90, 0), 8 => imagerotate($img, 90, 0), default => $img };
        }
        if (! imageistruecolor($img)) {
            imagepalettetotruecolor($img);
        }
        imagealphablending($img, false);
        imagesavealpha($img, true);

        return $img;
    }

    private static function resize(\GdImage $src, int $width): \GdImage
    {
        $w = imagesx($src);
        $h = imagesy($src);
        $nh = max(1, (int) round($h * $width / $w));
        $dst = imagecreatetruecolor($width, $nh);
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $width, $nh, $w, $h);

        return $dst;
    }

    private static function encode(\GdImage $img, string $format): string
    {
        $q = (int) config("site.image_quality.{$format}", $format === 'avif' ? 52 : 80);
        if (self::$highQuality) {
            $q = (int) config("site.image_quality_hq.{$format}", $format === 'avif' ? 68 : 90);
        }
        if (self::gdCan($format)) {
            ob_start();
            $format === 'avif'
                ? imageavif($img, null, $q, (int) config('site.avif_speed', 6))
                : imagewebp($img, null, $q);

            return (string) ob_get_clean();
        }
        if (self::imagickCan($format)) {
            ob_start();
            imagepng($img);
            $png = (string) ob_get_clean();
            $im = new \Imagick();
            $im->readImageBlob($png);
            $im->setImageFormat($format);
            $im->setImageCompressionQuality($q);
            $im->stripImage();
            $blob = $im->getImageBlob();
            if ($blob !== '') {
                return $blob;
            }
        }
        if ($format === 'avif' && self::cliCan()) {
            $in = tempnam(sys_get_temp_dir(), 'img').'.png';
            $out = tempnam(sys_get_temp_dir(), 'img').'.avif';
            try {
                imagepng($img, $in, 1);
                $p = new Process([self::avifenc(), '-q', (string) $q, '-s', (string) config('site.avif_speed', 6), '-j', 'all', $in, $out]);
                $p->setTimeout(120)->run();

                return $p->isSuccessful() && is_file($out) ? (string) file_get_contents($out) : '';
            } finally {
                @unlink($in);
                @unlink($out);
            }
        }

        return '';
    }

    private static function raiseMemory(): void
    {
        $limit = ini_get('memory_limit');
        if ($limit !== '-1' && (int) $limit < 1024) {
            @ini_set('memory_limit', '1024M');   // large camera photos need room while resizing
        }
        @set_time_limit(120);
    }

    /* ------------------------------------------------------------------ */
    /*  Reading (used by pages)                                            */
    /* ------------------------------------------------------------------ */

    public static function isOptimized(?string $path): bool
    {
        return (bool) ($path && preg_match(self::PATTERN, $path));
    }

    public static function url(?string $path): ?string
    {
        if (! $path) {
            return null;
        }

        return Str::startsWith($path, ['http://', 'https://', '/']) ? $path : Storage::url($path);
    }

    /** srcset for an optimised image; $format = 'avif' or 'webp' (default: the stored format) */
    public static function srcset(?string $path, ?string $format = null): ?string
    {
        if (! $path || ! preg_match(self::PATTERN, $path, $m)) {
            return null;
        }
        $ext = $format ?? $m[3];
        $main = (int) $m[2];
        $sizes = array_merge(array_filter(self::WIDTHS, fn ($x) => $x < $main), [$main]);
        sort($sizes);

        return implode(', ', array_map(fn ($x) => self::url("{$m[1]}_{$x}.{$ext}")." {$x}w", $sizes));
    }

    /** A smaller version (e.g. 800 px for cards); falls back to the original */
    public static function sized(?string $path, int $width, ?string $format = null): ?string
    {
        if ($path && preg_match(self::PATTERN, $path, $m)) {
            $ext = $format ?? $m[3];
            $w = ((int) $m[2] > $width && in_array($width, self::WIDTHS, true)) ? $width : (int) $m[2];

            return self::url("{$m[1]}_{$w}.{$ext}");
        }

        return self::url($path);
    }

    /** Does this optimised image also exist as AVIF? (checked once per request) */
    public static function hasAvif(?string $path): bool
    {
        static $cache = [];
        if (! $path || ! preg_match(self::PATTERN, $path, $m)) {
            return false;
        }
        if ($m[3] === 'avif') {
            return true;
        }

        return $cache[$path] ??= Storage::disk('public')->exists("{$m[1]}_{$m[2]}.avif");
    }

    /** [width, height] of the largest version, read from the file name */
    public static function dimensions(?string $path): ?array
    {
        return $path && preg_match('/-(\d+)x(\d+)_\d+\.(webp|avif)$/', $path, $m) ? [(int) $m[1], (int) $m[2]] : null;
    }

    /** True for photos that are taller than wide (used to crop gallery thumbnails towards the top) */
    public static function isPortrait(?string $path): bool
    {
        $d = self::dimensions($path);

        return $d && $d[1] > $d[0] * 1.1;
    }

    public static function delete(?string $path): void
    {
        if (! $path || Str::startsWith($path, ['http://', 'https://', '/'])) {
            return;
        }
        $disk = Storage::disk('public');
        if (preg_match(self::PATTERN, $path, $m)) {
            foreach (array_unique(array_merge(self::WIDTHS, [(int) $m[2]])) as $w) {
                $disk->delete(["{$m[1]}_{$w}.webp", "{$m[1]}_{$w}.avif"]);
            }
        } else {
            $disk->delete($path);
        }
    }

    /** Largest upload PHP accepts on this server, in KB (the smaller of upload_max_filesize and post_max_size) */
    public static function phpLimitKb(): int
    {
        $kb = function (string $v): int {
            $v = trim($v);
            $n = (float) $v;

            return (int) match (strtolower(substr($v, -1))) { 'g' => $n * 1024 * 1024, 'm' => $n * 1024, 'k' => $n, default => $n / 1024 };
        };
        $limits = array_filter([$kb((string) ini_get('upload_max_filesize')), $kb((string) ini_get('post_max_size'))]);   // 0 = unlimited

        return $limits ? min($limits) : 15360;
    }

    /** Biggest upload we ask for: 15 MB, or less if PHP is set lower */
    public static function maxKb(): int
    {
        return min(15360, self::phpLimitKb());
    }

    /** Message shown when PHP itself rejects an upload (file bigger than php.ini allows) */
    public static function uploadFailedMessage(): string
    {
        return 'The file could not be uploaded because it is larger than this server allows ('.round(self::phpLimitKb() / 1024, 1).' MB). '
            .'Use a smaller photo, or raise upload_max_filesize and post_max_size in php.ini (XAMPP: C:\\xampp\\php\\php.ini) and restart Apache.';
    }

    /** Validation rule for image uploads in the admin */
    public static function rule(int $maxKb = 15360): string
    {
        return 'mimes:jpg,jpeg,png,webp,avif,gif,bmp,svg|max:'.$maxKb;
    }
}
