<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\Category;
use App\Models\HistoricSite;
use App\Support\Gpx;
use App\Models\Tour;
use Illuminate\Http\Request;

class TourController extends Controller
{
    /** Tour finder: filters + list + map (inspired by valais.ch activity finder). */
    public function index(Request $request)
    {
        $filters = $request->only(['activity', 'category', 'style', 'level', 'region', 'duration', 'max_price', 'q', 'sort']);

        $tours = Tour::published()->with('activity')->filter($filters);
        match ($filters['sort'] ?? 'recommended') {
            'price_asc', 'price_desc' => $tours->orderBy('sort_order'),   // sorted below by the "from" price
            'duration'   => $tours->orderBy('duration_hours'),
            default      => $tours->orderByDesc('is_featured')->orderBy('sort_order'),
        };
        $tours = $tours->get();
        // price filter and price sorting use the "from" price shown on the cards (after group-size pricing)
        if (! empty($filters['max_price'])) {
            $tours = $tours->filter(fn (Tour $t) => $t->lowest_price !== null && $t->lowest_price <= (float) $filters['max_price'])->values();
        }
        if (in_array($filters['sort'] ?? '', ['price_asc', 'price_desc'], true)) {
            // tours with a price first (cheapest or dearest first); "on request" tours always last
            $priced = $tours->filter(fn (Tour $t) => $t->lowest_price !== null)
                ->sortBy(fn (Tour $t) => $t->lowest_price, SORT_REGULAR, $filters['sort'] === 'price_desc');
            $tours = $priced->concat($tours->filter(fn (Tour $t) => $t->lowest_price === null))->values();
        }

        $activities = Activity::withCount(['tours' => fn ($q) => $q->where('is_published', true)])
            ->orderBy('sort_order')->get();
        $regions = Tour::published()->distinct()->orderBy('region')->pluck('region');
        $currentActivity = $activities->firstWhere('slug', $filters['activity'] ?? null);
        $currentCategory = isset($filters['category']) ? Category::firstWhere('slug', $filters['category']) : null;
        $categories = Category::orderBy('sort_order')->get();
        $categoryCounts = Tour::published()->selectRaw('category, count(*) as c')->groupBy('category')->pluck('c', 'category');
        $mapTours = $tours->map(fn (Tour $t) => self::mapPoint($t))->values();

        return view('tours.index', compact('tours', 'activities', 'regions', 'filters', 'currentActivity', 'currentCategory', 'categories', 'mapTours', 'categoryCounts'));
    }

    /** Landing page for a trip type: /trips/{category} */
    public function category(Request $request, Category $category)
    {
        $request->merge(['category' => $category->slug]);

        return $this->index($request);
    }

    /** Landing page for a bike type: /bikes/{activity} */
    public function bike(Request $request, Activity $activity)
    {
        $request->merge(['activity' => $activity->slug]);

        return $this->index($request);
    }

    public function show(Tour $tour)
    {
        abort_unless($tour->is_published, 404);
        $tour->load(['activity', 'stages', 'reviews', 'photos',
            'departures' => fn ($q) => $q->where('start_date', '>=', today())->where('status', '!=', 'cancelled')]);

        // historic sites within 25 km of the route
        $points = collect($tour->route ?? [])->merge($tour->stages->flatMap(fn ($s) => $s->route ?? []));
        if ($tour->latitude) {
            $points->push([$tour->latitude, $tour->longitude]);
        }
        $sites = HistoricSite::where('is_published', true)->whereNotNull('latitude')->get()
            ->map(function ($site) use ($points) {
                $site->distance = $points->map(fn ($p) => Gpx::haversine($site->latitude, $site->longitude, $p[0], $p[1]))->min();

                return $site;
            })
            ->filter(fn ($s) => $s->distance !== null && $s->distance <= 25)->sortBy('distance')->values();

        $related = Tour::published()->with('activity')
            ->where('id', '!=', $tour->id)
            ->where(fn ($q) => $q->where('category', $tour->category)
                ->when($tour->activity_id, fn ($w) => $w->orWhere('activity_id', $tour->activity_id)))
            ->orderByRaw('category = ? desc', [$tour->category])
            ->limit(3)->get();

        return view('tours.show', compact('tour', 'related', 'sites'));
    }

    /** Compact data for map markers. */
    public static function mapPoint(Tour $t): array
    {
        return [
            'id'       => $t->id,
            'title'    => $t->tr('title'),
            'subtitle' => $t->tr('subtitle'),
            'url'      => route('tours.show', ['tour' => $t->slug]),
            'lat'      => $t->latitude,
            'lng'      => $t->longitude,
            'color'    => $t->activity->color,
            'activity' => $t->activity_id ? $t->activity->tr('name') : $t->activity->name,
            'level'    => $t->level_label,
            'price'    => $t->on_request ? __('Price on request') : __('from :price', ['price' => $t->price_formatted]),
            'duration' => $t->tr('duration_label'),
            'km'       => $t->distance_km,
            'image'    => \App\Support\Media::sized($t->image, 480),
            'route'    => collect($t->route ?? [])->values()->filter(fn ($p, $i) => $i % 2 === 0)->values(),
            'region'   => $t->region,
        ];
    }
}
