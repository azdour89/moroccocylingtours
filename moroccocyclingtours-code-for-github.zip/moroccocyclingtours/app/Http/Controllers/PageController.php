<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\BikeBrand;
use App\Models\Event;
use App\Models\Faq;
use App\Models\GalleryImage;
use App\Models\HistoricSite;
use App\Models\Page;
use App\Models\Review;
use App\Models\TeamMember;
use App\Models\Tour;

class PageController extends Controller
{
    public function about()
    {
        return view('pages.about', [
            'page' => Page::for('about'),
            'team' => TeamMember::where('is_published', true)->orderBy('sort_order')->get(),
            'brands' => BikeBrand::where('is_published', true)->orderBy('sort_order')->get(),
            'stats' => ['tours' => Tour::published()->count(), 'bikes' => Activity::count(), 'reviews' => Review::where('is_published', true)->count()],
        ]);
    }

    public function faq()
    {
        $order = array_flip(array_keys(Faq::GROUPS));
        $faqs = Faq::where('is_published', true)->orderBy('sort_order')->get()->groupBy('group')
            ->sortBy(fn ($items, $group) => $order[$group] ?? 99);

        return view('pages.faq', ['page' => Page::for('faq'), 'faqs' => $faqs]);
    }

    public function events()
    {
        return view('pages.events', [
            'page' => Page::for('events'),
            'upcoming' => Event::where('is_published', true)->where(fn ($q) => $q->where('starts_at', '>=', today())->orWhere('ends_at', '>=', today()))->orderBy('starts_at')->get(),
            'past' => Event::where('is_published', true)->where('starts_at', '<', today())->where(fn ($q) => $q->whereNull('ends_at')->orWhere('ends_at', '<', today()))->orderByDesc('starts_at')->limit(6)->get(),
        ]);
    }

    public function testimonials()
    {
        $reviews = Review::with('tour')->where('is_published', true)->latest('reviewed_at')->paginate(12);
        $rating = Review::where('is_published', true)->selectRaw('avg(rating) as avg, count(*) as n')->first();

        return view('pages.testimonials', ['page' => Page::for('testimonials'), 'reviews' => $reviews, 'rating' => $rating]);
    }

    public function gallery()
    {
        $photos = GalleryImage::with('activity')->where('is_published', true)->orderBy('sort_order')->get();
        $activities = $photos->pluck('activity')->filter()->unique('id')->sortBy('sort_order')->values();

        return view('pages.gallery', ['page' => Page::for('gallery'), 'photos' => $photos, 'activities' => $activities,
            'albums' => $photos->pluck('album')->filter()->unique()->values()]);
    }

    public function historicSites()
    {
        $sites = HistoricSite::where('is_published', true)->orderBy('sort_order')->get();

        return view('pages.historic-sites', ['page' => Page::for('historic-sites'), 'sites' => $sites]);
    }

    public function bikes()
    {
        $activities = Activity::withCount(['tours' => fn ($q) => $q->where('is_published', true)])->orderBy('sort_order')->get();

        return view('pages.bikes', ['page' => Page::for('bikes'), 'activities' => $activities,
            'brands' => BikeBrand::where('is_published', true)->orderBy('sort_order')->get()]);
    }

    public function contact()
    {
        $bike = request('bike') ? \App\Models\RentalBike::with('brand')->where('slug', request('bike'))->first() : null;
        $prefill = $bike ? __('I would like to rent the :bike. Dates: … Rider height: … Number of bikes: …', ['bike' => $bike->full_name]) : null;

        return view('pages.contact', ['page' => Page::for('contact'), 'prefill' => $prefill, 'tours' => Tour::published()->orderBy('title')->get(['id', 'title', 'translations'])]);
    }
}
