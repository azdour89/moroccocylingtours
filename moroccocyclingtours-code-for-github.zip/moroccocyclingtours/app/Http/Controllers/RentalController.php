<?php

namespace App\Http\Controllers;

use App\Models\RentalBike;
use App\Models\RentalItem;

/** Public "Bike rental" page: the fleet with full specifications, plus equipment that can be rented. */
class RentalController extends Controller
{
    public function index()
    {
        $bikes = RentalBike::live()->with(['brand', 'activity'])->get();
        $types = $bikes->pluck('activity')->filter()->unique('id')->sortBy('sort_order')->values();
        $items = RentalItem::live()->get()->groupBy('category');

        return view('rental.index', compact('bikes', 'types', 'items'));
    }
}
