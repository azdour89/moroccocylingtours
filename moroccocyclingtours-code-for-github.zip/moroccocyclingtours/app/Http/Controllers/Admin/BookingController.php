<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class BookingController extends Controller
{
    public function index(Request $request)
    {
        $bookings = Booking::with('tour.activity')
            ->when($request->status, fn ($q, $v) => $q->where('status', $v))
            ->when($request->q, fn ($q, $v) => $q->where(fn ($w) => $w
                ->where('name', 'like', "%{$v}%")
                ->orWhere('email', 'like', "%{$v}%")
                ->orWhere('reference', 'like', "%{$v}%")
                ->orWhere('tour_title', 'like', "%{$v}%")))
            ->when($request->when === 'upcoming', fn ($q) => $q->whereDate('tour_date', '>=', today())->orderBy('tour_date'))
            ->when($request->when === 'past', fn ($q) => $q->whereDate('tour_date', '<', today())->orderByDesc('tour_date'))
            ->latest()
            ->paginate(25)->withQueryString();

        $counts = Booking::selectRaw('status, count(*) as c')->groupBy('status')->pluck('c', 'status');

        return view('admin.bookings.index', compact('bookings', 'counts'));
    }

    public function show(Booking $booking)
    {
        $booking->load('tour.activity');

        return view('admin.bookings.show', compact('booking'));
    }

    public function update(Request $request, Booking $booking)
    {
        $booking->update($request->validate([
            'status'       => ['required', Rule::in(array_keys(Booking::STATUSES))],
            'tour_date'    => 'required|date',
            'participants' => 'required|integer|min:1|max:200',
            'total_price'  => 'required|numeric|min:0',
            'admin_notes'  => 'nullable|string|max:5000',
        ]));

        return back()->with('status', 'Booking '.$booking->reference.' saved.');
    }

    public function destroy(Booking $booking)
    {
        $booking->delete();

        return redirect()->route('admin.bookings.index')->with('status', 'Booking deleted.');
    }
}
