<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Support\Locale;
use App\Support\Media;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class ActivityController extends Controller
{
    public function index()
    {
        $activities = Activity::withCount(['tours', 'bookings'])->orderBy('sort_order')->get();

        return view('admin.activities.index', compact('activities'));
    }

    public function create()
    {
        return view('admin.activities.form', ['activity' => new Activity(['icon' => 'road', 'color' => '#1B4F8C'])]);
    }

    public function store(Request $request)
    {
        $activity = Activity::create($this->validated($request));
        $this->image($request, $activity);

        return redirect()->route('admin.activities.index')->with('status', 'Bike type added.');
    }

    public function edit(Activity $activity)
    {
        return view('admin.activities.form', compact('activity'));
    }

    public function update(Request $request, Activity $activity)
    {
        $activity->update($this->validated($request, $activity));
        $this->image($request, $activity);

        return redirect()->route('admin.activities.index')->with('status', 'Bike type saved.');
    }

    public function destroy(Activity $activity)
    {
        if ($activity->tours()->exists()) {
            return back()->with('error', 'Move or delete the tours using “'.$activity->name.'” before deleting it.');
        }
        $activity->delete();

        return redirect()->route('admin.activities.index')->with('status', 'Bike type deleted.');
    }

    private function validated(Request $request, ?Activity $activity = null): array
    {
        $data = $request->validate([
            'name'        => 'required|string|max:60',
            'slug'        => ['nullable', 'alpha_dash', 'max:80', Rule::unique('activities', 'slug')->ignore($activity?->id)],
            'icon'        => ['required', Rule::in(array_keys(Activity::ICONS))],
            'color'       => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'description' => 'nullable|string|max:500',
            'sort_order'  => 'nullable|integer',
            'image'       => 'nullable|'.Media::rule(),
            'translations'               => 'nullable|array',
            'translations.*.name'        => 'nullable|string|max:60',
            'translations.*.description' => 'nullable|string|max:500',
        ], ['image.uploaded' => Media::uploadFailedMessage()]);
        $data['translations'] = collect(Locale::translatable())
            ->mapWithKeys(fn ($n, $code) => [$code => array_filter(
                \Illuminate\Support\Arr::only((array) $request->input("translations.$code", []), Activity::TRANSLATABLE),
                'filled'
            )])
            ->filter()->all();
        unset($data['image']);
        $data['slug'] = $data['slug'] ?: Str::slug($data['name']);
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);

        return $data;
    }

    private function image(Request $request, Activity $activity): void
    {
        if ($request->hasFile('image')) {
            Media::delete($activity->image);
            $activity->update(['image' => Media::store($request->file('image'), 'bike-types')]);
        }
    }
}
