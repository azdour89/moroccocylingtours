<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\RouteStage;
use App\Models\Tour;
use App\Support\Gpx;
use App\Support\Locale;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

/** Route details per riding day: Komoot preview, GPX import, surfaces, POIs, elevation profile */
class StageController extends Controller
{
    public function create(Tour $tour)
    {
        $stage = new RouteStage(['day' => ($tour->stages()->max('day') ?? 0) + 1]);

        return view('admin.stages.form', compact('tour', 'stage'));
    }

    public function store(Request $request, Tour $tour)
    {
        $stage = new RouteStage(['tour_id' => $tour->id]);
        $this->save($request, $stage);

        return redirect()->route('admin.tours.stages.edit', [$tour, $stage])->with('status', 'Route stage created.');
    }

    public function edit(Tour $tour, RouteStage $stage)
    {
        abort_unless($stage->tour_id === $tour->id, 404);

        return view('admin.stages.form', compact('tour', 'stage'));
    }

    public function update(Request $request, Tour $tour, RouteStage $stage)
    {
        abort_unless($stage->tour_id === $tour->id, 404);
        $this->save($request, $stage);

        return redirect()->route('admin.tours.stages.edit', [$tour, $stage])->with('status', 'Route stage saved.');
    }

    public function destroy(Tour $tour, RouteStage $stage)
    {
        if ($stage->gpx_file) {
            Storage::disk('public')->delete($stage->gpx_file);
        }
        $stage->delete();

        return redirect()->route('admin.tours.edit', $tour)->with('status', 'Route stage deleted.');
    }

    private function save(Request $request, RouteStage $stage): void
    {
        $v = $request->validate([
            'day' => 'required|integer|min:1|max:60',
            'title' => 'required|string|max:200',
            'description' => 'nullable|string|max:3000',
            'komoot_url' => 'nullable|string|max:500',
            'gpx' => 'nullable|file|max:15360',
            'distance_km' => 'nullable|numeric|min:0',
            'ascent_m' => 'nullable|integer|min:0',
            'descent_m' => 'nullable|integer|min:0',
            'max_alt_m' => 'nullable|integer|min:0',
            'min_alt_m' => 'nullable|integer|min:0',
            'duration_label' => 'nullable|string|max:60',
            'surfaces_text' => 'nullable|string',
            'pois_text' => 'nullable|string',
            'profile_text' => 'nullable|string',
            'route_json' => 'nullable|json',
            'translations' => 'nullable|array',
        ]);

        $stage->fill(collect($v)->only(['day', 'title', 'description', 'komoot_url', 'distance_km', 'ascent_m', 'descent_m', 'max_alt_m', 'min_alt_m', 'duration_label'])->all());
        $stage->gpx_public = $request->boolean('gpx_public');
        $stage->surfaces = RouteStage::parseSurfaces($v['surfaces_text'] ?? '');
        $stage->pois = RouteStage::parsePois($v['pois_text'] ?? '');
        $route = json_decode($v['route_json'] ?? '[]', true) ?: [];
        $stage->route = $route;
        $profile = RouteStage::parseProfile($v['profile_text'] ?? '');
        if ($profile !== ($stage->profile ?? [])) {
            $stage->profile = $profile;
            $stage->profile_approximate = (bool) $profile;
        }

        if ($request->hasFile('gpx')) {
            try {
                $g = Gpx::parse((string) file_get_contents($request->file('gpx')->getRealPath()));
            } catch (\InvalidArgumentException $e) {
                back()->withErrors(['gpx' => $e->getMessage()])->withInput()->throwResponse();
            }
            if ($stage->gpx_file) {
                Storage::disk('public')->delete($stage->gpx_file);
            }
            $stage->gpx_file = $request->file('gpx')->storeAs('gpx', 'stage-'.uniqid().'.gpx', 'public');
            $stage->fill(array_filter($g, fn ($x) => $x !== null && $x !== []));
            $stage->profile_approximate = false;
        }
        if ($request->boolean('remove_gpx') && $stage->gpx_file) {
            Storage::disk('public')->delete($stage->gpx_file);
            $stage->gpx_file = null;
        }

        $tr = [];
        foreach (array_keys(Locale::translatable()) as $code) {
            $row = array_filter(array_intersect_key((array) $request->input("translations.{$code}", []), array_flip(['title', 'description'])), 'filled');
            if ($row) {
                $tr[$code] = $row;
            }
        }
        $stage->translations = $tr;
        $stage->save();
    }
}
