<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Models\Tour;
use App\Support\GroupPricing;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

/** Admin → Group pricing: price adjustments by group size, applied to every tour */
class PricingController extends Controller
{
    public function edit()
    {
        return view('admin.pricing', [
            'config' => GroupPricing::config(),
            'tours' => Tour::where('price', '>', 0)->orderBy('title')->get(['id', 'title', 'price']),
            'gaps' => GroupPricing::gaps(),
        ]);
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'enabled' => 'nullable|boolean',
            'rounding' => 'required|in:1,5,10',
            'tiers' => 'required|array|min:1|max:12',
            'tiers.*.min' => 'required|integer|min:1|max:500',
            'tiers.*.max' => 'required|integer|min:1|max:500',
            'tiers.*.mode' => 'required|in:price,request',
            'tiers.*.adjust' => 'nullable|numeric|min:-90|max:300',
        ]);

        $tiers = collect($data['tiers'])->map(fn ($t) => [
            'min' => (int) $t['min'], 'max' => (int) $t['max'], 'mode' => $t['mode'], 'adjust' => round((float) ($t['adjust'] ?? 0), 1),
        ])->sortBy('min')->values();

        // each row must be valid and must not overlap the next one
        foreach ($tiers as $i => $t) {
            if ($t['min'] > $t['max']) {
                throw ValidationException::withMessages(["tiers.$i.max" => "Row ".($i + 1).": “to” must be at least “from”."]);
            }
            if ($i > 0 && $t['min'] <= $tiers[$i - 1]['max']) {
                throw ValidationException::withMessages(["tiers.$i.min" => "Row ".($i + 1)." overlaps the row before it ({$tiers[$i - 1]['min']}–{$tiers[$i - 1]['max']} people)."]);
            }
        }

        Setting::put(GroupPricing::KEY, [
            'enabled' => $request->boolean('enabled'),
            'rounding' => (int) $data['rounding'],
            'tiers' => $tiers->all(),
        ]);

        $gaps = GroupPricing::gaps($tiers->all());

        return redirect()->route('admin.pricing')->with('status', 'Group pricing saved. All tour pages now use the new prices.'
            .($gaps ? ' Note: no row covers '.GroupPricing::gapText($gaps).' people, so those groups see “price on request”.' : ''));
    }
}
