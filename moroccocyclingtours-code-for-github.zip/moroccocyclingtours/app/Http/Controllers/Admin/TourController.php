<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\GalleryImage;
use App\Models\RentalItem;
use App\Models\Tour;
use App\Support\Locale;
use App\Support\Media;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class TourController extends Controller
{
    public function index(Request $request)
    {
        $tours = Tour::with('activity')->withCount('bookings')
            ->when($request->q, fn ($q, $v) => $q->where('title', 'like', "%{$v}%"))
            ->when($request->activity, fn ($q, $v) => $q->where('activity_id', $v))
            ->when($request->category, fn ($q, $v) => $q->where('category', $v))
            ->when($request->status === 'published', fn ($q) => $q->where('is_published', true))
            ->when($request->status === 'draft', fn ($q) => $q->where('is_published', false))
            ->orderBy('sort_order')->orderByDesc('updated_at')
            ->paginate(20)->withQueryString();

        $activities = Activity::orderBy('sort_order')->get();

        return view('admin.tours.index', compact('tours', 'activities'));
    }

    public function create()
    {
        return view('admin.tours.form', [
            'tour'       => new Tour(['is_published' => true, 'level' => 'moderate', 'capacity' => 8, 'min_age' => 12, 'duration_hours' => 4]),
            'activities' => Activity::orderBy('sort_order')->get(),
        ] + $this->pickLists());
    }

    public function store(Request $request)
    {
        $tour = Tour::create($this->payload($request));
        $this->handleMedia($request, $tour);
        $this->syncPicks($request, $tour);

        return redirect()->route('admin.tours.edit', $tour)->with('status', 'Tour created.');
    }

    public function edit(Tour $tour)
    {
        return view('admin.tours.form', [
            'tour'       => $tour,
            'activities' => Activity::orderBy('sort_order')->get(),
        ] + $this->pickLists());
    }

    public function update(Request $request, Tour $tour)
    {
        $tour->update($this->payload($request, $tour));
        $this->handleMedia($request, $tour);
        $this->syncPicks($request, $tour);

        return redirect()->route('admin.tours.edit', $tour)->with('status', 'Tour saved.');
    }

    public function toggle(Tour $tour)
    {
        $tour->update(['is_published' => ! $tour->is_published]);

        return back()->with('status', $tour->is_published ? 'Tour published.' : 'Tour moved to drafts.');
    }

    public function destroy(Tour $tour)
    {
        foreach (array_merge([$tour->image], $tour->gallery ?? []) as $path) {
            $this->deleteFile($path);
        }
        $tour->delete();

        return redirect()->route('admin.tours.index')->with('status', 'Tour deleted.');
    }

    /** Gallery photos and rental items the form lets you tick */
    private function pickLists(): array
    {
        return [
            'galleryPhotos' => GalleryImage::with('activity')->orderBy('sort_order')->get(),
            'rentalItems'   => RentalItem::orderBy('sort_order')->orderBy('name')->get(),
        ];
    }

    /** Save the ticked photos and equipment (only when the panel was on the page) */
    private function syncPicks(Request $request, Tour $tour): void
    {
        if ($request->has('picks_present')) {
            $tour->photosAll()->sync(array_map('intval', (array) $request->input('photos', [])));
            $tour->rentalItems()->sync(array_map('intval', (array) $request->input('rental_items', [])));
        }
    }

    /* ------------------------------------------------------------------ */

    private function payload(Request $request, ?Tour $tour = null): array
    {
        $v = $request->validate([
            'title'          => 'required|string|max:160',
            'subtitle'       => 'nullable|string|max:200',
            'translations.*.subtitle' => 'nullable|string|max:200',
            'slug'           => ['nullable', 'string', 'max:180', 'alpha_dash', Rule::unique('tours', 'slug')->ignore($tour?->id)],
            'activity_id'    => 'nullable|exists:activities,id',
            'category'       => ['required', Rule::exists('categories', 'slug')],
            'level'          => ['required', Rule::in(array_keys(Tour::LEVELS))],
            'region'         => 'required|string|max:120',
            'start_point'    => 'nullable|string|max:160',
            'excerpt'        => 'required|string|max:300',
            'description'    => 'nullable|string',
            'price'          => 'required|numeric|min:0',
            'duration_label' => 'required|string|max:60',
            'duration_hours' => 'required|numeric|min:0.5|max:400',
            'distance_km'    => 'nullable|numeric|min:0',
            'elevation_m'    => 'nullable|integer|min:0',
            'max_altitude_m' => 'nullable|integer|min:0',
            'terrain'        => 'nullable|string|max:120',
            'capacity'       => 'nullable|integer|min:1|max:200',
            'min_age'        => 'nullable|integer|min:0|max:99',
            'season'         => 'nullable|string|max:120',
            'latitude'       => 'nullable|numeric|between:-90,90',
            'longitude'      => 'nullable|numeric|between:-180,180',
            'route_json'     => 'nullable|json',
            'sort_order'     => 'nullable|integer',
            'image'          => 'nullable|'.Media::rule(),
            'gallery.*'      => 'nullable|'.Media::rule(),
            'remove_gallery' => 'nullable|array',
            'translations'   => 'nullable|array',
            'translations.*.title'   => 'nullable|string|max:160',
            'translations.*.excerpt' => 'nullable|string|max:300',
        ], ['image.uploaded' => Media::uploadFailedMessage(), 'gallery.*.uploaded' => Media::uploadFailedMessage()]);

        $lines = fn (string $key) => array_values(array_filter(
            array_map('trim', preg_split('/\R/', (string) $request->input($key)))
        ));

        $route = json_decode($request->input('route_json') ?: '[]', true) ?: [];
        $route = array_values(array_filter($route, fn ($p) => is_array($p) && count($p) === 2));

        return array_merge(['translations' => $this->translations($request)], Arr::only($v, [
            'title', 'subtitle', 'activity_id', 'category', 'level', 'region', 'start_point', 'excerpt', 'description', 'price',
            'duration_label', 'duration_hours', 'distance_km', 'elevation_m', 'max_altitude_m', 'terrain',
            'capacity', 'min_age', 'season', 'latitude', 'longitude',
        ]), [
            'slug'          => ($v['slug'] ?? null) ?: Tour::uniqueSlug($v['title'], $tour?->id),
            'route'         => $route,
            'highlights'    => $lines('highlights_text'),
            'included'      => $lines('included_text'),
            'not_included'  => $lines('not_included_text'),
            'what_to_bring' => $lines('what_to_bring_text'),
            'itinerary'     => array_map([self::class, 'parseItineraryLine'], $lines('itinerary_text')),
            'is_published'  => $request->boolean('is_published'),
            'is_featured'   => $request->boolean('is_featured'),
            'sort_order'    => (int) ($v['sort_order'] ?? 0),
        ]);
    }

    /** translations[fr][title], translations[fr][highlights_text] … → JSON column */
    private function translations(Request $request): array
    {
        $out = [];
        foreach (array_keys(Locale::translatable()) as $code) {
            $in = (array) $request->input("translations.$code", []);
            $split = fn ($text) => array_values(array_filter(array_map('trim', preg_split('/\R/', (string) $text))));
            $row = [];
            foreach (Tour::TRANSLATABLE_TEXT as $f) {
                if (filled($in[$f] ?? null)) {
                    $row[$f] = trim($in[$f]);
                }
            }
            foreach (Tour::TRANSLATABLE_LISTS as $f) {
                if ($items = $split($in[$f.'_text'] ?? '')) {
                    $row[$f] = $items;
                }
            }
            if ($lines = $split($in['itinerary_text'] ?? '')) {
                $row['itinerary'] = array_map([self::class, 'parseItineraryLine'], $lines);
            }
            if ($row) {
                $out[$code] = $row;
            }
        }

        return $out;
    }

    /** "09:00 | text" or "Day 2 | Asni – Ouirgane | text" */
    public static function parseItineraryLine(string $line): array
    {
        $parts = array_map('trim', explode('|', $line, 3));

        return match (count($parts)) {
            3       => ['time' => $parts[0], 'title' => $parts[1], 'text' => $parts[2]],
            2       => ['time' => $parts[0], 'text' => $parts[1]],
            default => ['time' => null, 'text' => $parts[0]],
        };
    }

    /** Back to the one-line-per-item admin format */
    public static function itineraryToText(?array $items): string
    {
        return implode("\n", array_map(fn ($s) => implode(' | ', array_filter([
            $s['time'] ?? null, $s['title'] ?? null, $s['text'] ?? '',
        ], 'filled')), $items ?? []));
    }

    private function handleMedia(Request $request, Tour $tour): void
    {
        if ($request->hasFile('image')) {
            Media::delete($tour->image);
            $tour->image = Media::store($request->file('image'), 'tours');
        }

        $gallery = $tour->gallery ?? [];
        $remove = (array) $request->input('remove_gallery', []);
        foreach ($remove as $path) {
            Media::delete($path);
        }
        $gallery = array_values(array_diff($gallery, $remove));

        foreach ((array) $request->file('gallery', []) as $file) {
            $gallery[] = Media::store($file, 'tours/gallery');
        }
        $tour->gallery = $gallery;
        $tour->save();
    }

    private function deleteFile(?string $path): void
    {
        Media::delete($path);
    }
}
