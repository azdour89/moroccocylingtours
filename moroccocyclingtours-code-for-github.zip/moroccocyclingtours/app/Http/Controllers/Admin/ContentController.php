<?php

namespace App\Http\Controllers\Admin;

use App\Admin\Resources;
use App\Http\Controllers\Controller;
use App\Support\Locale;
use App\Support\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/** One controller for every content section defined in App\Admin\Resources */
class ContentController extends Controller
{
    private function resource(string $key): array
    {
        $r = Resources::get($key);
        abort_unless($r, 404);

        return $r + ['key' => $key];
    }

    public function index(Request $request, string $resource)
    {
        $r = $this->resource($resource);
        $query = $r['model']::query();
        if (($s = $request->q) && ($col = $r['search'] ?? null)) {
            $query->where($col, 'like', "%{$s}%");
        }
        foreach ($r['filters'] ?? [] as $f) {
            if ($request->filled($f)) {
                $query->where($f, $request->input($f));
            }
        }
        [$col, $dir] = $r['order'] ?? ['id', 'desc'];
        $items = $query->orderBy($col, $dir)->orderByDesc('id')->paginate(25)->withQueryString();

        return view('admin.content.index', compact('r', 'items'));
    }

    public function create(string $resource)
    {
        $r = $this->resource($resource);
        abort_if(($r['create'] ?? true) === false, 404);
        $item = new $r['model'];
        foreach ($r['fields'] as $name => $f) {
            if (array_key_exists('default', $f)) {
                $item->{$name} = $f['default'];
            }
        }

        return view('admin.content.form', compact('r', 'item'));
    }

    public function store(Request $request, string $resource)
    {
        $r = $this->resource($resource);
        $item = new $r['model'];
        $this->save($request, $r, $item);

        return redirect()->route('admin.content.edit', [$resource, $item->id])->with('status', ucfirst($r['singular']).' created.');
    }

    public function edit(string $resource, int $id)
    {
        $r = $this->resource($resource);
        $item = $r['model']::findOrFail($id);

        return view('admin.content.form', compact('r', 'item'));
    }

    public function update(Request $request, string $resource, int $id)
    {
        $r = $this->resource($resource);
        $item = $r['model']::findOrFail($id);
        $this->save($request, $r, $item);

        return redirect()->route('admin.content.edit', [$resource, $item->id])->with('status', ucfirst($r['singular']).' saved.');
    }

    public function destroy(string $resource, int $id)
    {
        $r = $this->resource($resource);
        $item = $r['model']::findOrFail($id);
        foreach ($r['fields'] as $name => $f) {
            if (in_array($f['type'], ['image', 'file'], true)) {
                Media::delete($item->{$name});
            }
        }
        $item->delete();

        return redirect()->route('admin.content.index', $resource)->with('status', ucfirst($r['singular']).' deleted.');
    }

    private function save(Request $request, array $r, Model $item): void
    {
        $rules = [];
        foreach ($r['fields'] as $name => $f) {
            if ($f['readonly'] ?? false) {
                continue;
            }
            $rules[$name] = match ($f['type']) {
                'image' => array_filter(['nullable', Media::rule(), ($f['rules'] ?? '') === 'required_without:id' && ! $item->exists ? 'required' : null]),
                'file' => 'nullable|file|'.(isset($f['mimes']) ? 'mimes:'.$f['mimes'].'|' : '').'max:'.($f['max_kb'] ?? 30720),
                'checkbox' => 'nullable',
                'slug' => ['nullable', 'alpha_dash', 'max:180'],
                default => $f['rules'] ?? 'nullable',
            };
            if ($f['tr'] ?? false) {
                $rules["translations.*.{$name}"] = 'nullable|string|max:'.($f['type'] === 'markdown' ? 60000 : 3000);
            }
            if ($name === 'slug' && $f['type'] === 'select' && $r['key'] === 'pages') {
                $rules[$name] = ['required', 'string', \Illuminate\Validation\Rule::unique('pages', 'slug')->ignore($item->id)];
            }
        }
        $messages = [];
        foreach ($r['fields'] as $name => $f) {
            if (in_array($f['type'], ['image', 'file'], true)) {
                $messages["{$name}.uploaded"] = Media::uploadFailedMessage();
            }
        }
        $data = $request->validate($rules, $messages);

        // A photo that the database requires (hero slides, gallery) can be replaced but never removed
        foreach ($r['fields'] as $name => $f) {
            if (in_array($f['type'], ['image', 'file'], true) && ($f['rules'] ?? '') === 'required_without:id'
                && $request->boolean("remove_{$name}") && ! $request->hasFile($name)) {
                throw ValidationException::withMessages([$name => 'This '.$r['singular'].' needs a photo. Choose a new photo to replace the current one.']);
            }
        }

        foreach ($r['fields'] as $name => $f) {
            if ($f['readonly'] ?? false) {
                continue;
            }
            switch ($f['type']) {
                case 'checkbox':
                    $item->{$name} = $request->boolean($name);
                    break;
                case 'image':
                case 'file':
                    $old = $item->{$name};
                    if ($request->hasFile($name)) {
                        // store the new file first, so the old one is only deleted once the new one is safe
                        $item->{$name} = $f['type'] === 'image'
                            ? Media::store($request->file($name), $r['dir'] ?? 'uploads')
                            : $request->file($name)->store($r['dir'] ?? 'uploads', 'public');
                        Media::delete($old);
                    } elseif ($request->boolean("remove_{$name}")) {
                        Media::delete($old);
                        $item->{$name} = null;
                    }
                    break;
                case 'slug':
                    $item->{$name} = $this->uniqueSlug($r['model'], ($data[$name] ?? null) ?: Str::slug((string) $request->input($f['from'] ?? 'title')), $item->id);
                    break;
                case 'faqs':
                    $item->{$name} = \App\Models\Post::parseFaqs($data[$name] ?? '');
                    break;
                case 'specs':
                    $item->{$name} = \App\Models\RentalBike::parseSpecs($data[$name] ?? '');
                    break;
                case 'number':
                    $item->{$name} = ($data[$name] ?? null) === null || $data[$name] === '' ? (str_contains($f['rules'] ?? '', 'required') ? 0 : ($name === 'sort_order' || $name === 'spots_taken' ? 0 : null)) : $data[$name];
                    break;
                default:
                    $item->{$name} = $data[$name] ?? null;
            }
        }

        $trFields = array_keys(array_filter($r['fields'], fn ($f) => $f['tr'] ?? false));
        if ($trFields) {
            $tr = [];
            foreach (array_keys(Locale::translatable()) as $code) {
                $row = array_filter(array_intersect_key((array) $request->input("translations.{$code}", []), array_flip($trFields)), 'filled');
                foreach ($row as $field => $value) {
                    $row[$field] = ($r['fields'][$field]['type'] ?? '') === 'faqs' ? \App\Models\Post::parseFaqs($value) : trim($value);
                }
                if ($row = array_filter($row, fn ($v) => $v !== [] && $v !== '')) {
                    $tr[$code] = $row;
                }
            }
            $item->translations = $tr;
        }

        $item->save();
    }

    private function uniqueSlug(string $model, string $base, ?int $ignore): string
    {
        $base = $base ?: 'item';
        $slug = $base;
        for ($i = 2; $model::where('slug', $slug)->when($ignore, fn ($q) => $q->where('id', '!=', $ignore))->exists(); $i++) {
            $slug = "{$base}-{$i}";
        }

        return $slug;
    }
}
