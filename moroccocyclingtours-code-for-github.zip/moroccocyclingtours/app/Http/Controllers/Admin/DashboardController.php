<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use App\Models\Booking;
use App\Models\Tour;

class DashboardController extends Controller
{
    public function __invoke()
    {
        $stats = [
            'leads'    => \App\Models\Lead::where('status', 'new')->count(),
            'departures' => \App\Models\Departure::where('start_date', '>=', today())->where('status', '!=', 'cancelled')->count(),
            'tours'    => Tour::where('is_published', true)->count(),
            'drafts'   => Tour::where('is_published', false)->count(),
            'pending'  => Booking::where('status', 'pending')->count(),
            'upcoming' => Booking::whereIn('status', ['pending', 'confirmed'])->whereDate('tour_date', '>=', today())->count(),
            'riders'   => (int) Booking::whereIn('status', ['confirmed', 'completed'])
                ->whereBetween('tour_date', [now()->startOfMonth(), now()->endOfMonth()])->sum('participants'),
            'revenue'  => (float) Booking::whereIn('status', ['confirmed', 'completed'])
                ->whereBetween('tour_date', [now()->startOfMonth(), now()->endOfMonth()])->sum('total_price'),
        ];

        $upcoming = Booking::with('tour.activity')
            ->whereIn('status', ['pending', 'confirmed'])
            ->whereDate('tour_date', '>=', today())
            ->orderBy('tour_date')->limit(8)->get();

        $latest = Booking::latest()->limit(6)->get();

        $byActivity = Activity::withCount(['tours', 'bookings'])->orderBy('sort_order')->get();

        $images = \App\Support\Media::status();
        $pricing = \App\Support\GroupPricing::config();
        $postsDue = \App\Models\Post::where('updated_at', '<', now()->subMonths(12))->orderBy('updated_at')->limit(5)->get();
        $postsWithNotes = \App\Models\Post::where('body', 'like', '%[[%')->orderByDesc('published_at')->get();

        return view('admin.dashboard', compact('stats', 'upcoming', 'latest', 'byActivity', 'images', 'postsDue', 'postsWithNotes', 'pricing'));
    }
}
