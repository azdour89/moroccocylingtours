<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Departure;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;

/** Month view of fixed departures and booking requests */
class CalendarController extends Controller
{
    public function __invoke(Request $request)
    {
        $month = CarbonImmutable::createFromFormat('Y-m', $request->input('month', now()->format('Y-m')))->startOfMonth();
        $start = $month->startOfWeek(CarbonImmutable::MONDAY);
        $end = $month->endOfMonth()->endOfWeek(CarbonImmutable::SUNDAY);

        $departures = Departure::with('tour.activity')
            ->where('start_date', '<=', $end)
            ->where(fn ($q) => $q->where('end_date', '>=', $start)->orWhere(fn ($w) => $w->whereNull('end_date')->where('start_date', '>=', $start)))
            ->orderBy('start_date')->get();
        $bookings = Booking::whereBetween('tour_date', [$start, $end])->where('status', '!=', 'cancelled')->get();

        $days = [];
        for ($d = $start; $d <= $end; $d = $d->addDay()) {
            $key = $d->toDateString();
            $days[$key] = [
                'date' => $d,
                'in_month' => $d->month === $month->month,
                'departures' => $departures->filter(fn ($x) => $x->start_date->toDateString() <= $key && ($x->end_date ?? $x->start_date)->toDateString() >= $key),
                'bookings' => $bookings->filter(fn ($b) => $b->tour_date->toDateString() === $key),
            ];
        }

        return view('admin.calendar', compact('month', 'days', 'departures'));
    }
}
