<?php

namespace App\Http\Controllers;

use App\Models\Page;
use App\Models\Post;

class BlogController extends Controller
{
    public function index()
    {
        $topic = request('topic');

        return view('blog.index', [
            'page' => Page::for('blog'),
            'topic' => array_key_exists((string) $topic, Post::TOPICS) ? $topic : null,
            'posts' => Post::live()->when(array_key_exists((string) $topic, Post::TOPICS), fn ($q) => $q->where('topic', $topic))->latest('published_at')->paginate(12)->withQueryString(),
        ]);
    }

    public function show(Post $post)
    {
        abort_unless($post->is_published && (! $post->published_at || $post->published_at->isPast()), 404);
        $more = Post::live()->where('id', '!=', $post->id)->latest('published_at')->limit(3)->get();

        return view('blog.show', compact('post', 'more'));
    }
}
