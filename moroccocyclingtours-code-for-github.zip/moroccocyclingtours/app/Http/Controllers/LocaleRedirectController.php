<?php

namespace App\Http\Controllers;

use App\Support\Locale;
use Illuminate\Http\Request;

class LocaleRedirectController extends Controller
{
    public function __invoke(Request $request)
    {
        $codes = Locale::codes();
        $locale = $request->session()->get('locale');
        if (! in_array($locale, $codes, true)) {
            $locale = $request->getPreferredLanguage($codes) ?? Locale::fallback();
            $locale = substr($locale, 0, 2);
            $locale = in_array($locale, $codes, true) ? $locale : Locale::fallback();
        }

        $path = trim($request->path(), '/');
        $qs = $request->getQueryString();

        return redirect(url($locale.($path ? '/'.$path : '')).($qs ? '?'.$qs : ''), 302);
    }
}
