<?php

namespace App\Http\Controllers;

use App\Models\Lead;
use App\Models\Page;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

/** Route-guide downloads and private / custom trip requests */
class LeadController extends Controller
{
    public function store(Request $request)
    {
        $data = $request->validate([
            'type' => ['required', Rule::in(array_keys(Lead::TYPES))],
            'name' => 'nullable|string|max:120',
            'email' => 'required|email|max:160',
            'phone' => 'nullable|string|max:40',
            'message' => 'nullable|string|max:3000',
            'travel_date' => 'nullable|string|max:60',
            'group_size' => 'nullable|integer|min:1|max:200',
            'tour_id' => 'nullable|exists:tours,id',
            'website' => 'prohibited',
        ]);
        unset($data['website']);
        Lead::create($data + ['locale' => app()->getLocale(), 'status' => 'new']);

        $guide = $data['type'] === 'guide' ? Page::for('home')->guide_file : null;

        return back()->with('lead_ok', $data['type'])->with('guide_url', $guide ? \App\Support\Media::url($guide) : null)
            ->withFragment($data['type'] === 'guide' ? 'guide' : 'enquiry');
    }
}
