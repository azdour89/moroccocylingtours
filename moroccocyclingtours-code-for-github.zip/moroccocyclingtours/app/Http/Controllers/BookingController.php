<?php

namespace App\Http\Controllers;

use App\Models\Tour;
use Illuminate\Http\Request;

class BookingController extends Controller
{
    public function store(Request $request, Tour $tour)
    {
        abort_unless($tour->is_published, 404);

        $data = $request->validate([
            'name'            => 'required|string|max:120',
            'email'           => 'required|email|max:160',
            'phone'           => 'nullable|string|max:40',
            'country'         => 'nullable|string|max:80',
            'tour_date'       => 'required|date|after_or_equal:today',
            'participants'    => 'required|integer|min:1|max:'.($tour->capacity ?: 50),
            'pickup_location' => 'nullable|string|max:160',
            'message'         => 'nullable|string|max:2000',
            'addons'          => 'nullable|array',
            'addons.*'        => 'nullable|integer|min:0|max:50',
            'website'         => 'prohibited', // honeypot against bots
        ], [
            'tour_date.after_or_equal' => __('Choose today or a later date.'),
            'participants.max'         => __('This tour takes up to :max riders. Contact us for larger groups.'),
        ]);
        unset($data['website']);

        // Rented equipment: only items offered on this tour, quantities capped, prices always taken from the database
        $offered = $tour->addons->keyBy('id');
        $lines = [];
        $addonsTotal = 0.0;
        foreach ((array) ($data['addons'] ?? []) as $id => $qty) {
            $item = $offered->get((int) $id);
            $qty = $item ? min((int) $qty, $item->max_qty) : 0;
            if ($qty < 1) {
                continue;
            }
            $total = $item->lineTotal($qty, $tour->duration_days);
            $lines[] = ['id' => $item->id, 'name' => $item->name, 'qty' => $qty, 'unit' => $item->unit, 'unit_price' => $item->price,
                'days' => $item->unit === 'day' ? $tour->duration_days : 1, 'total' => $total];
            $addonsTotal += $total;
        }
        unset($data['addons']);

        $tourTotal = ($tour->priceFor((int) $data['participants']) ?? 0) * $data['participants'];   // 0 = quote on request

        $booking = $tour->bookings()->create($data + [
            'tour_title'   => $tour->title,
            'total_price'  => $tourTotal > 0 ? $tourTotal + $addonsTotal : 0,
            'addons'       => $lines ?: null,
            'addons_total' => $addonsTotal,
            'status'      => 'pending',
            'locale'      => app()->getLocale(),   // reply to the guest in their language
        ]);

        // Hook point: send confirmation e-mails here (Mail::to(...)->send(...)).

        return redirect()->to(route('tours.show', ['tour' => $tour->slug]).'#book')
            ->with('booking_ref', $booking->reference);
    }
}
