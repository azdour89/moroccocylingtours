<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\BikeBrand;
use App\Models\Category;
use App\Models\Faq;
use App\Models\HeroSlide;
use App\Models\Page;
use App\Models\Post;
use App\Models\Review;
use App\Models\Tour;

class HomeController extends Controller
{
    public function __invoke()
    {
        $page = Page::for('home');
        $slides = HeroSlide::where('is_active', true)->orderBy('sort_order')->get();
        $activities = Activity::withCount(['tours' => fn ($q) => $q->where('is_published', true)])->orderBy('sort_order')->get();
        $categoryCounts = Tour::published()->selectRaw('category, count(*) as c')->groupBy('category')->pluck('c', 'category');
        $categories = Category::orderBy('sort_order')->get()->filter(fn ($c) => ($categoryCounts[$c->slug] ?? 0) > 0)->values();   // trip types without tours stay hidden

        $allTours = Tour::published()->with('activity')->orderByDesc('is_featured')->orderBy('sort_order')->get();
        $popular = $allTours->where('is_featured', true)->take(6);
        if ($popular->count() < 3) {
            $popular = $allTours->take(6);
        }
        $mapTours = $allTours->map(fn (Tour $t) => TourController::mapPoint($t))->values();

        $reviews = Review::where('is_published', true)->where('show_on_home', true)->latest('reviewed_at')->limit(6)->get();
        $rating = Review::where('is_published', true)->selectRaw('avg(rating) as avg, count(*) as n')->first();
        $faqs = Faq::where('is_published', true)->where('show_on_home', true)->orderBy('sort_order')->limit(8)->get();
        $brands = BikeBrand::where('is_published', true)->orderBy('sort_order')->get();
        $posts = Post::live()->latest('published_at')->limit(3)->get();
        $minPrice = $allTours->where('price', '>', 0)->min('price');

        return view('home', compact('page', 'slides', 'activities', 'categories', 'categoryCounts', 'allTours', 'popular',
            'mapTours', 'reviews', 'rating', 'faqs', 'brands', 'posts', 'minPrice'));
    }
}
