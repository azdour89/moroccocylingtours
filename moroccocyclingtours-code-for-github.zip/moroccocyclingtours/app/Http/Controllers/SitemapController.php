<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\Category;
use App\Models\Post;
use App\Models\Tour;
use App\Support\Locale;

class SitemapController extends Controller
{
    public function __invoke()
    {
        $paths = ['', '/tours', '/bikes', '/about', '/faq', '/events', '/testimonials', '/blog', '/gallery', '/bike-rental', '/historic-sites', '/contact'];
        foreach (Activity::pluck('slug') as $s) {
            $paths[] = "/bikes/{$s}";
        }
        foreach (Category::pluck('slug') as $s) {
            $paths[] = "/trips/{$s}";
        }
        foreach (Tour::published()->pluck('slug') as $s) {
            $paths[] = "/tours/{$s}";
        }
        foreach (Post::live()->pluck('slug') as $s) {
            $paths[] = "/blog/{$s}";
        }

        // image sitemap: gallery photos on /gallery and on the tours they are attached to
        $images = ['/gallery' => \App\Models\GalleryImage::where('is_published', true)->whereNull('video')->orderBy('sort_order')->get()];
        $videos = ['/gallery' => \App\Models\GalleryImage::where('is_published', true)->whereNotNull('video')->orderBy('sort_order')->get()];
        foreach (Tour::published()->with('photos')->get() as $t) {
            if ($t->photos->reject->isVideo()->count()) {
                $images["/tours/{$t->slug}"] = $t->photos->reject->isVideo();
            }
            if ($t->photos->filter->isVideo()->count()) {
                $videos["/tours/{$t->slug}"] = $t->photos->filter->isVideo();
            }
        }

        return response()->view('sitemap', ['paths' => $paths, 'locales' => Locale::codes(), 'images' => $images, 'videos' => $videos])
            ->header('Content-Type', 'application/xml');
    }
}
