<?php

namespace App\Http\Middleware;

use App\Support\Locale;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\URL;
use Symfony\Component\HttpFoundation\Response;

class SetLocale
{
    public function handle(Request $request, Closure $next): Response
    {
        $locale = $request->route('locale');
        abort_unless(in_array($locale, Locale::codes(), true), 404);

        App::setLocale($locale);
        URL::defaults(['locale' => $locale]);   // route('tours.index') now includes the current language
        $request->session()->put('locale', $locale);
        $request->route()->forgetParameter('locale'); // controllers don't receive it

        return $next($request);
    }
}
