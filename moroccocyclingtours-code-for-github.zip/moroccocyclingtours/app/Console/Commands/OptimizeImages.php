<?php

namespace App\Console\Commands;

use App\Models;
use App\Support\Media;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

/**
 * Converts images that were uploaded before optimisation existed (JPG/PNG) to AVIF + WebP
 * in 4 sizes, and adds AVIF versions to images that only have WebP.
 *
 *   php artisan images:optimize            convert everything
 *   php artisan images:optimize --dry-run  only show what would change
 *   php artisan images:optimize --keep-originals
 */
class OptimizeImages extends Command
{
    protected $signature = 'images:optimize {--dry-run : Show what would be converted} {--keep-originals : Do not delete the original JPG/PNG files}';

    protected $description = 'Convert uploaded images to AVIF and WebP in 4 sizes';

    /** model, field, folder, field holds a list of paths */
    private const SOURCES = [
        [Models\Tour::class, 'image', 'tours', false],
        [Models\Tour::class, 'gallery', 'tours/gallery', true],
        [Models\Activity::class, 'image', 'bike-types', false],
        [Models\Category::class, 'image', 'categories', false],
        [Models\Page::class, 'image', 'pages', false],
        [Models\HeroSlide::class, 'image', 'slides', false],
        [Models\HistoricSite::class, 'image', 'sites', false],
        [Models\GalleryImage::class, 'image', 'gallery', false],
        [Models\TeamMember::class, 'photo', 'team', false],
        [Models\BikeBrand::class, 'logo', 'brands', false],
        [Models\BikeBrand::class, 'image', 'brands', false],
        [Models\RentalBike::class, 'image', 'rental', false],
        [Models\RentalItem::class, 'image', 'rental', false],
        [Models\Post::class, 'cover', 'blog', false],
        [Models\Event::class, 'image', 'events', false],
    ];

    public function handle(): int
    {
        $status = Media::status();
        $this->info('Output formats: '.(implode(' + ', array_map('strtoupper', $status['formats'])) ?: 'none').'  (engine: '.$status['engine'].')');
        if (! $status['formats']) {
            $this->error('This PHP installation cannot write WebP or AVIF. Enable the GD extension with WebP support.');

            return self::FAILURE;
        }
        if (! $status['avif']) {
            $this->warn('AVIF is not available: only WebP will be created. Install libavif (avifenc) or a PHP build with AVIF support to add it.');
        }

        $converted = $avifAdded = $skipped = 0;
        $disk = Storage::disk('public');

        foreach (self::SOURCES as [$model, $field, $dir, $isList]) {
            $model::query()->whereNotNull($field)->chunkById(50, function ($items) use ($field, $dir, $isList, $disk, &$converted, &$avifAdded, &$skipped) {
                foreach ($items as $item) {
                    $paths = $isList ? (array) $item->{$field} : [$item->{$field}];
                    $changed = false;
                    foreach ($paths as $i => $path) {
                        if (! $path || str_starts_with($path, 'http') || str_starts_with($path, '/')) {
                            continue;
                        }
                        if (Media::isOptimized($path)) {
                            if (! Media::hasAvif($path) && Media::canEncode('avif')) {
                                $this->line("  + AVIF  {$path}");
                                if (! $this->option('dry-run') && Media::addMissingAvif($path)) {
                                    $avifAdded++;
                                }
                            }
                            continue;
                        }
                        if (! $disk->exists($path)) {
                            $this->warn("  missing {$path}");
                            $skipped++;
                            continue;
                        }
                        $mime = (string) $disk->mimeType($path);
                        $this->line("  convert {$path} ({$mime})");
                        if ($this->option('dry-run')) {
                            continue;
                        }
                        $new = Media::storeFromPath($disk->path($path), $mime, $dir);
                        if (! $new) {
                            $skipped++;   // SVG, PDF or unreadable file: left as it is
                            continue;
                        }
                        if (! $this->option('keep-originals')) {
                            $disk->delete($path);
                        }
                        $paths[$i] = $new;
                        $changed = true;
                        $converted++;
                    }
                    if ($changed) {
                        $item->{$field} = $isList ? array_values($paths) : $paths[0];
                        $item->saveQuietly();
                    }
                }
            });
        }

        $this->newLine();
        $this->info("Converted: {$converted}   AVIF added: {$avifAdded}   Skipped: {$skipped}".($this->option('dry-run') ? '   (dry run, nothing changed)' : ''));

        return self::SUCCESS;
    }
}
