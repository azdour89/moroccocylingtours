<?php

namespace App\Providers;

use App\Models\Activity;
use App\Support\Locale;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Links to the public site from the admin (or e-mails) default to the base language.
        URL::defaults(['locale' => Locale::fallback()]);

        // Menus are cached for an hour and refreshed whenever a bike type or trip type changes
        View::composer('layouts.app', function ($view) {
            $view->with('navActivities', Schema::hasTable('activities')
                ? Cache::remember('nav.activities', 3600, fn () => Activity::orderBy('sort_order')->get())
                : collect());
            $view->with('navCategories', Schema::hasTable('categories')
                ? Cache::remember('nav.categories', 3600, fn () => \App\Models\Category::whereHas('tours', fn ($q) => $q->where('is_published', true))->orderBy('sort_order')->get())
                : collect());
        });
        foreach ([Activity::class => 'nav.activities', \App\Models\Category::class => 'nav.categories'] as $model => $key) {
            $model::saved(fn () => Cache::forget($key));
            $model::deleted(fn () => Cache::forget($key));
        }
    }
}
