<?php

namespace App\Admin;

use App\Support\Media;

class ImageHint
{
    public static function text(): string
    {
        $f = array_map('strtoupper', Media::formats());

        return $f
            ? 'JPG, PNG, WebP, AVIF or GIF up to '.round(Media::maxKb() / 1024, 1).' MB. Converted automatically to '.implode(' + ', $f).' in 4 sizes (1920, 1280, 800, 480 px).'
            : 'JPG, PNG, WebP or GIF up to '.round(Media::maxKb() / 1024, 1).' MB. Image conversion is not available on this server (see Dashboard).';
    }
}
