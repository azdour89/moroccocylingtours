<?php

namespace App\Admin;

use App\Models;

/**
 * Admin content sections. Each entry describes a model, its list columns and its form fields.
 * Field types: text, textarea, markdown, number, date, datetime, select, checkbox, image, file, url, color, slug, rating.
 * 'tr' => true makes a field translatable (fr, es, it, de, nl tabs in the form).
 */
class Resources
{
    public static function all(): array
    {
        $yes = ['type' => 'checkbox'];

        return [
            'pages' => [
                'group' => 'Website', 'label' => 'Page content', 'singular' => 'page', 'icon' => 'edit', 'model' => Models\Page::class,
                'dir' => 'pages', 'order' => ['slug', 'asc'], 'columns' => ['slug', 'title', 'updated_at'], 'search' => 'title',
                'help' => 'Texts for the home page and the About, FAQ, Events, Testimonials, Blog, Gallery, Historic sites and Contact pages. The “home” page also holds the trust badges, the SEO text block and the route-guide PDF.',
                'fields' => [
                    'slug' => ['type' => 'select', 'label' => 'Page', 'options' => 'pages', 'rules' => 'required|string|max:60'],
                    'title' => ['type' => 'text', 'label' => 'Main heading (H1)', 'rules' => 'required|string|max:160', 'tr' => true],
                    'subtitle' => ['type' => 'textarea', 'label' => 'Sub-heading', 'rules' => 'nullable|string|max:300', 'tr' => true, 'rows' => 2],
                    'body' => ['type' => 'markdown', 'label' => 'Text', 'rules' => 'nullable|string', 'tr' => true, 'rows' => 10,
                        'help' => 'Blank line = new paragraph. **bold**, [link text](/en/tours), ## for a sub-heading.'],
                    'badges' => ['type' => 'textarea', 'label' => 'Trust badges (one per line, home page)', 'rules' => 'nullable|string', 'tr' => true, 'rows' => 3],
                    'meta_title' => ['type' => 'text', 'label' => 'SEO title (55–60 characters)', 'rules' => 'nullable|string|max:70', 'tr' => true],
                    'meta_description' => ['type' => 'textarea', 'label' => 'SEO description (150–160 characters)', 'rules' => 'nullable|string|max:170', 'tr' => true, 'rows' => 2],
                    'image' => ['type' => 'image', 'label' => 'Page image'],
                    'guide_file' => ['type' => 'file', 'label' => 'Route guide PDF (home page download form)'],
                ],
            ],
            'hero-slides' => [
                'group' => 'Website', 'label' => 'Hero slider', 'singular' => 'slide', 'icon' => 'eye', 'model' => Models\HeroSlide::class,
                'dir' => 'slides', 'order' => ['sort_order', 'asc'], 'columns' => ['image', 'caption', 'sort_order', 'is_active'], 'search' => 'caption',
                'help' => 'Wide landscape photos for the home page slider. Upload at least 1920 px wide: they are converted to AVIF and WebP in four sizes automatically. A slide can also play a short silent video: the photo is shown first and while the video loads.',
                'fields' => [
                    'image' => ['type' => 'image', 'label' => 'Photo (also the first frame of a video)', 'rules' => 'required_without:id'],
                    'video' => ['type' => 'file', 'label' => 'Looping video (optional)', 'accept' => 'video/mp4,video/webm', 'mimes' => 'mp4,webm', 'max_kb' => 20480,
                                'hint' => 'MP4 (H.264), no sound, 6–15 seconds, 1280×720, ideally under 4 MB. Visitors with reduced motion or data saving see the photo only.'],
                    'caption' => ['type' => 'text', 'label' => 'Caption (small text in the corner)', 'rules' => 'nullable|string|max:140', 'tr' => true],
                    'link_url' => ['type' => 'url', 'label' => 'Caption link (optional)', 'rules' => 'nullable|string|max:255'],
                    'sort_order' => ['type' => 'number', 'label' => 'Order'],
                    'is_active' => $yes + ['label' => 'Show in the slider', 'default' => true],
                ],
            ],
            'departures' => [
                'group' => 'Tours', 'label' => 'Tour calendar', 'singular' => 'departure', 'icon' => 'calendar', 'model' => Models\Departure::class,
                'order' => ['start_date', 'asc'], 'columns' => ['start_date', 'tour_id', 'status', 'spots', 'spots_taken'], 'filters' => ['tour_id', 'status'],
                'help' => 'Fixed departure dates shown on each tour page. See them by month in the calendar view.', 'calendar' => true,
                'fields' => [
                    'tour_id' => ['type' => 'select', 'label' => 'Tour', 'options' => 'tours', 'rules' => 'required|exists:tours,id'],
                    'start_date' => ['type' => 'date', 'label' => 'Start date', 'rules' => 'required|date', 'half' => true],
                    'end_date' => ['type' => 'date', 'label' => 'End date', 'rules' => 'nullable|date|after_or_equal:start_date', 'half' => true],
                    'status' => ['type' => 'select', 'label' => 'Status', 'options' => Models\Departure::STATUSES, 'rules' => 'required', 'half' => true],
                    'price' => ['type' => 'number', 'label' => 'Price per person (leave empty = tour price)', 'rules' => 'nullable|numeric|min:0', 'half' => true],
                    'spots' => ['type' => 'number', 'label' => 'Places', 'rules' => 'nullable|integer|min:1', 'half' => true],
                    'spots_taken' => ['type' => 'number', 'label' => 'Places booked', 'rules' => 'nullable|integer|min:0', 'half' => true],
                    'note' => ['type' => 'text', 'label' => 'Note (shown on the site)', 'rules' => 'nullable|string|max:255'],
                ],
            ],
            'categories' => [
                'group' => 'Tours', 'label' => 'Categories', 'singular' => 'trip type', 'icon' => 'grid', 'model' => Models\Category::class,
                'dir' => 'categories', 'order' => ['sort_order', 'asc'], 'columns' => ['name', 'slug', 'sort_order'], 'search' => 'name',
                'help' => 'Trip types such as “Atlas to Sahara bike tours”. Each one gets its own landing page at /trips/{web address}.',
                'fields' => [
                    'name' => ['type' => 'text', 'label' => 'Name', 'rules' => 'required|string|max:80', 'tr' => true],
                    'slug' => ['type' => 'slug', 'label' => 'Web address', 'from' => 'name'],
                    'description' => ['type' => 'textarea', 'label' => 'Intro text for the landing page', 'rules' => 'nullable|string|max:600', 'tr' => true, 'rows' => 3],
                    'icon' => ['type' => 'select', 'label' => 'Icon', 'options' => 'icons', 'half' => true],
                    'color' => ['type' => 'color', 'label' => 'Colour', 'half' => true, 'default' => '#0E7A5F'],
                    'image' => ['type' => 'image', 'label' => 'Image'],
                    'sort_order' => ['type' => 'number', 'label' => 'Order'],
                ],
            ],
            'historic-sites' => [
                'group' => 'Tours', 'label' => 'Historic sites', 'singular' => 'historic site', 'icon' => 'peak', 'model' => Models\HistoricSite::class,
                'dir' => 'sites', 'order' => ['sort_order', 'asc'], 'columns' => ['image', 'name', 'region', 'period', 'is_published'], 'search' => 'name',
                'help' => 'Kasbahs, mosques and ruins. Sites within 25 km of a route appear automatically on that tour page.', 'map' => true,
                'fields' => [
                    'name' => ['type' => 'text', 'label' => 'Name', 'rules' => 'required|string|max:120', 'tr' => true],
                    'slug' => ['type' => 'slug', 'label' => 'Web address', 'from' => 'name'],
                    'region' => ['type' => 'text', 'label' => 'Region', 'rules' => 'nullable|string|max:120', 'half' => true],
                    'period' => ['type' => 'text', 'label' => 'Period (e.g. 12th century)', 'rules' => 'nullable|string|max:120', 'tr' => true, 'half' => true],
                    'description' => ['type' => 'textarea', 'label' => 'Description', 'rules' => 'nullable|string|max:1500', 'tr' => true, 'rows' => 4],
                    'latitude' => ['type' => 'number', 'label' => 'Latitude', 'rules' => 'nullable|numeric|between:-90,90', 'half' => true, 'step' => 'any'],
                    'longitude' => ['type' => 'number', 'label' => 'Longitude', 'rules' => 'nullable|numeric|between:-180,180', 'half' => true, 'step' => 'any'],
                    'image' => ['type' => 'image', 'label' => 'Photo'],
                    'sort_order' => ['type' => 'number', 'label' => 'Order', 'half' => true],
                    'is_published' => $yes + ['label' => 'Published', 'default' => true],
                ],
            ],
            'gallery' => [
                'group' => 'Website', 'label' => 'Gallery', 'singular' => 'photo', 'icon' => 'eye', 'model' => Models\GalleryImage::class,
                'dir' => 'gallery', 'order' => ['sort_order', 'asc'], 'columns' => ['image', 'caption', 'activity_id', 'album', 'is_published'], 'filters' => ['activity_id', 'album'],
                'help' => 'Every photo has a bike type, a caption, an SEO title, an alt text and a description, in all six languages. Photos are shown on the Gallery page and can be attached to tours (Tours → edit → Photos & equipment). Photos with identifiable faces of guests stay unpublished until you have their permission.',
                'fields' => [
                    'image' => ['type' => 'image', 'label' => 'Photo (also the cover picture of a video)', 'rules' => 'required_without:id'],
                    'video' => ['type' => 'file', 'label' => 'Video (optional)', 'accept' => 'video/mp4,video/webm', 'mimes' => 'mp4,webm', 'max_kb' => 20480,
                                'hint' => 'MP4 (H.264), no sound, 1280×720, ideally under 8 MB. It opens in the gallery pop-up.'],
                    'activity_id' => ['type' => 'select', 'label' => 'Bike type / activity', 'options' => 'activities', 'rules' => 'nullable|exists:activities,id', 'half' => true, 'empty' => '— none (scenery, food, tour life) —'],
                    'album' => ['type' => 'text', 'label' => 'Album (e.g. High Atlas, Sahara)', 'rules' => 'nullable|string|max:80', 'half' => true],
                    'caption' => ['type' => 'text', 'label' => 'Caption (shown under the photo)', 'rules' => 'nullable|string|max:200', 'tr' => true],
                    'seo_title' => ['type' => 'text', 'label' => 'SEO title (about 60 characters)', 'rules' => 'nullable|string|max:160', 'tr' => true],
                    'alt_text' => ['type' => 'text', 'label' => 'Alt text (describe what the picture shows)', 'rules' => 'nullable|string|max:255', 'tr' => true],
                    'description' => ['type' => 'textarea', 'label' => 'SEO description (about 155 characters)', 'rows' => 2, 'rules' => 'nullable|string|max:400', 'tr' => true],
                    'sort_order' => ['type' => 'number', 'label' => 'Order', 'half' => true],
                    'is_published' => $yes + ['label' => 'Published', 'default' => true],
                ],
            ],
            'team' => [
                'group' => 'Website', 'label' => 'Team', 'singular' => 'team member', 'icon' => 'helmet', 'model' => Models\TeamMember::class,
                'dir' => 'team', 'order' => ['sort_order', 'asc'], 'columns' => ['photo', 'name', 'role', 'is_published'], 'search' => 'name',
                'fields' => [
                    'name' => ['type' => 'text', 'label' => 'Name', 'rules' => 'required|string|max:120', 'half' => true],
                    'role' => ['type' => 'text', 'label' => 'Role (e.g. MTB guide)', 'rules' => 'nullable|string|max:120', 'tr' => true, 'half' => true],
                    'bio' => ['type' => 'textarea', 'label' => 'Short bio', 'rules' => 'nullable|string|max:1200', 'tr' => true, 'rows' => 4],
                    'languages' => ['type' => 'text', 'label' => 'Languages spoken', 'rules' => 'nullable|string|max:160'],
                    'photo' => ['type' => 'image', 'label' => 'Photo (square works best)'],
                    'sort_order' => ['type' => 'number', 'label' => 'Order', 'half' => true],
                    'is_published' => $yes + ['label' => 'Published', 'default' => true],
                ],
            ],
            'bike-brands' => [
                'group' => 'Tours', 'label' => 'Bike brands', 'singular' => 'bike brand', 'icon' => 'wrench', 'model' => Models\BikeBrand::class,
                'dir' => 'brands', 'order' => ['sort_order', 'asc'], 'columns' => ['image', 'logo', 'name', 'is_published'], 'search' => 'name',
                'help' => 'Brands in your rental fleet. The logo appears in the strip on the home and About pages, the photo on the Bike rental page.',
                'fields' => [
                    'name' => ['type' => 'text', 'label' => 'Brand', 'rules' => 'required|string|max:80', 'half' => true],
                    'url' => ['type' => 'url', 'label' => 'Website', 'rules' => 'nullable|url|max:255', 'half' => true],
                    'description' => ['type' => 'text', 'label' => 'Models in the fleet (e.g. Grail CF 7, Spectral:ON)', 'rules' => 'nullable|string|max:255'],
                    'image' => ['type' => 'image', 'label' => 'Photo of a bike from this brand'],
                    'logo' => ['type' => 'image', 'label' => 'Logo (SVG or PNG on transparent background)'],
                    'sort_order' => ['type' => 'number', 'label' => 'Order', 'half' => true],
                    'is_published' => $yes + ['label' => 'Published', 'default' => true],
                ],
            ],
            'rental-bikes' => [
                'group' => 'Rentals', 'label' => 'Rental bikes', 'singular' => 'rental bike', 'icon' => 'wrench', 'model' => Models\RentalBike::class,
                'dir' => 'rental', 'order' => ['sort_order', 'asc'], 'columns' => ['image', 'name', 'bike_brand_id', 'activity_id', 'price_day', 'quantity', 'is_published'], 'search' => 'name', 'filters' => ['activity_id', 'bike_brand_id'],
                'help' => 'The bikes of your fleet, shown on the Bike rental page with their full specification. Prices are per day; leave the price empty to show "on request".',
                'fields' => [
                    'name' => ['type' => 'text', 'label' => 'Model name (without the brand)', 'rules' => 'required|string|max:160', 'half' => true],
                    'slug' => ['type' => 'slug', 'label' => 'Web address (slug)', 'from' => 'name', 'half' => true],
                    'bike_brand_id' => ['type' => 'select', 'label' => 'Brand', 'options' => 'bike-brands', 'rules' => 'nullable|exists:bike_brands,id', 'half' => true],
                    'activity_id' => ['type' => 'select', 'label' => 'Bike type', 'options' => 'activities', 'rules' => 'nullable|exists:activities,id', 'half' => true],
                    'model_year' => ['type' => 'number', 'step' => 1, 'label' => 'Model year', 'rules' => 'nullable|integer|min:2000|max:2100', 'half' => true],
                    'image' => ['type' => 'image', 'label' => 'Photo of the bike'],
                    'description' => ['type' => 'textarea', 'rows' => 4, 'label' => 'Description (who it is for, how it rides)', 'rules' => 'nullable|string|max:3000', 'tr' => true],
                    'sizes' => ['type' => 'text', 'label' => 'Frame sizes (e.g. S, M, L, XL)', 'rules' => 'nullable|string|max:80', 'half' => true],
                    'rider_height' => ['type' => 'text', 'label' => 'Rider height (e.g. 150–195 cm)', 'rules' => 'nullable|string|max:80', 'half' => true],
                    'wheel_size' => ['type' => 'text', 'label' => 'Wheel size (e.g. 29")', 'rules' => 'nullable|string|max:40', 'half' => true],
                    'frame_material' => ['type' => 'text', 'label' => 'Frame material', 'rules' => 'nullable|string|max:80', 'half' => true],
                    'travel_front' => ['type' => 'number', 'step' => 1, 'label' => 'Front suspension travel (mm)', 'rules' => 'nullable|integer|min:0|max:300', 'half' => true],
                    'travel_rear' => ['type' => 'number', 'step' => 1, 'label' => 'Rear suspension travel (mm)', 'rules' => 'nullable|integer|min:0|max:300', 'half' => true],
                    'motor' => ['type' => 'text', 'label' => 'Motor (e-bikes)', 'rules' => 'nullable|string|max:120', 'half' => true],
                    'battery_wh' => ['type' => 'number', 'step' => 1, 'label' => 'Battery (Wh, e-bikes)', 'rules' => 'nullable|integer|min:0|max:2000', 'half' => true],
                    'weight_kg' => ['type' => 'number', 'step' => '0.1', 'label' => 'Weight (kg)', 'rules' => 'nullable|numeric|min:0|max:60', 'half' => true],
                    'specs' => ['type' => 'specs', 'label' => 'More specifications – one per line: Label | Value', 'rows' => 9, 'rules' => 'nullable|string|max:4000'],
                    'price_day' => ['type' => 'number', 'step' => '0.01', 'label' => 'Price per day', 'rules' => 'nullable|numeric|min:0', 'half' => true],
                    'deposit' => ['type' => 'number', 'step' => '0.01', 'label' => 'Deposit', 'rules' => 'nullable|numeric|min:0', 'half' => true],
                    'quantity' => ['type' => 'number', 'step' => 1, 'label' => 'Bikes in the fleet', 'rules' => 'nullable|integer|min:0|max:99', 'half' => true],
                    'source_url' => ['type' => 'url', 'label' => 'Manufacturer page (for your reference)', 'rules' => 'nullable|url|max:255', 'half' => true],
                    'sort_order' => ['type' => 'number', 'label' => 'Order', 'half' => true],
                    'is_published' => $yes + ['label' => 'Show on the Bike rental page', 'default' => true],
                ],
            ],
            'rental-items' => [
                'group' => 'Rentals', 'label' => 'Equipment to rent', 'singular' => 'item', 'icon' => 'bottle', 'model' => Models\RentalItem::class,
                'dir' => 'rental', 'order' => ['sort_order', 'asc'], 'columns' => ['image', 'name', 'category', 'price', 'unit', 'is_published'], 'search' => 'name', 'filters' => ['category'],
                'help' => 'Gear guests can add to their booking at checkout. An item appears on a tour when the tour\'s trip type is listed in "Shown automatically on trip types", or when you tick it in Tours → edit → Photos & equipment.',
                'fields' => [
                    'name' => ['type' => 'text', 'label' => 'Item', 'rules' => 'required|string|max:120', 'tr' => true, 'half' => true],
                    'slug' => ['type' => 'slug', 'label' => 'Web address (slug)', 'from' => 'name', 'half' => true],
                    'category' => ['type' => 'select', 'label' => 'Group', 'options' => 'rental-categories', 'rules' => 'required', 'half' => true],
                    'unit' => ['type' => 'select', 'label' => 'Price is', 'options' => 'rental-units', 'rules' => 'required', 'half' => true],
                    'price' => ['type' => 'number', 'step' => '0.01', 'label' => 'Price', 'rules' => 'required|numeric|min:0', 'half' => true],
                    'max_qty' => ['type' => 'number', 'step' => 1, 'label' => 'Most a guest can add', 'rules' => 'required|integer|min:1|max:50', 'half' => true],
                    'description' => ['type' => 'text', 'label' => 'Short description', 'rules' => 'nullable|string|max:255', 'tr' => true],
                    'applies_to' => ['type' => 'text', 'label' => 'Shown automatically on trip types (comma-separated slugs, e.g. trekking, multi-day)', 'rules' => 'nullable|string|max:255'],
                    'image' => ['type' => 'image', 'label' => 'Photo (optional)'],
                    'sort_order' => ['type' => 'number', 'label' => 'Order', 'half' => true],
                    'is_published' => $yes + ['label' => 'Available to rent', 'default' => true],
                ],
            ],
            'reviews' => [
                'group' => 'Website', 'label' => 'Reviews', 'singular' => 'review', 'icon' => 'check', 'model' => Models\Review::class,
                'order' => ['reviewed_at', 'desc'], 'columns' => ['name', 'rating', 'tour_id', 'reviewed_at', 'show_on_home', 'is_published'], 'search' => 'name', 'filters' => ['tour_id'],
                'help' => 'Copy real guest reviews (e.g. from Google or TripAdvisor) with the guest’s permission. They appear on the Testimonials page, the tour page and the home page.',
                'fields' => [
                    'name' => ['type' => 'text', 'label' => 'Guest name', 'rules' => 'required|string|max:120', 'half' => true],
                    'country' => ['type' => 'text', 'label' => 'Country', 'rules' => 'nullable|string|max:80', 'half' => true],
                    'rating' => ['type' => 'select', 'label' => 'Rating', 'options' => [5 => '★★★★★', 4 => '★★★★', 3 => '★★★', 2 => '★★', 1 => '★'], 'rules' => 'required|integer|between:1,5', 'half' => true],
                    'reviewed_at' => ['type' => 'date', 'label' => 'Date', 'rules' => 'nullable|date', 'half' => true],
                    'title' => ['type' => 'text', 'label' => 'Title', 'rules' => 'nullable|string|max:160'],
                    'body' => ['type' => 'textarea', 'label' => 'Review', 'rules' => 'required|string|max:3000', 'rows' => 5],
                    'tour_id' => ['type' => 'select', 'label' => 'Tour', 'options' => 'tours', 'rules' => 'nullable|exists:tours,id', 'half' => true, 'empty' => '— general —'],
                    'source' => ['type' => 'text', 'label' => 'Source (Google, TripAdvisor…)', 'rules' => 'nullable|string|max:80', 'half' => true],
                    'show_on_home' => $yes + ['label' => 'Show on the home page'],
                    'is_published' => $yes + ['label' => 'Published', 'default' => true],
                ],
            ],
            'posts' => [
                'group' => 'Website', 'label' => 'Blog posts', 'singular' => 'post', 'icon' => 'edit', 'model' => Models\Post::class,
                'dir' => 'blog', 'order' => ['published_at', 'desc'], 'columns' => ['cover', 'title', 'topic', 'published_at', 'is_published'], 'search' => 'title', 'filters' => ['topic'],
                'side_view' => 'admin.posts._checklist',
                'help' => 'Write [[note: …]] anywhere in the text for reminders to yourself (a personal story to add, a price to check). Notes never appear on the website and the checklist lists them until they are gone.',
                'fields' => [
                    'title' => ['type' => 'text', 'label' => 'Title (H1, include the focus keyword)', 'rules' => 'required|string|max:160', 'tr' => true],
                    'focus_keyword' => ['type' => 'text', 'label' => 'Focus keyword (the search phrase this post answers)', 'rules' => 'nullable|string|max:120', 'tr' => true, 'half' => true],
                    'topic' => ['type' => 'select', 'label' => 'Topic (for related posts)', 'options' => Models\Post::TOPICS, 'half' => true],
                    'slug' => ['type' => 'slug', 'label' => 'Web address (short, with the keyword)', 'from' => 'title'],
                    'summary' => ['type' => 'markdown', 'label' => 'Quick answer (shown first: answer the question in 2–3 sentences, then key points)', 'rules' => 'nullable|string|max:3000', 'tr' => true, 'rows' => 6],
                    'excerpt' => ['type' => 'textarea', 'label' => 'Card summary (blog list)', 'rules' => 'nullable|string|max:300', 'tr' => true, 'rows' => 2],
                    'body' => ['type' => 'markdown', 'label' => 'Article', 'rules' => 'nullable|string', 'tr' => true, 'rows' => 26,
                        'help' => '## H2 section, ### H3, #### H4. Blank line = new paragraph. [link](/{lang}/tours) – {lang} becomes the visitor’s language. Tables: | Season | Best for | lines. Photos: ![alt text](/storage/blog/photo.webp).'],
                    'faqs' => ['type' => 'faqs', 'label' => 'FAQ (one per line: Question | Answer) – shown at the end and sent to Google as FAQ data', 'rules' => 'nullable|string', 'tr' => true, 'rows' => 6],
                    'meta_title' => ['type' => 'text', 'label' => 'Meta title (under 60 characters)', 'rules' => 'nullable|string|max:70', 'tr' => true],
                    'meta_description' => ['type' => 'textarea', 'label' => 'Meta description (under 155 characters, invites a click)', 'rules' => 'nullable|string|max:170', 'tr' => true, 'rows' => 2],
                    'cover' => ['type' => 'image', 'label' => 'Cover photo (your own photo)'],
                    'cover_alt' => ['type' => 'text', 'label' => 'Cover alt text (describe the photo, keyword where natural)', 'rules' => 'nullable|string|max:200', 'tr' => true],
                    'author' => ['type' => 'text', 'label' => 'Author name', 'rules' => 'nullable|string|max:120', 'half' => true],
                    'published_at' => ['type' => 'datetime', 'label' => 'Publish date', 'rules' => 'nullable|date', 'half' => true],
                    'author_bio' => ['type' => 'textarea', 'label' => 'Short author bio (e.g. “Guide since 2005, rides the Atlas every week”)', 'rules' => 'nullable|string|max:400', 'rows' => 2],
                    'is_published' => $yes + ['label' => 'Published', 'default' => true],
                ],
            ],
            'faqs' => [
                'group' => 'Website', 'label' => 'FAQs', 'singular' => 'question', 'icon' => 'list', 'model' => Models\Faq::class,
                'order' => ['sort_order', 'asc'], 'columns' => ['question', 'group', 'show_on_home', 'is_published'], 'search' => 'question', 'filters' => ['group'],
                'fields' => [
                    'question' => ['type' => 'text', 'label' => 'Question', 'rules' => 'required|string|max:255', 'tr' => true],
                    'answer' => ['type' => 'markdown', 'label' => 'Answer', 'rules' => 'required|string', 'tr' => true, 'rows' => 4,
                        'help' => 'Links: [text](/{lang}/blog/my-post). {lang} becomes the visitor’s language.'],
                    'group' => ['type' => 'select', 'label' => 'Group', 'options' => Models\Faq::GROUPS, 'half' => true],
                    'sort_order' => ['type' => 'number', 'label' => 'Order', 'half' => true],
                    'show_on_home' => $yes + ['label' => 'Show on the home page'],
                    'is_published' => $yes + ['label' => 'Published', 'default' => true],
                ],
            ],
            'events' => [
                'group' => 'Website', 'label' => 'Events', 'singular' => 'event', 'icon' => 'calendar', 'model' => Models\Event::class,
                'dir' => 'events', 'order' => ['starts_at', 'asc'], 'columns' => ['image', 'title', 'starts_at', 'location', 'is_published'], 'search' => 'title',
                'help' => 'Races, festivals, group departures and open days.',
                'fields' => [
                    'title' => ['type' => 'text', 'label' => 'Title', 'rules' => 'required|string|max:160', 'tr' => true],
                    'slug' => ['type' => 'slug', 'label' => 'Web address', 'from' => 'title'],
                    'starts_at' => ['type' => 'date', 'label' => 'Start date', 'rules' => 'required|date', 'half' => true],
                    'ends_at' => ['type' => 'date', 'label' => 'End date', 'rules' => 'nullable|date|after_or_equal:starts_at', 'half' => true],
                    'location' => ['type' => 'text', 'label' => 'Place', 'rules' => 'nullable|string|max:160'],
                    'description' => ['type' => 'markdown', 'label' => 'Description', 'rules' => 'nullable|string', 'tr' => true, 'rows' => 5],
                    'link_url' => ['type' => 'url', 'label' => 'Link (registration, tour page…)', 'rules' => 'nullable|string|max:255'],
                    'image' => ['type' => 'image', 'label' => 'Image'],
                    'is_published' => $yes + ['label' => 'Published', 'default' => true],
                ],
            ],
            'leads' => [
                'group' => 'Sales', 'label' => 'Enquiries & leads', 'singular' => 'enquiry', 'icon' => 'mail', 'model' => Models\Lead::class,
                'order' => ['created_at', 'desc'], 'columns' => ['created_at', 'type', 'name', 'email', 'status'], 'search' => 'email', 'filters' => ['type', 'status'],
                'create' => false, 'help' => 'Private-trip requests and route-guide downloads from the website.',
                'fields' => [
                    'type' => ['type' => 'select', 'label' => 'Type', 'options' => Models\Lead::TYPES, 'readonly' => true, 'half' => true],
                    'created_at' => ['type' => 'datetime', 'label' => 'Received', 'readonly' => true, 'half' => true],
                    'name' => ['type' => 'text', 'label' => 'Name', 'readonly' => true, 'half' => true],
                    'email' => ['type' => 'text', 'label' => 'E-mail', 'readonly' => true, 'half' => true],
                    'phone' => ['type' => 'text', 'label' => 'Phone', 'readonly' => true, 'half' => true],
                    'locale' => ['type' => 'text', 'label' => 'Language', 'readonly' => true, 'half' => true],
                    'travel_date' => ['type' => 'text', 'label' => 'Travel dates', 'readonly' => true, 'half' => true],
                    'group_size' => ['type' => 'text', 'label' => 'Group size', 'readonly' => true, 'half' => true],
                    'tour_id' => ['type' => 'select', 'label' => 'Tour', 'options' => 'tours', 'readonly' => true],
                    'message' => ['type' => 'textarea', 'label' => 'Message', 'readonly' => true],
                    'status' => ['type' => 'select', 'label' => 'Status', 'options' => Models\Lead::STATUSES, 'rules' => 'required'],
                    'admin_notes' => ['type' => 'textarea', 'label' => 'Internal notes', 'rules' => 'nullable|string|max:5000', 'rows' => 4],
                ],
            ],
        ];
    }

    public static function get(string $key): ?array
    {
        return self::all()[$key] ?? null;
    }

    public const PAGE_SLUGS = [
        'home' => 'Home page', 'about' => 'About us', 'faq' => 'FAQs', 'events' => 'Events', 'testimonials' => 'Testimonials',
        'blog' => 'Blog', 'gallery' => 'Gallery', 'historic-sites' => 'Historic sites', 'contact' => 'Contact / private trips',
        'tours' => 'All tours (finder)', 'bikes' => 'Bike types',
    ];

    /** Options for select fields that load data */
    public static function options(string|array $source): array
    {
        if (is_array($source)) {
            return $source;
        }

        return match ($source) {
            'tours' => Models\Tour::orderBy('title')->pluck('title', 'id')->all(),
            'activities' => Models\Activity::orderBy('sort_order')->pluck('name', 'id')->all(),
            'bike-brands' => Models\BikeBrand::orderBy('name')->pluck('name', 'id')->all(),
            'rental-categories' => Models\RentalItem::CATEGORIES,
            'rental-units' => Models\RentalItem::UNITS,
            'pages' => self::PAGE_SLUGS,
            'icons' => ['stopwatch' => 'Stopwatch', 'mountain' => 'Mountain', 'dune' => 'Dune', 'ski' => 'Ski', 'car' => '4×4', 'map' => 'Map',
                        'wheel' => 'Wheel', 'peak' => 'Peak', 'helmet' => 'Helmet', 'star8' => 'Zellige star'] + Models\Activity::ICONS,
            default => [],
        };
    }
}
