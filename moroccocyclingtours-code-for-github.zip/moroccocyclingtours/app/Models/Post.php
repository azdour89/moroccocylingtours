<?php

namespace App\Models;

use App\Models\Concerns\Translatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Post extends Model
{
    use Translatable;

    protected $guarded = ['id'];

    protected $casts = ['translations' => 'array', 'faqs' => 'array', 'published_at' => 'datetime', 'is_published' => 'boolean'];

    public const TOPICS = [
        'planning' => 'Planning & seasons', 'bikes' => 'Bikes & gear', 'routes' => 'Routes & regions',
        'safety' => 'Safety & practical', 'culture' => 'Food & culture',
    ];

    /** Guide notes written as [[note: …]] are visible in the admin checklist only, never on the website */
    public const NOTE_PATTERN = '/\[\[(?!(?:photo|video):)(.*?)\]\]/si';

    public function scopeLive($q)
    {
        return $q->where('is_published', true)->where(fn ($w) => $w->whereNull('published_at')->orWhere('published_at', '<=', now()));
    }

    /** Body for visitors: guide notes removed, {lang} replaced by the current language */
    public function publicText(?string $text): string
    {
        $text = preg_replace(self::NOTE_PATTERN, '', (string) $text);
        $text = preg_replace("/\n{3,}/", "\n\n", $text);

        return str_replace('{lang}', app()->getLocale(), trim($text));
    }

    public function notes(?string $locale = null): array
    {
        preg_match_all(self::NOTE_PATTERN, (string) $this->tr('body', $locale).' '.$this->tr('summary', $locale), $m);

        return array_map('trim', $m[1]);
    }

    public function readingMinutes(?string $locale = null): int
    {
        $words = str_word_count(strip_tags($this->publicText($this->tr('body', $locale)).' '.$this->tr('summary', $locale)));

        return max(1, (int) round($words / 220));
    }

    /** FAQs in the current language: [{q, a}] */
    public function faqList(?string $locale = null): array
    {
        return array_values(array_filter((array) $this->tr('faqs', $locale), fn ($f) => ! empty($f['q']) && ! empty($f['a'])));
    }

    public static function faqsToText(?array $faqs): string
    {
        return implode("\n", array_map(fn ($f) => trim($f['q']).' | '.trim($f['a']), $faqs ?? []));
    }

    public static function parseFaqs(?string $text): array
    {
        $out = [];
        foreach (preg_split('/\R/', (string) $text) as $line) {
            if (str_contains($line, '|')) {
                [$q, $a] = array_map('trim', explode('|', $line, 2));
                if ($q !== '' && $a !== '') {
                    $out[] = ['q' => $q, 'a' => $a];
                }
            }
        }

        return $out;
    }

    public function related(int $limit = 3)
    {
        return static::live()->where('id', '!=', $this->id)
            ->orderByRaw('CASE WHEN topic = ? THEN 0 ELSE 1 END', [$this->topic])
            ->latest('published_at')->limit($limit)->get();
    }

    public function getUpdateDueAttribute(): bool
    {
        return $this->updated_at && $this->updated_at->lt(now()->subMonths(12));
    }

    public function getShortExcerptAttribute(): string
    {
        return Str::limit((string) $this->tr('excerpt'), 160);
    }
}
