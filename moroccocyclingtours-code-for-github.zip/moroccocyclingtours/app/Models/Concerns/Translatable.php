<?php

namespace App\Models\Concerns;

use App\Support\Locale;

/**
 * Per-language content stored in a JSON "translations" column:
 *   {"fr": {"title": "...", "excerpt": "..."}, "de": {...}}
 * The base columns hold the English (fallback) text.
 */
trait Translatable
{
    /** Translated value of a field for the current (or given) language, falling back to the base column. */
    public function tr(string $field, ?string $locale = null): mixed
    {
        $locale ??= app()->getLocale();
        if ($locale !== Locale::fallback() && is_array($this->translations)) {
            $value = $this->translations[$locale][$field] ?? null;
            if ($value !== null && $value !== '' && $value !== []) {
                return $value;
            }
        }

        return $this->getAttribute($field);
    }

    /** Raw translated value without fallback (for admin forms). */
    public function trRaw(string $locale, string $field): mixed
    {
        return $this->translations[$locale][$field] ?? null;
    }
}
