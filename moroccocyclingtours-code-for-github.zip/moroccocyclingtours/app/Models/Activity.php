<?php

namespace App\Models;

use App\Models\Concerns\Translatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

/**
 * A bike type / activity: Enduro, Gravel bike, Road bike, E-bike, City bike, Cross-country.
 */
class Activity extends Model
{
    use Translatable;

    /** Icon keys available in resources/views/components/icon.blade.php */
    public const ICONS = [
        'road'          => 'Road bike (drop bars)',
        'gravel'        => 'Gravel bike (flared drops)',
        'enduro'        => 'Enduro (full suspension)',
        'ebike'         => 'E-bike (battery)',
        'city'          => 'City bike (basket)',
        'cross-country' => 'Cross-country (hardtail)',
    ];

    protected $fillable = ['name', 'slug', 'icon', 'color', 'image', 'description', 'translations', 'sort_order'];

    protected $casts = ['translations' => 'array'];

    /** Fields editable per language in the admin */
    public const TRANSLATABLE = ['name', 'description'];

    protected static function booted(): void
    {
        static::saving(function (Activity $a) {
            $a->slug = $a->slug ?: Str::slug($a->name);
        });
    }

    public function tours()
    {
        return $this->hasMany(Tour::class);
    }

    public function bookings()
    {
        return $this->hasManyThrough(Booking::class, Tour::class);
    }
}
