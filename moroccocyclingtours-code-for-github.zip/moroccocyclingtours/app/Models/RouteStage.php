<?php

namespace App\Models;

use App\Models\Concerns\Translatable;
use Illuminate\Database\Eloquent\Model;

/**
 * One riding day of a tour, with Komoot-style route data:
 * overview map, points of interest, surfaces, details, elevation profile and weather.
 */
class RouteStage extends Model
{
    use Translatable;

    protected $guarded = ['id'];

    protected $casts = [
        'translations' => 'array', 'route' => 'array', 'profile' => 'array', 'surfaces' => 'array', 'pois' => 'array',
        'gpx_public' => 'boolean', 'profile_approximate' => 'boolean', 'distance_km' => 'float',
    ];

    /** Surface types: key => [label, colour]. Labels are translated in lang/*.json */
    public const SURFACES = [
        'asphalt'   => ['Asphalt', '#5B6B67'],
        'compacted' => ['Compacted gravel', '#C9A227'],
        'gravel'    => ['Loose gravel', '#A0712B'],
        'unpaved'   => ['Unpaved track', '#8A5A2B'],
        'natural'   => ['Singletrack / natural trail', '#0E7A5F'],
        'alpine'    => ['Alpine path', '#1B4F8C'],
        'sand'      => ['Sand', '#E0A526'],
        'unknown'   => ['Unknown', '#B8C2BF'],
    ];

    /** Accepts Komoot’s English and French labels */
    private const SURFACE_ALIASES = [
        'asphalte' => 'asphalt', 'paved' => 'asphalt', 'asphalt' => 'asphalt', 'route' => 'asphalt',
        'pierres plates' => 'compacted', 'compact gravel' => 'compacted', 'compacted gravel' => 'compacted', 'compacted' => 'compacted',
        'gravillon' => 'gravel', 'gravel' => 'gravel', 'loose gravel' => 'gravel',
        'non pavé' => 'unpaved', 'non pave' => 'unpaved', 'unpaved' => 'unpaved', 'unpaved track' => 'unpaved',
        'naturel' => 'natural', 'natural' => 'natural', 'singletrack' => 'natural', 'trail' => 'natural',
        'alpin' => 'alpine', 'alpine' => 'alpine', 'sable' => 'sand', 'sand' => 'sand', 'inconnu' => 'unknown', 'unknown' => 'unknown',
    ];

    public const POI_TYPES = [
        'viewpoint' => ['Viewpoint', '#1B4F8C'], 'pass' => ['Mountain pass', '#9B2C2C'], 'village' => ['Village', '#8A5A2B'],
        'water' => ['Water point', '#1F7A8C'], 'food' => ['Lunch / café', '#E0A526'], 'sleep' => ['Overnight', '#0F2A26'],
        'historic' => ['Historic site', '#6B4E9B'], 'info' => ['Point of interest', '#0E7A5F'],
    ];

    public function tour()
    {
        return $this->belongsTo(Tour::class);
    }

    /** Komoot tour link or embed link → embed URL for the admin preview iframe */
    public function getKomootEmbedAttribute(): ?string
    {
        $url = trim((string) $this->komoot_url);
        if ($url === '') {
            return null;
        }
        if (str_contains($url, '/embed')) {
            return $url;
        }
        if (preg_match('~komoot\.[a-z.]+/(?:[a-z]{2}(?:-[a-z]{2})?/)?tour/(\d+)~i', $url, $m)) {
            parse_str((string) parse_url($url, PHP_URL_QUERY), $q);

            return "https://www.komoot.com/tour/{$m[1]}/embed?profile=1".(! empty($q['share_token']) ? '&share_token='.urlencode($q['share_token']) : '');
        }

        return null;
    }

    public function getSurfaceTotalAttribute(): float
    {
        return (float) collect($this->surfaces ?? [])->sum('km');
    }

    /* ---------- admin text <-> data ---------- */

    /** "Asphalte | 16.1 km" lines → [{type, km}] */
    public static function parseSurfaces(?string $text): array
    {
        $out = [];
        foreach (preg_split('/\R/', (string) $text) as $line) {
            if (! str_contains($line, '|')) {
                continue;
            }
            [$label, $value] = array_map('trim', explode('|', $line, 2));
            $key = self::SURFACE_ALIASES[mb_strtolower($label)] ?? (array_key_exists($label, self::SURFACES) ? $label : 'unknown');
            $out[] = ['type' => $key, 'km' => self::toKm($value)];
        }

        return $out;
    }

    public static function surfacesToText(?array $items): string
    {
        return implode("\n", array_map(fn ($s) => $s['type'].' | '.$s['km'], $items ?? []));
    }

    /** "Tizi n’Tamatert | pass | 31.150, -7.888" lines → [{name, type, lat, lng}] */
    public static function parsePois(?string $text): array
    {
        $out = [];
        foreach (preg_split('/\R/', (string) $text) as $line) {
            $p = array_map('trim', explode('|', $line));
            if (count($p) < 3 || ! preg_match('/(-?\d+(?:\.\d+)?)\s*[,; ]\s*(-?\d+(?:\.\d+)?)/', $p[2], $m)) {
                continue;
            }
            $out[] = ['name' => $p[0], 'type' => array_key_exists($p[1], self::POI_TYPES) ? $p[1] : 'info', 'lat' => (float) $m[1], 'lng' => (float) $m[2]];
        }

        return $out;
    }

    public static function poisToText(?array $items): string
    {
        return implode("\n", array_map(fn ($p) => "{$p['name']} | {$p['type']} | {$p['lat']}, {$p['lng']}", $items ?? []));
    }

    /** "12.5 | 1450" lines → [[km, ele]] */
    public static function parseProfile(?string $text): array
    {
        $out = [];
        foreach (preg_split('/\R/', (string) $text) as $line) {
            if (preg_match('/(-?\d+(?:[.,]\d+)?)\s*\|\s*(-?\d+(?:[.,]\d+)?)/', $line, $m)) {
                $out[] = [(float) str_replace(',', '.', $m[1]), (float) str_replace(',', '.', $m[2])];
            }
        }
        usort($out, fn ($a, $b) => $a[0] <=> $b[0]);

        return $out;
    }

    public static function profileToText(?array $items): string
    {
        return implode("\n", array_map(fn ($p) => $p[0].' | '.$p[1], $items ?? []));
    }

    private static function toKm(string $v): float
    {
        $v = mb_strtolower(str_replace(',', '.', $v));
        preg_match('/(\d+(?:\.\d+)?)/', $v, $m);
        $n = (float) ($m[1] ?? 0);
        if (str_contains($v, '<')) {
            $n = $n / 2;
        }

        return round(preg_match('/\d\s*m\b/', $v) && ! str_contains($v, 'km') ? $n / 1000 : $n, 2);
    }
}
