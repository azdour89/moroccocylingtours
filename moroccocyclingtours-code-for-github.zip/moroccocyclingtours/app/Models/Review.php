<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    protected $guarded = ['id'];

    protected $casts = ['reviewed_at' => 'date', 'show_on_home' => 'boolean', 'is_published' => 'boolean', 'rating' => 'integer'];

    public function tour()
    {
        return $this->belongsTo(Tour::class);
    }
}
