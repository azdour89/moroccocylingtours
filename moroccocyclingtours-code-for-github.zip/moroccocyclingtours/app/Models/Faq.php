<?php

namespace App\Models;

use App\Models\Concerns\Translatable;
use Illuminate\Database\Eloquent\Model;

class Faq extends Model
{
    use Translatable;

    protected $guarded = ['id'];

    protected $casts = ['translations' => 'array', 'show_on_home' => 'boolean', 'is_published' => 'boolean'];

    /** Answer text for visitors: {lang} in links becomes the current language (e.g. /fr/blog/…) */
    public function answerText(): string
    {
        return str_replace('{lang}', app()->getLocale(), (string) $this->tr('answer'));
    }

    /** Topic groups, in the order they appear on the FAQ page */
    public const GROUPS = [
        'general' => 'General', 'entry' => 'Entry & travel', 'booking' => 'Booking & payment', 'bikes' => 'Bikes & equipment',
        'travel' => 'Safety & emergencies', 'culture' => 'Culture, etiquette & dress', 'customs' => 'Customs & prohibited items',
        'food' => 'Food, water & nutrition',
    ];
}
