<?php

namespace App\Models;

use App\Models\Concerns\Translatable;
use Illuminate\Database\Eloquent\Model;

class GalleryImage extends Model
{
    use Translatable;

    protected $guarded = ['id'];

    protected $casts = ['translations' => 'array', 'is_published' => 'boolean'];

    public function activity()
    {
        return $this->belongsTo(Activity::class);
    }

    public function tours()
    {
        return $this->belongsToMany(Tour::class, 'gallery_image_tour');
    }

    public function isVideo(): bool
    {
        return filled($this->video);
    }

    /** ISO 8601 duration for structured data, e.g. PT0M22S */
    public function isoDuration(): ?string
    {
        return $this->video_seconds ? 'PT'.intdiv($this->video_seconds, 60).'M'.($this->video_seconds % 60).'S' : null;
    }

    /** SEO: alt text (describes the picture), title and description, each falling back to the caption */
    public function altText(): string
    {
        return (string) ($this->tr('alt_text') ?: $this->tr('caption') ?: '');
    }

    public function titleText(): string
    {
        return (string) ($this->tr('seo_title') ?: $this->tr('caption') ?: '');
    }

    public function descriptionText(): string
    {
        return (string) ($this->tr('description') ?: $this->tr('caption') ?: '');
    }
}
