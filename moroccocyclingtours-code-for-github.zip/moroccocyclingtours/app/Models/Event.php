<?php

namespace App\Models;

use App\Models\Concerns\Translatable;
use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    use Translatable;

    protected $guarded = ['id'];

    protected $casts = ['translations' => 'array', 'starts_at' => 'date', 'ends_at' => 'date', 'is_published' => 'boolean'];
}
