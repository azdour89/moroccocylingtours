<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Booking extends Model
{
    public const STATUSES = [
        'pending'   => 'Pending',
        'confirmed' => 'Confirmed',
        'completed' => 'Completed',
        'cancelled' => 'Cancelled',
    ];

    protected $fillable = [
        'tour_id', 'tour_title', 'reference', 'name', 'email', 'phone', 'country', 'tour_date',
        'participants', 'pickup_location', 'message', 'total_price', 'status', 'locale', 'admin_notes', 'addons', 'addons_total',
    ];

    protected function casts(): array
    {
        return [
            'tour_date'   => 'date',
            'total_price' => 'float',
            'addons'      => 'array',
            'addons_total' => 'float',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (Booking $b) {
            do {
                $ref = 'MCT-'.strtoupper(Str::random(6));
            } while (static::where('reference', $ref)->exists());
            $b->reference = $ref;
        });
    }

    public function tour()
    {
        return $this->belongsTo(Tour::class);
    }

    public function getStatusLabelAttribute(): string
    {
        return self::STATUSES[$this->status] ?? ucfirst($this->status);
    }

    public function getTotalFormattedAttribute(): string
    {
        return (float) $this->total_price <= 0 ? 'On request' : config('site.currency').number_format((float) $this->total_price, 0);
    }
}
