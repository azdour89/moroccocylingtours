<?php

namespace App\Models;

use App\Models\Concerns\Translatable;
use Illuminate\Database\Eloquent\Model;

class HistoricSite extends Model
{
    use Translatable;

    protected $guarded = ['id'];

    protected $casts = ['translations' => 'array', 'latitude' => 'float', 'longitude' => 'float', 'is_published' => 'boolean'];
}
