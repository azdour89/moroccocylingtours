<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Lead extends Model
{
    protected $guarded = ['id'];

    public const TYPES = ['guide' => 'Route guide download', 'enquiry' => 'Private / custom trip', 'newsletter' => 'Newsletter'];
    public const STATUSES = ['new' => 'New', 'contacted' => 'Contacted', 'won' => 'Booked', 'closed' => 'Closed'];

    public function tour()
    {
        return $this->belongsTo(Tour::class);
    }
}
