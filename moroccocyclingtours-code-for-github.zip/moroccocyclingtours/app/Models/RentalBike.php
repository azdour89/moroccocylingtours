<?php

namespace App\Models;

use App\Models\Concerns\Translatable;
use Illuminate\Database\Eloquent\Model;

/** A bike of the rental fleet, with its full specification. */
class RentalBike extends Model
{
    use Translatable;

    protected $guarded = ['id'];

    protected $casts = ['specs' => 'array', 'translations' => 'array', 'is_published' => 'boolean', 'weight_kg' => 'float', 'price_day' => 'float', 'deposit' => 'float'];

    public function brand()
    {
        return $this->belongsTo(BikeBrand::class, 'bike_brand_id');
    }

    public function activity()
    {
        return $this->belongsTo(Activity::class);
    }

    public function scopeLive($q)
    {
        return $q->where('is_published', true)->orderBy('sort_order')->orderBy('name');
    }

    public function getFullNameAttribute(): string
    {
        return trim(($this->brand?->name ?? '').' '.$this->name);
    }

    /** Key facts for the card: [label => value] using the typed columns */
    public function facts(): array
    {
        $f = [];
        if ($this->wheel_size) { $f['Wheel size'] = $this->wheel_size; }
        if ($this->travel_front || $this->travel_rear) {
            $f['Travel'] = $this->travel_rear ? "{$this->travel_front} / {$this->travel_rear} mm" : "{$this->travel_front} mm";
        }
        if ($this->motor) { $f['Motor'] = $this->motor; }
        if ($this->battery_wh) { $f['Battery'] = $this->battery_wh.' Wh'; }
        if ($this->frame_material) { $f['Frame'] = $this->frame_material; }
        if ($this->weight_kg) { $f['Weight'] = rtrim(rtrim(number_format($this->weight_kg, 1), '0'), '.').' kg'; }
        if ($this->rider_height) { $f['Rider height'] = $this->rider_height; }
        if ($this->sizes) { $f['Sizes'] = $this->sizes; }

        return $f;
    }

    /** "Label | Value" lines (admin) <-> [[label, value], …] */
    public static function specsToText(?array $rows): string
    {
        return implode("\n", array_map(fn ($r) => trim($r[0]).' | '.trim($r[1]), $rows ?? []));
    }

    public static function parseSpecs(?string $text): array
    {
        $out = [];
        foreach (preg_split('/\R/', (string) $text) as $line) {
            if (str_contains($line, '|')) {
                [$k, $v] = array_map('trim', explode('|', $line, 2));
                if ($k !== '' && $v !== '') {
                    $out[] = [$k, $v];
                }
            }
        }

        return $out;
    }
}
