<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BikeBrand extends Model
{
    protected $guarded = ['id'];

    protected $casts = ['is_published' => 'boolean'];
}
