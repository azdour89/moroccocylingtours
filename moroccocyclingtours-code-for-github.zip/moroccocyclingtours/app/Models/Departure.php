<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Departure extends Model
{
    protected $guarded = ['id'];

    public const STATUSES = ['open' => 'Open', 'guaranteed' => 'Guaranteed departure', 'full' => 'Full', 'cancelled' => 'Cancelled'];

    protected $casts = ['start_date' => 'date', 'end_date' => 'date', 'price' => 'float'];

    public function tour()
    {
        return $this->belongsTo(Tour::class);
    }

    public function getSpotsLeftAttribute(): ?int
    {
        return $this->spots ? max(0, $this->spots - $this->spots_taken) : null;
    }
}
