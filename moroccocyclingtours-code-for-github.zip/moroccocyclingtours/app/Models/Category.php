<?php

namespace App\Models;

use App\Models\Concerns\Translatable;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use Translatable;

    protected $guarded = ['id'];

    protected $casts = ['translations' => 'array'];

    public function tours()
    {
        return $this->hasMany(Tour::class, 'category', 'slug');
    }
}
