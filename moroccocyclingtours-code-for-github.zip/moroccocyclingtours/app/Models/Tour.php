<?php

namespace App\Models;

use App\Models\Concerns\Translatable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class Tour extends Model
{
    use Translatable;

    /** Fields editable per language in the admin (lists are one item per line) */
    public const TRANSLATABLE_TEXT = ['title', 'subtitle', 'excerpt', 'description', 'duration_label', 'terrain', 'season'];
    public const TRANSLATABLE_LISTS = ['highlights', 'included', 'not_included', 'what_to_bring'];

    public const LEVELS = [
        'easy'        => 'Easy',
        'moderate'    => 'Moderate',
        'challenging' => 'Challenging',
        'expert'      => 'Expert',
    ];

    /** Trip types shown as filters and on cards */
    public const CATEGORIES = [
        'day'       => ['label' => 'Day rides',                 'icon' => 'stopwatch'],
        'multi-day' => ['label' => 'Multi-day Atlas bike tours', 'icon' => 'mountain'],
        'sahara'    => ['label' => 'Atlas to Sahara bike tours', 'icon' => 'dune'],
        'bike-ski'  => ['label' => 'Bike & ski touring',         'icon' => 'ski'],
        'desert'    => ['label' => 'Desert & culture tours',     'icon' => 'car'],
        'trekking'  => ['label' => 'Trekking tours',             'icon' => 'peak'],
    ];

    /** Duration buckets used by the tour finder and the home page quick search */
    public const DURATIONS = [
        'day'   => 'Day trips',
        'short' => '2–5 days',
        'week'  => '6–14 days',
    ];

    /** Riding styles for the quick search → bike-type slugs */
    public const STYLES = [
        'gravel' => ['label' => 'Gravel', 'activities' => ['gravel-bike']],
        'road'   => ['label' => 'Road', 'activities' => ['road-bike']],
        'mtb'    => ['label' => 'Mountain biking (MTB)', 'activities' => ['enduro', 'cross-country']],
        'ebike'  => ['label' => 'E-bike', 'activities' => ['e-bike']],
        'city'   => ['label' => 'City bike', 'activities' => ['city-bike']],
    ];

    protected $fillable = [
        'activity_id', 'category', 'title', 'subtitle', 'slug', 'excerpt', 'description', 'image', 'gallery',
        'price', 'duration_label', 'duration_hours', 'distance_km', 'elevation_m', 'max_altitude_m',
        'level', 'terrain', 'region', 'start_point', 'latitude', 'longitude', 'route',
        'capacity', 'min_age', 'season', 'highlights', 'itinerary', 'included', 'not_included',
        'what_to_bring', 'translations', 'is_featured', 'is_published', 'sort_order',
    ];

    protected function casts(): array
    {
        return [
            'gallery'        => 'array',
            'route'          => 'array',
            'highlights'     => 'array',
            'itinerary'      => 'array',
            'included'       => 'array',
            'not_included'   => 'array',
            'what_to_bring'  => 'array',
            'translations'   => 'array',
            'is_featured'    => 'boolean',
            'is_published'   => 'boolean',
            'price'          => 'float',
            'duration_hours' => 'float',
            'distance_km'    => 'float',
            'latitude'       => 'float',
            'longitude'      => 'float',
        ];
    }

    /* ---------- relations ---------- */

    /** Tours without a bike (4×4 desert & culture tours) get a stand-in "activity" so views keep working. */
    public function activity()
    {
        return $this->belongsTo(Activity::class)->withDefault(fn (Activity $a) => $a->forceFill([
            'name'  => __('Guided 4×4 tour'),
            'slug'  => '',
            'icon'  => 'car',
            'color' => '#8A5A2B',
        ]));
    }

    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }

    public function stages()
    {
        return $this->hasMany(RouteStage::class)->orderBy('day');
    }

    public function departures()
    {
        return $this->hasMany(Departure::class)->orderBy('start_date');
    }

    public function reviews()
    {
        return $this->hasMany(Review::class)->where('is_published', true)->latest('reviewed_at');
    }

    /** Gallery photos shown on this tour's page (a photo can be shared by several tours) */
    public function photos()
    {
        return $this->belongsToMany(GalleryImage::class, 'gallery_image_tour')->where('gallery_images.is_published', true)->orderBy('gallery_images.sort_order');
    }

    /** All attached photos, published or not (used by the admin form) */
    public function photosAll()
    {
        return $this->belongsToMany(GalleryImage::class, 'gallery_image_tour');
    }

    public function rentalItems()
    {
        return $this->belongsToMany(RentalItem::class, 'rental_item_tour');
    }

    /** Whole days of the tour, for per-day equipment prices */
    public function getDurationDaysAttribute(): int
    {
        return max(1, (int) ceil(((float) $this->duration_hours) / 24));
    }

    /** Equipment offered at checkout: items attached to this tour + items that apply to its trip type */
    public function getAddonsAttribute()
    {
        if (! isset($this->relations['addons_cache'])) {
            $auto = RentalItem::live()->get()->filter(fn (RentalItem $i) => in_array($this->category, $i->appliesToList(), true));
            $this->relations['addons_cache'] = $auto->merge($this->rentalItems()->live()->get())->unique('id')->sortBy('sort_order')->values();
        }

        return $this->relations['addons_cache'];
    }

    /** Category record (trip type), cached for the request */
    public function getCategoryModelAttribute(): ?Category
    {
        static $all;
        $all ??= \Illuminate\Support\Facades\Schema::hasTable('categories') ? Category::all()->keyBy('slug') : collect();

        return $all[$this->category] ?? null;
    }

    /* ---------- scopes ---------- */

    public function scopePublished(Builder $q): Builder
    {
        return $q->where('is_published', true);
    }

    /** Filters for the public tour finder. */
    public function scopeFilter(Builder $q, array $f): Builder
    {
        return $q
            ->when($f['activity'] ?? null, fn ($q, $v) => $q->whereHas('activity', fn ($a) => $a->where('slug', $v)))
            ->when($f['category'] ?? null, fn ($q, $v) => $q->where('category', $v))
            ->when(array_filter((array) ($f['level'] ?? [])), fn ($q, $v) => $q->whereIn('level', $v))
            ->when($f['region'] ?? null, fn ($q, $v) => $q->where('region', $v))
            ->when($f['style'] ?? null, fn ($q, $v) => isset(self::STYLES[$v])
                ? $q->whereHas('activity', fn ($a) => $a->whereIn('slug', self::STYLES[$v]['activities']))
                : $q)
            ->when($f['duration'] ?? null, fn ($q, $v) => match ($v) {
                'day'   => $q->where('duration_hours', '<=', 24),
                'short' => $q->where('duration_hours', '>', 24)->where('duration_hours', '<=', 120),
                'week'  => $q->where('duration_hours', '>', 120),
                default => $q,
            })
            ->when($f['q'] ?? null, fn ($q, $v) => $q->where(fn ($w) => $w
                ->where('title', 'like', "%{$v}%")
                ->orWhere('subtitle', 'like', "%{$v}%")
                ->orWhere('excerpt', 'like', "%{$v}%")
                ->orWhere('region', 'like', "%{$v}%")
                ->orWhere('translations', 'like', "%{$v}%")));
    }

    /* ---------- accessors ---------- */

    public function getImageUrlAttribute(): ?string
    {
        return self::mediaUrl($this->image);
    }

    public function getGalleryUrlsAttribute(): array
    {
        return array_values(array_filter(array_map([self::class, 'mediaUrl'], $this->gallery ?? [])));
    }

    public function getLevelLabelAttribute(): string
    {
        return __(self::LEVELS[$this->level] ?? ucfirst((string) $this->level));
    }

    /** "Price on request": no price set, or no group size this tour can take has a price */
    public function getOnRequestAttribute(): bool
    {
        return \App\Support\GroupPricing::isOnRequest((float) $this->price, $this->capacity);
    }

    /** Lowest price per person this tour can reach (largest group it takes) */
    public function getLowestPriceAttribute(): ?float
    {
        return \App\Support\GroupPricing::lowestFor((float) $this->price, $this->capacity);
    }

    public function getHighestPriceAttribute(): ?float
    {
        return \App\Support\GroupPricing::highestFor((float) $this->price, $this->capacity);
    }

    /** The "from …" price shown on cards and pages */
    public function getPriceFormattedAttribute(): string
    {
        return $this->on_request ? __('On request') : self::money((float) $this->lowest_price);
    }

    /** The base price entered in the admin */
    public function getBasePriceFormattedAttribute(): string
    {
        return (float) $this->price <= 0 ? __('On request') : self::money((float) $this->price);
    }

    /** Price per person for a group size (null = on request) */
    public function priceFor(int $people): ?float
    {
        return $this->on_request ? null : \App\Support\GroupPricing::priceFor((float) $this->price, $people);
    }

    /** Price table by group size, for the tour page */
    public function getGroupPricesAttribute(): array
    {
        return $this->on_request ? [] : \App\Support\GroupPricing::rows((float) $this->price, $this->capacity);
    }

    /** Largest group priced online; bigger groups ask for a quote */
    public function getGroupMaxAttribute(): int
    {
        $max = \App\Support\GroupPricing::maxGroup();

        return $this->capacity ? min($max, $this->capacity) : $max;
    }

    /** People pre-selected in the booking form: the smallest group that has a price */
    public function getDefaultPeopleAttribute(): int
    {
        foreach ($this->group_prices as $row) {
            if ($row['price'] !== null) {
                return $row['min'];
            }
        }

        return min(2, $this->capacity ?: 2);
    }

    public static function money(float $amount): string
    {
        return config('site.currency').number_format($amount, 0);
    }

    public function getCategoryLabelAttribute(): string
    {
        return $this->category_model?->tr('name') ?? __(self::CATEGORIES[$this->category]['label'] ?? ucfirst((string) $this->category));
    }

    public function getCategoryIconAttribute(): string
    {
        return $this->category_model?->icon ?? self::CATEGORIES[$this->category]['icon'] ?? 'map';
    }

    public static function mediaUrl(?string $path): ?string
    {
        if (! $path) {
            return null;
        }

        return Str::startsWith($path, ['http://', 'https://', '/']) ? $path : Storage::url($path);
    }

    public static function uniqueSlug(string $title, ?int $ignoreId = null): string
    {
        $base = Str::slug($title) ?: 'tour';
        $slug = $base;
        $i = 2;
        while (static::where('slug', $slug)->when($ignoreId, fn ($q) => $q->where('id', '!=', $ignoreId))->exists()) {
            $slug = "{$base}-{$i}";
            $i++;
        }

        return $slug;
    }
}
