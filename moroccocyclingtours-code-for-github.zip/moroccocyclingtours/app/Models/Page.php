<?php

namespace App\Models;

use App\Models\Concerns\Translatable;
use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    use Translatable;

    protected $guarded = ['id'];

    protected $casts = ['translations' => 'array'];

    /** Editable page by slug (home, about, faq…). Returns an unsaved stand-in if it doesn’t exist yet. */
    public static function for(string $slug): self
    {
        static $cache = [];

        return $cache[$slug] ??= static::firstWhere('slug', $slug) ?? new static(['slug' => $slug, 'title' => '']);
    }

    /** Trust badges, one per line */
    public function badgeList(): array
    {
        return array_values(array_filter(array_map('trim', preg_split('/\R/', (string) $this->tr('badges')))));
    }
}
