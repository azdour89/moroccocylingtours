<?php

namespace App\Models;

use App\Models\Concerns\Translatable;
use Illuminate\Database\Eloquent\Model;

/** Equipment guests can rent from the shop when they book a tour (helmet, poles, GPS, camping gear…). */
class RentalItem extends Model
{
    use Translatable;

    public const CATEGORIES = [
        'bike' => 'Bike extras', 'protection' => 'Protection', 'clothing' => 'Clothing', 'bags' => 'Bags & packs',
        'navigation' => 'Navigation & photo', 'trekking' => 'Trekking gear', 'camping' => 'Camping & sleeping',
    ];

    public const UNITS = ['day' => 'per day', 'trip' => 'per trip'];

    protected $guarded = ['id'];

    protected $casts = ['translations' => 'array', 'is_published' => 'boolean', 'price' => 'float'];

    public function scopeLive($q)
    {
        return $q->where('is_published', true)->orderBy('sort_order')->orderBy('name');
    }

    /** Trip types (category slugs) that show this item automatically */
    public function appliesToList(): array
    {
        return array_values(array_filter(array_map('trim', explode(',', (string) $this->applies_to))));
    }

    public function tours()
    {
        return $this->belongsToMany(Tour::class, 'rental_item_tour');
    }

    /** Price for a quantity on a tour of $days days */
    public function lineTotal(int $qty, int $days): float
    {
        return $this->price * $qty * ($this->unit === 'day' ? max(1, $days) : 1);
    }
}
