<?php

namespace App\Models;

use App\Models\Concerns\Translatable;
use Illuminate\Database\Eloquent\Model;

class HeroSlide extends Model
{
    use Translatable;

    protected $guarded = ['id'];

    protected $casts = ['translations' => 'array', 'is_active' => 'boolean'];
}
