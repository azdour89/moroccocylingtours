@props(['review'])
<figure class="review-card">
    <x-stars :rating="$review->rating" />
    @if ($review->title)<h3>{{ $review->title }}</h3>@endif
    <blockquote>{{ \Illuminate\Support\Str::limit($review->body, 420) }}</blockquote>
    <figcaption>
        <strong>{{ $review->name }}</strong>@if ($review->country), {{ $review->country }}@endif
        <small>@if ($review->tour){{ $review->tour->tr('title') }} · @endif{{ $review->reviewed_at?->translatedFormat('F Y') }}@if ($review->source) · {{ $review->source }}@endif</small>
    </figcaption>
</figure>
