<div {{ $attributes->merge(['class' => 'frieze']) }} aria-hidden="true"></div>
