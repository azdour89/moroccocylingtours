@props(['level'])
@php
    $keys = array_keys(\App\Models\Tour::LEVELS);
    $step = (array_search($level, $keys) ?: 0) + 1;
    $label = __(\App\Models\Tour::LEVELS[$level] ?? ucfirst((string) $level));
@endphp
<span {{ $attributes->merge(['class' => 'level level-'.$level]) }} title="{{ __('Difficulty: :level (:step of 4)', ['level' => $label, 'step' => $step]) }}">
    <x-icon name="gauge" size="16" />
    <span class="pips" aria-hidden="true">@for ($i = 1; $i <= 4; $i++)<i @class(['on' => $i <= $step])></i>@endfor</span>
    <span class="level-text">{{ $label }}</span>
</span>
