@props(['post'])
<article class="post-card">
    <a href="{{ route('blog.show', $post->slug) }}" class="pc-media" tabindex="-1" aria-hidden="true">
        @if ($post->cover)<x-img :src="$post->cover" :alt="$post->tr('cover_alt') ?? ''" sizes="(max-width: 900px) 100vw, 33vw" />@else<span class="tc-ph" style="--c:#1B4F8C"><x-icon name="edit" size="56" /></span>@endif
    </a>
    <div class="pc-body">
        <p class="pc-meta">@if ($post->topic)<span>{{ __(\App\Models\Post::TOPICS[$post->topic] ?? $post->topic) }}</span> · @endif{{ trans_choice(':count min read|:count min read', $post->readingMinutes()) }}</p>
        <h3><a href="{{ route('blog.show', $post->slug) }}">{{ $post->tr('title') }}</a></h3>
        <p>{{ $post->tr('excerpt') }}</p>
    </div>
</article>
