@props(['tour'])
@php $title = $tour->tr('title'); $url = route('tours.show', ['tour' => $tour->slug]); @endphp
<article class="tour-card" data-tour-id="{{ $tour->id }}" style="--c: {{ $tour->activity->color }}">
    <a href="{{ $url }}" class="tc-media" tabindex="-1" aria-hidden="true">
        @if ($tour->image_url)
            <x-img :src="$tour->image" alt="" sizes="(max-width: 700px) 100vw, (max-width: 1200px) 50vw, 400px" />
        @else
            <span class="tc-ph"><x-icon :name="$tour->activity->icon" size="72" /></span>
        @endif
    </a>
    <div class="tc-body">
        <p class="tc-meta">
            <span class="bike-chip"><x-icon :name="$tour->activity->icon" size="18" />{{ $tour->activity->tr('name') }}</span>
            <span class="tc-region"><x-icon name="pin" size="14" />{{ $tour->region }}</span>
        </p>
        <p class="tc-cat"><x-icon :name="$tour->category_icon" size="14" />{{ $tour->category_label }}</p>
        <h3 class="tc-title"><a href="{{ $url }}">{{ $title }}</a></h3>
        @if ($sub = $tour->tr('subtitle'))<p class="tc-sub">{{ $sub }}</p>@endif
        <p class="tc-excerpt">{{ $tour->tr('excerpt') }}</p>
        <ul class="tc-stats">
            @if ($tour->distance_km)<li title="{{ __('Distance') }}"><x-icon name="wheel" size="16" />{{ $tour->distance_km + 0 }} km</li>@endif
            <li title="{{ __('Duration') }}"><x-icon name="stopwatch" size="16" />{{ $tour->tr('duration_label') }}</li>
            @if ($tour->elevation_m)<li title="{{ __('Elevation gain') }}"><x-icon name="mountain" size="16" />{{ number_format($tour->elevation_m) }} m</li>@endif
        </ul>
        <div class="tc-foot">
            <x-level :level="$tour->level" />
            @if ($tour->on_request)
                <p class="tc-price"><strong class="tc-request">{{ __('Price on request') }}</strong></p>
            @else
                <p class="tc-price"><small>{{ __('from') }}</small> <strong>{{ $tour->price_formatted }}</strong> <small>{{ $tour->activity_id ? __('per rider') : __('per person') }}</small></p>
            @endif
        </div>
    </div>
</article>
