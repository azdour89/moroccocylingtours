{{-- Optimised image: AVIF first, WebP fallback, responsive sizes, lazy loading, fixed proportions (no layout shift) --}}
@props(['src', 'alt' => '', 'sizes' => '100vw', 'eager' => false])
@php
    use App\Support\Media;
    $webp = Media::srcset($src);
    $avif = Media::hasAvif($src) ? Media::srcset($src, 'avif') : null;
    $dim = Media::dimensions($src);
@endphp
@if ($src)
@if ($avif)<picture><source type="image/avif" srcset="{{ $avif }}" sizes="{{ $sizes }}">@endif
<img src="{{ Media::sized($src, 1280) }}" @if ($webp) srcset="{{ $webp }}" sizes="{{ $sizes }}" @endif
     @if ($dim) width="{{ $dim[0] }}" height="{{ $dim[1] }}" @endif
     alt="{{ $alt }}" decoding="async" @if ($eager) fetchpriority="high" @else loading="lazy" @endif {{ $attributes }}>
@if ($avif)</picture>@endif
@endif
