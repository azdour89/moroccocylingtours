@props(['rating' => 5])
<span class="stars" role="img" aria-label="{{ __(':n out of 5 stars', ['n' => $rating]) }}">@for ($i = 1; $i <= 5; $i++)<x-icon name="star" size="16" :class="$i <= $rating ? 'on' : ''" />@endfor</span>
