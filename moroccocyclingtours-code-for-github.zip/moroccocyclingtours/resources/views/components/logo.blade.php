{{-- Brand logo. Round badge by default (square files, 1:1); :round="false" gives the flat logo.
     AVIF first, WebP next, PNG fallback; $height = size in CSS pixels, with 1x/2x/3x versions. --}}
@props(['height' => 56, 'eager' => true, 'alt' => null, 'round' => true])
@php
    $w = $round ? $height : (int) round($height * 1410 / 1290);      // flat logo is 1410 x 1290 px
    $name = $round ? 'logo-round' : 'logo';
    $url = fn ($size, $ext) => asset("img/logo/{$name}-{$size}.{$ext}");
    $set = fn ($ext) => implode(', ', array_map(fn ($s) => $url($s, $ext).' '.$s.'w', [160, 320, 640, 1280]));
@endphp
<picture>
    <source type="image/avif" srcset="{{ $set('avif') }}" sizes="{{ $w }}px">
    <source type="image/webp" srcset="{{ $set('webp') }}" sizes="{{ $w }}px">
    <img src="{{ $url(320, 'png') }}" srcset="{{ $set('png') }}" sizes="{{ $w }}px" width="{{ $w }}" height="{{ $height }}"
         alt="{{ $alt ?? config('site.name') }}" decoding="async" loading="{{ $eager ? 'eager' : 'lazy' }}" {{ $attributes }}>
</picture>
