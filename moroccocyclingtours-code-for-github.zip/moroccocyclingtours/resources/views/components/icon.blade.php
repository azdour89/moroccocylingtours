{{-- Cycling icon set: bike types + bike-tool labels (gauge, wheel, pump, wrench, helmet…) --}}
@props(['name', 'size' => 24])
<svg {{ $attributes->merge(['class' => 'ico ico-'.$name]) }} width="{{ $size }}" height="{{ $size }}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
@switch($name)
    {{-- ===== Bike types ===== --}}
    @case('road')
        <circle cx="5.5" cy="16.5" r="3.6"/><circle cx="18.5" cy="16.5" r="3.6"/>
        <path d="M5.5 16.5 11 16.5 8.8 9.5 5.5 16.5M8.8 9.5H16l-5 7M16 9.5l2.5 7M7.3 8.3h3"/>
        <path d="M16 9.5l-.4-2.2h2.2c1 0 1.2 1.6.4 2.1"/>
        @break
    @case('gravel')
        <circle cx="5.5" cy="16" r="3.6"/><circle cx="18.5" cy="16" r="3.6"/>
        <path d="M5.5 16H11L8.8 9h7.2l-5 7M16 9l2.5 7M7.3 7.8h3"/>
        <path d="M16 9l-.4-2.2h2.1c1.2 0 1.6 1.9.6 2.4"/>
        <path d="M2.5 21.6h.01M7 21.8h.01M12 21.5h.01M16.5 21.8h.01M21 21.6h.01" stroke-width="2.2"/>
        @break
    @case('enduro')
        <circle cx="5.5" cy="16.5" r="3.7" stroke-width="2.4"/><circle cx="18.5" cy="16.5" r="3.7" stroke-width="2.4"/>
        <path d="M5.5 16.5l4-3.5 1.6 3.5 4.6-6.8 2.8 6.8M9.5 13l-1-3.3h-2M15.7 9.7l-.5-2.2h2.6"/>
        <path d="M8.6 12.3l2.2-1.2 1 1.8-2.2 1.2z"/>
        @break
    @case('ebike')
        <circle cx="5.5" cy="16.5" r="3.6"/><circle cx="18.5" cy="16.5" r="3.6"/>
        <path d="M5.5 16.5H11l-2.2-6.5H16l-5 6.5M16 10l2.5 6.5M16 10l-.5-2.3h2.3"/>
        <path d="M12.8 2.2l-2.3 3.6h2.6l-2.2 3.4" stroke-width="1.8"/>
        @break
    @case('city')
        <circle cx="5.5" cy="16.8" r="3.5"/><circle cx="18.5" cy="16.8" r="3.5"/>
        <path d="M5.5 16.8H11l-3-7.3M11 16.8l4.6-7.3 2.9 7.3M6.6 9.5h3M15.6 9.5l-.6-3h2.5"/>
        <path d="M17.2 9.6h4.3l-.7 2.7h-2.9z"/>
        <path d="M2.2 15.3a3.6 3.6 0 0 1 6.6 0M15.2 15.3a3.6 3.6 0 0 1 6.6 0"/>
        @break
    @case('cross-country')
        <circle cx="5.5" cy="17" r="3.6" stroke-dasharray="1.6 1.1"/><circle cx="18.5" cy="17" r="3.6" stroke-dasharray="1.6 1.1"/>
        <path d="M5.5 17H11l-2.2-6.8H16l-5 6.8M16 10.2l2.5 6.8M7.3 9.2h3M16 10.2l-.4-2h2.7"/>
        <path d="M1.8 7.2 5 2.8l2 2.6 1.4-1.6 2.3 3.4"/>
        @break

    {{-- ===== Bike-tool labels ===== --}}
    @case('gauge')
        <path d="M4 17a8 8 0 1 1 16 0"/><path d="M12 17l4.2-4.6"/><circle cx="12" cy="17" r="1.3"/>
        <path d="M6.3 12.2l1.1.8M12 9v1.3M17.7 12.2l-1.1.8"/>
        @break
    @case('wheel')
        <circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="1.6"/>
        <path d="M12 3v7.4M12 13.6V21M3 12h7.4M13.6 12H21M5.6 5.6l5.3 5.3M13.1 13.1l5.3 5.3M18.4 5.6l-5.3 5.3M10.9 13.1l-5.3 5.3"/>
        @break
    @case('stopwatch')
        <circle cx="12" cy="13.5" r="7.5"/><path d="M12 13.5V9.6M10 2.5h4M12 2.5V6M18.4 6.6l1.3-1.3"/>
        @break
    @case('mountain')
        <path d="M2.5 20 9 8.5l3.6 6 2.4-3.6L21.5 20z"/><path d="M7.4 11.3l1.6 1.2 1.6-1.4"/>
        @break
    @case('peak')
        <path d="M12 3v18M5 21h14M12 3l6 4-6 4"/>
        @break
    @case('helmet')
        <path d="M3 15.5a9 8 0 0 1 18 0v1H13l-2 2.2H4.5A1.5 1.5 0 0 1 3 17.2z"/><path d="M8 8.6l2 4.4M13 7.3l1 5.2M17.4 9.4l-1 3.6"/>
        @break
    @case('wrench')
        <path d="M14.7 6.3a4.1 4.1 0 0 0-5.5 5.2L3.5 17.2a1.9 1.9 0 0 0 2.7 2.7l5.7-5.7a4.1 4.1 0 0 0 5.2-5.5l-2.6 2.6-2.3-.5-.5-2.3z"/>
        @break
    @case('allen')
        <path d="M6 3v11.5A3.5 3.5 0 0 0 9.5 18H21"/><path d="M6 6.5h2.2M18 15.5v5"/>
        @break
    @case('pump')
        <path d="M8 21h8M12 21V9M9.5 9h5v-2.5h-5zM12 6.5V3M9.5 3h5M14.5 12.5c3 0 4.5 1.2 4.5 3.5"/>
        @break
    @case('chainring')
        <circle cx="12" cy="12" r="6.2"/><circle cx="12" cy="12" r="2"/>
        <path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M18.7 5.3l-1.6 1.6M6.9 17.1l-1.6 1.6"/>
        @break
    @case('terrain')
        <path d="M2 17c2.5-3 4.5-3 7 0s4.5 3 7 0 3.5-3 6-1M2 12c2.5-3 4.5-3 7 0"/><path d="M14 9h.01M18 7h.01M16.5 11.5h.01" stroke-width="2.2"/>
        @break
    @case('age')
        <circle cx="12" cy="7.5" r="3.5"/><path d="M5 20.5a7 7 0 0 1 14 0"/>
        @break
    @case('tag')
        <path d="M3 12.2V4h8.2l9.3 9.3-8.2 8.2z"/><circle cx="7.6" cy="8.6" r="1.4"/>
        @break
    @case('pin')
        <path d="M12 21s-7-6.2-7-11.6a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.4" r="2.5"/>
        @break
    @case('bottle')
        <path d="M10 2.5h4M10.5 2.5v3L8.5 8v12a1.5 1.5 0 0 0 1.5 1.5h4a1.5 1.5 0 0 0 1.5-1.5V8l-2-2.5v-3M8.5 12h7M8.5 16h7"/>
        @break

    {{-- ===== UI ===== --}}
    @case('star8')
        <path d="M5.5 5.5h13v13h-13z"/><path d="M12 2.8 21.2 12 12 21.2 2.8 12z"/>
        @break
    @case('check') <path d="M4.5 12.5l4.5 4.5 10.5-11"/> @break
    @case('x') <path d="M6 6l12 12M18 6 6 18"/> @break
    @case('play') <path d="M8 5.5v13l11-6.5z" fill="currentColor"/> @break
    @case('search') <circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5 21 21"/> @break
    @case('map') <path d="M3 6.5 9 4l6 2.5L21 4v13.5L15 20l-6-2.5L3 20z"/><path d="M9 4v13.5M15 6.5V20"/> @break
    @case('list') <path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01" stroke-width="2"/> @break
    @case('calendar') <rect x="3.5" y="5" width="17" height="15.5" rx="1.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/> @break
    @case('grid') <rect x="3.5" y="3.5" width="7" height="7" rx="1"/><rect x="13.5" y="3.5" width="7" height="7" rx="1"/><rect x="3.5" y="13.5" width="7" height="7" rx="1"/><rect x="13.5" y="13.5" width="7" height="7" rx="1"/> @break
    @case('plus') <path d="M12 5v14M5 12h14"/> @break
    @case('edit') <path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/> @break
    @case('trash') <path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/> @break
    @case('eye') <path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/> @break
    @case('logout') <path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/> @break
    @case('phone') <path d="M5 3.5h4l1.5 4.5-2.3 1.5a11 11 0 0 0 6.3 6.3l1.5-2.3 4.5 1.5v4a1.5 1.5 0 0 1-1.6 1.5A17 17 0 0 1 3.5 5.1 1.5 1.5 0 0 1 5 3.5z"/> @break
    @case('mail') <rect x="3" y="5" width="18" height="14" rx="1.5"/><path d="M3.5 6l8.5 7 8.5-7"/> @break
    @case('car') <path d="M3 15.5V12l2.2-4.8A2 2 0 0 1 7 6h10a2 2 0 0 1 1.8 1.2L21 12v3.5a1 1 0 0 1-1 1h-1"/><path d="M5 16.5H4a1 1 0 0 1-1-1M9 16.5h6M3 12h18M9 6v6"/><circle cx="7" cy="16.5" r="2"/><circle cx="17" cy="16.5" r="2"/> @break
    @case('ski') <path d="M3 18.5 21 14M5 21.5 21 17.5"/><circle cx="15" cy="4" r="1.8"/><path d="M14 6.5 11 11l3.5 2-1 3.5M11 11 8 9.5l-2 1.5M14.5 13 17 12"/> @break
    @case('dune') <path d="M2 18c3-5 6-7 10-7 3 0 5 2 10 7"/><path d="M8 18c2-3 4-4 7-4"/><circle cx="17" cy="5.5" r="2.2"/><path d="M2 21h20"/> @break
    @case('chevron') <path d="M6 9l6 6 6-6"/> @break
    @case('van') <path d="M2.5 16V7a1 1 0 0 1 1-1H14l4.5 4.5H21a.5.5 0 0 1 .5.5V16h-2"/><path d="M14 6v4.5h4.5M7 16h8"/><circle cx="5" cy="16.5" r="2"/><circle cx="17" cy="16.5" r="2"/> @break
    @case('house') <path d="M3 11.5 12 4l9 7.5M5.5 9.5V20h13V9.5"/><path d="M10 20v-5.5h4V20"/><path d="M8.5 12.5a3.5 3.5 0 0 1 7 0"/> @break
    @case('gps') <circle cx="12" cy="11" r="3"/><path d="M12 2v3M12 17v5M3 11h3M18 11h3"/><circle cx="12" cy="11" r="7"/> @break
    @case('star') <path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/> @break
    @case('download') <path d="M12 4v11M7 10l5 5 5-5M4 20h16"/> @break
    @case('sun') <circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M18.7 5.3l-1.6 1.6M6.9 17.1l-1.6 1.6"/> @break
    @case('cloud') <path d="M7 18.5a4.5 4.5 0 0 1-.6-9A6 6 0 0 1 18 10.5a4 4 0 0 1-.5 8z"/> @break
    @case('rain') <path d="M7 15a4.5 4.5 0 0 1-.6-9A6 6 0 0 1 18 7a4 4 0 0 1-.5 8z"/><path d="M8 18l-1 3M12 18l-1 3M16 18l-1 3"/> @break
    @case('snow') <path d="M7 14.5a4.5 4.5 0 0 1-.6-9A6 6 0 0 1 18 6.5a4 4 0 0 1-.5 8z"/><path d="M8 18.5h.01M12 20.5h.01M16 18.5h.01M10 21.5h.01M14 21.5h.01" stroke-width="2.4"/> @break
    @case('storm') <path d="M7 14.5a4.5 4.5 0 0 1-.6-9A6 6 0 0 1 18 6.5a4 4 0 0 1-.5 8z"/><path d="M12.5 13l-2 4h3l-2 4"/> @break
    @case('globe') <circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.6 3.8 5.6 3.8 9s-1.2 6.4-3.8 9c-2.6-2.6-3.8-5.6-3.8-9S9.4 5.6 12 3z"/> @break
    @case('menu') <path d="M4 7h16M4 12h16M4 17h16"/> @break
    @case('arrow-left') <path d="M19 12H5M11 6l-6 6 6 6"/> @break
    @default
        <circle cx="12" cy="12" r="8"/>
@endswitch
</svg>
