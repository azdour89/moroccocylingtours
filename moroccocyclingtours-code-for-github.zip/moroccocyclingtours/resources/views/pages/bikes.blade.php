@extends('layouts.app')
@section('title', ($page->tr('meta_title') ?: __('Bike types for every rider')).' | '.config('site.name'))
@section('meta_description', $page->tr('meta_description') ?: __('Road, gravel, enduro, cross-country, e-bike and city bike tours in Morocco. Compare the bike types and find the right ride for you.'))
@section('content')
@include('partials.page-head', ['title' => $page->tr('title') ?: __('Bike types for every rider'), 'subtitle' => $page->tr('subtitle') ?: __('From relaxed city rides to technical Atlas singletrack: choose the bike that suits your trip.'), 'crumb' => __('Bike types')])
<section class="section">
    <div class="wrap bike-list">
        @foreach ($activities as $a)
            <article class="bike-row" style="--c: {{ $a->color }}">
                <div class="bike-media">@if ($a->image)<x-img :src="$a->image" :alt="$a->tr('name')" sizes="(max-width: 800px) 100vw, 40vw" />@else<span class="tf-ph"><x-icon :name="$a->icon" size="96" /></span>@endif</div>
                <div class="bike-body">
                    <span class="bike-chip"><x-icon :name="$a->icon" size="18" />{{ trans_choice(':count tour|:count tours', $a->tours_count) }}</span>
                    <h2>{{ $a->tr('name') }}</h2>
                    <p>{{ $a->tr('description') }}</p>
                    <a class="btn btn-green" href="{{ route('bikes.show', $a->slug) }}">{{ __(':name tours', ['name' => $a->tr('name')]) }} →</a>
                </div>
            </article>
        @endforeach
    </div>
</section>
@if ($brands->count())
<section class="brands-strip"><div class="wrap"><p>{{ __('Bikes in our fleet') }}</p>
    <ul>@foreach ($brands as $b)<li title="{{ $b->description }}">@if ($b->logo)<img src="{{ \App\Support\Media::url($b->logo) }}" alt="{{ $b->name }}" loading="lazy">@else<span>{{ $b->name }}</span>@endif</li>@endforeach</ul>
</div></section>
@endif
@endsection
