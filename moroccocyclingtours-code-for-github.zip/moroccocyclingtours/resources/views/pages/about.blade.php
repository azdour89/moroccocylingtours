@extends('layouts.app')
@section('title', ($page->tr('meta_title') ?: ($page->tr('title') ?: __('About us'))).' | '.config('site.name'))
@section('meta_description', $page->tr('meta_description') ?: $page->tr('subtitle'))
@section('content')
@include('partials.page-head', ['title' => $page->tr('title') ?: __('About us'), 'subtitle' => $page->tr('subtitle'), 'crumb' => __('About us'), 'image' => $page->image])
<section class="section">
    <div class="wrap about-grid">
        <div class="prose">@include('partials.markdown', ['text' => $page->tr('body')])</div>
        <aside class="about-stats">
            <div><strong>{{ $stats['tours'] }}</strong><span>{{ __('guided tours') }}</span></div>
            <div><strong>{{ $stats['bikes'] }}</strong><span>{{ __('bike types') }}</span></div>
            @if ($stats['reviews'])<div><strong>{{ $stats['reviews'] }}</strong><span>{{ __('guest reviews') }}</span></div>@endif
            <a class="btn btn-saffron btn-block" href="{{ route('contact') }}">{{ __('Plan a private trip') }}</a>
        </aside>
    </div>
</section>
@if ($team->count())
<section class="section section-tint" id="team">
    <div class="wrap">
        <div class="section-head"><h2>{{ __('Meet the team') }}</h2></div>
        <div class="team-grid">
            @foreach ($team as $m)
                <article class="team-card">
                    @if ($m->photo)<x-img :src="$m->photo" :alt="$m->name" sizes="(max-width: 700px) 50vw, 260px" />@else<span class="team-ph"><x-icon name="helmet" size="56" /></span>@endif
                    <h3>{{ $m->name }}</h3>
                    @if ($m->tr('role'))<p class="team-role">{{ $m->tr('role') }}</p>@endif
                    @if ($m->tr('bio'))<p>{{ $m->tr('bio') }}</p>@endif
                    @if ($m->languages)<p class="muted"><x-icon name="globe" size="14" /> {{ $m->languages }}</p>@endif
                </article>
            @endforeach
        </div>
    </div>
</section>
@endif
@if ($brands->count())
<section class="brands-strip"><div class="wrap"><p>{{ __('Bikes in our fleet') }}</p>
    <ul>@foreach ($brands as $b)<li title="{{ $b->description }}">@if ($b->logo)<img src="{{ \App\Support\Media::url($b->logo) }}" alt="{{ $b->name }}" loading="lazy">@else<span>{{ $b->name }}</span>@endif</li>@endforeach</ul>
</div></section>
@endif
@endsection
