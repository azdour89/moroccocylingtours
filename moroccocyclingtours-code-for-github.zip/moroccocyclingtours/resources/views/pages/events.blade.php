@extends('layouts.app')
@section('title', ($page->tr('meta_title') ?: ($page->tr('title') ?: __('Events'))).' | '.config('site.name'))
@section('meta_description', $page->tr('meta_description') ?: $page->tr('subtitle'))
@push('head')
@if ($upcoming->count())
<script type="application/ld+json">{!! json_encode($upcoming->map(fn ($e) => array_filter(['@context' => 'https://schema.org', '@type' => 'Event', 'name' => $e->tr('title'),
    'startDate' => $e->starts_at->toDateString(), 'endDate' => $e->ends_at?->toDateString(), 'eventAttendanceMode' => 'https://schema.org/OfflineEventAttendanceMode',
    'location' => ['@type' => 'Place', 'name' => $e->location ?: 'Morocco', 'address' => $e->location ?: 'Morocco'], 'organizer' => ['@type' => 'Organization', 'name' => config('site.name'), 'url' => route('home')]]))->values(),
    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) !!}</script>
@endif
@endpush
@section('content')
@include('partials.page-head', ['title' => $page->tr('title') ?: __('Events'), 'subtitle' => $page->tr('subtitle'), 'crumb' => __('Events')])
<section class="section">
    <div class="wrap">
        <h2>{{ __('Upcoming events') }}</h2>
        @forelse ($upcoming as $e)
            <article class="event-row">
                <div class="event-date"><strong>{{ $e->starts_at->format('d') }}</strong><span>{{ $e->starts_at->translatedFormat('M Y') }}</span></div>
                @if ($e->image)<x-img :src="$e->image" alt="" class="event-img" sizes="220px" />@endif
                <div>
                    <h3>{{ $e->tr('title') }}</h3>
                    <p class="muted">{{ $e->starts_at->translatedFormat('j F Y') }}@if ($e->ends_at && ! $e->ends_at->eq($e->starts_at)) – {{ $e->ends_at->translatedFormat('j F Y') }}@endif @if ($e->location) · {{ $e->location }}@endif</p>
                    <div class="prose">@include('partials.markdown', ['text' => $e->tr('description')])</div>
                    @if ($e->link_url)<a class="link-strong" href="{{ $e->link_url }}">{{ __('More information') }} →</a>@endif
                </div>
            </article>
        @empty
            <p>{{ __('No events are planned right now. Follow us or write to us to hear about the next group departures.') }}</p>
        @endforelse
        @if ($past->count())
            <h2 class="mt">{{ __('Past events') }}</h2>
            <ul class="past-events">@foreach ($past as $e)<li><span>{{ $e->starts_at->translatedFormat('j M Y') }}</span> {{ $e->tr('title') }}</li>@endforeach</ul>
        @endif
    </div>
</section>
@endsection
