@extends('layouts.app')
@section('title', ($page->tr('meta_title') ?: ($page->tr('title') ?: __('Testimonials'))).' | '.config('site.name'))
@section('meta_description', $page->tr('meta_description') ?: $page->tr('subtitle'))
@section('content')
@include('partials.page-head', ['title' => $page->tr('title') ?: __('What our riders say'), 'subtitle' => $page->tr('subtitle'), 'crumb' => __('Testimonials')])
<section class="section">
    <div class="wrap">
        @if ($rating->n)<p class="rating-summary big"><x-stars :rating="round($rating->avg)" /> {{ __(':avg out of 5 from :n reviews', ['avg' => number_format($rating->avg, 1), 'n' => $rating->n]) }}</p>@endif
        @if ($reviews->count())
            <div class="review-grid">@foreach ($reviews as $r)<x-review :review="$r" />@endforeach</div>
            {{ $reviews->links('admin.partials.pagination') }}
        @else
            <p>{{ __('Reviews from our guests will appear here soon.') }}</p>
        @endif
    </div>
</section>
@endsection
