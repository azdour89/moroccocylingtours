@extends('layouts.app')
@section('title', ($page->tr('meta_title') ?: ($page->tr('title') ?: __('Historic sites'))).' | '.config('site.name'))
@section('meta_description', $page->tr('meta_description') ?: $page->tr('subtitle'))
@push('head')<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">@endpush
@section('content')
@include('partials.page-head', ['title' => $page->tr('title') ?: __('Historic sites'), 'subtitle' => $page->tr('subtitle'), 'crumb' => __('Historic sites')])
<section class="section">
    <div class="wrap">
        <div class="prose narrow-prose">@include('partials.markdown', ['text' => $page->tr('body')])</div>
        <div id="sites-map" class="tour-map mb"></div>
        <div class="site-cards three">
            @foreach ($sites as $s)
                <article class="site-card" id="{{ $s->slug }}">
                    @if ($s->image)<x-img :src="$s->image" :alt="$s->tr('name')" sizes="(max-width: 700px) 100vw, 33vw" />@endif
                    <div><h2>{{ $s->tr('name') }}</h2>
                        <p class="muted">{{ $s->region }}@if ($s->tr('period')) · {{ $s->tr('period') }}@endif</p>
                        <p>{{ $s->tr('description') }}</p></div>
                </article>
            @endforeach
        </div>
    </div>
</section>
@endsection
@push('scripts')
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
<script src="{{ \App\Support\Asset::v('js/maps.js') }}"></script>
<script>
(function () {
    const map = MCT.base('sites-map', {}); if (!map) return;
    const pts = [];
    {{ \Illuminate\Support\Js::from($sites->filter(fn ($s) => $s->latitude)->map(fn ($s) => ['n' => $s->tr('name'), 'lat' => $s->latitude, 'lng' => $s->longitude, 'id' => $s->slug])->values()) }}.forEach((s) => {
        L.marker([s.lat, s.lng], { icon: MCT.pin('#6B4E9B'), title: s.n }).bindPopup(`<a href="#${s.id}"><strong>${s.n}</strong></a>`).addTo(map); pts.push([s.lat, s.lng]);
    });
    if (pts.length) map.fitBounds(pts, { padding: [40, 40] });
})();
</script>
@endpush
