@extends('layouts.app')
@section('title', ($page->tr('meta_title') ?: __('Frequently Asked Questions About Cycling in Morocco')).' | '.config('site.name'))
@section('meta_description', $page->tr('meta_description') ?: $page->tr('subtitle'))
@push('head')
<script type="application/ld+json">{!! json_encode(['@context' => 'https://schema.org', '@type' => 'FAQPage',
    'mainEntity' => $faqs->flatten()->map(fn ($f) => ['@type' => 'Question', 'name' => $f->tr('question'), 'acceptedAnswer' => ['@type' => 'Answer', 'text' => strip_tags(\Illuminate\Support\Str::markdown($f->answerText()))]])->values()],
    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) !!}</script>
@endpush
@section('content')
@include('partials.page-head', ['title' => $page->tr('title') ?: __('Frequently Asked Questions About Cycling in Morocco'), 'subtitle' => $page->tr('subtitle'), 'crumb' => __('FAQ')])
<section class="section">
    <div class="wrap faq-page">
        @if (\App\Models\Faq::GROUPS && $faqs->count() > 1)
            <nav class="faq-nav" aria-label="{{ __('Topics') }}">
                @foreach ($faqs as $group => $items)<a href="#faq-{{ $group }}">{{ __(\App\Models\Faq::GROUPS[$group] ?? $group) }}</a>@endforeach
            </nav>
        @endif
        <div>
            @forelse ($faqs as $group => $items)
                <h2 id="faq-{{ $group }}">{{ __(\App\Models\Faq::GROUPS[$group] ?? $group) }}</h2>
                <div class="faq-list">
                    @foreach ($items as $f)
                        <details class="faq"><summary>{{ $f->tr('question') }}</summary><div class="prose">@include('partials.markdown', ['text' => $f->answerText()])</div></details>
                    @endforeach
                </div>
            @empty
                <p>{{ __('Questions and answers will appear here soon.') }}</p>
            @endforelse
            <div class="callout">
                <h2>{{ __('Still have a question?') }}</h2>
                <p>{{ __('Write to us and a member of the team will answer within 24 hours.') }}</p>
                <a class="btn btn-green" href="{{ route('contact') }}">{{ __('Contact us') }}</a>
            </div>
        </div>
    </div>
</section>
@endsection
