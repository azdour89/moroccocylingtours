@extends('layouts.app')
@section('title', ($page->tr('meta_title') ?: ($page->tr('title') ?: __('Gallery'))).' | '.config('site.name'))
@section('meta_description', $page->tr('meta_description') ?: $page->tr('subtitle'))
@section('content')
@include('partials.page-head', ['title' => $page->tr('title') ?: __('Gallery'), 'subtitle' => $page->tr('subtitle'), 'crumb' => __('Gallery')])
<script type="application/ld+json">{!! json_encode(['@context' => 'https://schema.org', '@type' => 'ImageGallery', 'name' => $page->tr('title') ?: __('Gallery'), 'url' => url()->current(),
    'associatedMedia' => $photos->map(function ($p) {
        $base = ['name' => $p->titleText(), 'description' => $p->descriptionText(), 'caption' => $p->tr('caption'), 'creator' => ['@type' => 'Organization', 'name' => config('site.name')]];

        return array_filter($p->isVideo()
            ? $base + ['@type' => 'VideoObject', 'contentUrl' => url(\App\Support\Media::url($p->video)), 'thumbnailUrl' => url(\App\Support\Media::sized($p->image, 1280)), 'uploadDate' => optional($p->created_at)->toIso8601String(), 'duration' => $p->isoDuration()]
            : $base + ['@type' => 'ImageObject', 'contentUrl' => url(\App\Support\Media::sized($p->image, 1920)), 'thumbnailUrl' => url(\App\Support\Media::sized($p->image, 480))]);
    })->values()->all()], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!}</script>
<section class="section">
    <div class="wrap">
        @if ($activities->count())
            <div class="album-filter act-filter" role="group" aria-label="{{ __('Bike types') }}">
                <button type="button" class="is-on" data-act="">{{ __('All bike types') }}</button>
                @foreach ($activities as $a)<button type="button" data-act="{{ $a->slug }}" style="--c: {{ $a->color }}"><x-icon :name="$a->icon" size="16" />{{ $a->tr('name') }}</button>@endforeach
            </div>
        @endif
        @if ($albums->count() > 1)
            <div class="album-filter" role="group" aria-label="{{ __('Albums') }}">
                <button type="button" class="is-on" data-album="">{{ __('All photos') }}</button>
                @foreach ($albums as $a)<button type="button" data-album="{{ $a }}">{{ __($a) }}</button>@endforeach
            </div>
        @endif
        @if ($photos->count())
            <div class="gallery-grid" id="gallery">
                @foreach ($photos as $p)
                    <figure data-album="{{ $p->album }}" data-act="{{ $p->activity?->slug }}" @class(['is-portrait' => \App\Support\Media::isPortrait($p->image), 'is-video' => $p->isVideo()])>
                        <a href="{{ $p->isVideo() ? \App\Support\Media::url($p->video) : \App\Support\Media::sized($p->image, 1920) }}" data-lightbox @if ($p->isVideo()) data-video="1" aria-label="{{ __('Play video') }}: {{ $p->altText() }}" @endif
                           data-title="{{ $p->titleText() }}" data-desc="{{ $p->descriptionText() }}" title="{{ $p->titleText() }}">
                            <x-img :src="$p->image" :alt="$p->altText()" sizes="(max-width: 700px) 50vw, 25vw" />
                            @if ($p->isVideo())<span class="play-badge" aria-hidden="true"><x-icon name="play" size="26" /></span>@endif
                        </a>
                        @if ($p->tr('caption'))<figcaption>{{ $p->tr('caption') }}</figcaption>@endif
                    </figure>
                @endforeach
            </div>
        @else
            <p>{{ __('Photos will appear here soon.') }}</p>
        @endif
    </div>
</section>
<dialog class="lightbox" id="lightbox" aria-label="{{ __('Photo viewer') }}">
    <button type="button" class="lb-close" aria-label="{{ __('Close') }}"><x-icon name="x" /></button>
    <img alt="" hidden><video controls playsinline preload="metadata" hidden></video>
    <div class="lb-cap" hidden><strong></strong><span></span></div>
</dialog>
@endsection
@push('scripts')
<script>
(function () {
    const state = { act: '', album: '' };
    const apply = () => document.querySelectorAll('#gallery figure').forEach((f) => {
        f.hidden = (state.act && f.dataset.act !== state.act) || (state.album && f.dataset.album !== state.album);
    });
    document.querySelectorAll('.album-filter button').forEach((b) => b.addEventListener('click', () => {
        const key = 'act' in b.dataset ? 'act' : 'album';
        state[key] = b.dataset[key] || '';
        b.parentElement.querySelectorAll('button').forEach((x) => x.classList.toggle('is-on', x === b));
        apply();
    }));
    const lb = document.getElementById('lightbox'), img = lb.querySelector('img'), vid = lb.querySelector('video'), cap = lb.querySelector('.lb-cap');
    document.querySelectorAll('[data-lightbox]').forEach((a) => a.addEventListener('click', (e) => {
        if (!lb.showModal) return;
        e.preventDefault();
        const isVideo = !!a.dataset.video, thumb = a.querySelector('img');
        img.hidden = isVideo; vid.hidden = !isVideo;
        if (isVideo) { vid.src = a.href; vid.poster = thumb ? thumb.currentSrc || thumb.src : ''; }
        else { img.src = a.href; img.alt = thumb ? thumb.alt : ''; }
        cap.hidden = !(a.dataset.title || a.dataset.desc);
        cap.querySelector('strong').textContent = a.dataset.title || '';
        cap.querySelector('span').textContent = a.dataset.desc && a.dataset.desc !== a.dataset.title ? a.dataset.desc : '';
        lb.showModal();
        if (isVideo) vid.play().catch(() => {});
    }));
    lb.addEventListener('close', () => { vid.pause(); vid.removeAttribute('src'); vid.load(); });
    lb.addEventListener('click', (e) => { if (e.target === lb || e.target.closest('.lb-close')) lb.close(); });
})();
</script>
@endpush
