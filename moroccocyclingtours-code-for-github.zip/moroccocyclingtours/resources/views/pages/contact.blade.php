@extends('layouts.app')
@section('title', ($page->tr('meta_title') ?: __('Plan a private or custom cycling trip')).' | '.config('site.name'))
@section('meta_description', $page->tr('meta_description') ?: __('Tell us your dates, group and riding level and we’ll design a private cycling trip in Morocco for you.'))
@section('content')
@include('partials.page-head', ['title' => $page->tr('title') ?: __('Plan a private or custom cycling trip'), 'subtitle' => $page->tr('subtitle') ?: __('Tell us your dates, group and riding level and we’ll design a trip for you.'), 'crumb' => __('Contact')])
<section class="section" id="enquiry">
    <div class="wrap contact-grid">
        <div>
            @if (session('lead_ok') === 'enquiry')
                <div class="flash flash-ok" role="status"><x-icon name="check" size="20" /><div><strong>{{ __('Thank you!') }}</strong><br>{{ __('We have your request and will reply within 24 hours.') }}</div></div>
            @endif
            <form class="book-form card-form" method="post" action="{{ route('leads.store') }}">
                @csrf
                <input type="hidden" name="type" value="enquiry">
                <div class="hp" aria-hidden="true"><label>{{ __('Website') }} <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
                <div class="row2">
                    <div class="field"><label for="c-name">{{ __('Full name') }}</label><input id="c-name" name="name" value="{{ old('name') }}" autocomplete="name" required></div>
                    <div class="field"><label for="c-email">{{ __('E-mail') }}</label><input id="c-email" type="email" name="email" value="{{ old('email') }}" autocomplete="email" required>@error('email')<p class="err">{{ $message }}</p>@enderror</div>
                </div>
                <div class="row2">
                    <div class="field"><label for="c-phone">{{ __('Phone / WhatsApp') }}</label><input id="c-phone" type="tel" name="phone" value="{{ old('phone') }}" autocomplete="tel"></div>
                    <div class="field"><label for="c-size">{{ __('Group size') }}</label><input id="c-size" type="number" min="1" name="group_size" value="{{ old('group_size', 2) }}"></div>
                </div>
                <div class="row2">
                    <div class="field"><label for="c-dates">{{ __('Travel dates') }}</label><input id="c-dates" name="travel_date" value="{{ old('travel_date') }}" placeholder="{{ __('e.g. 10–17 April 2027') }}"></div>
                    <div class="field"><label for="c-tour">{{ __('Tour you like (optional)') }}</label>
                        <select id="c-tour" name="tour_id"><option value="">{{ __('Not sure yet') }}</option>@foreach ($tours as $t)<option value="{{ $t->id }}" @selected(old('tour_id', request('tour')) == $t->id)>{{ $t->tr('title') }}</option>@endforeach</select></div>
                </div>
                <div class="field"><label for="c-msg">{{ __('Your ideas: riding level, bike type, comfort, places to see') }}</label><textarea id="c-msg" name="message" rows="6">{{ old('message', $prefill ?? '') }}</textarea></div>
                <button class="btn btn-saffron btn-lg" type="submit">{{ __('Send my request') }}</button>
            </form>
        </div>
        <aside class="contact-side">
            <div class="prose">@include('partials.markdown', ['text' => $page->tr('body')])</div>
            <ul class="contact-list">
                <li><x-icon name="mail" size="20" /><a href="mailto:{{ config('site.email') }}">{{ config('site.email') }}</a></li>
                <li><x-icon name="phone" size="20" /><a href="tel:{{ preg_replace('/\s+/', '', config('site.phone')) }}">{{ config('site.phone') }}</a></li>
                <li><x-icon name="phone" size="20" /><a href="https://wa.me/{{ config('site.whatsapp') }}" rel="noopener">WhatsApp</a></li>
                <li><x-icon name="pin" size="20" /><span>{{ config('site.address') }}</span></li>
            </ul>
        </aside>
    </div>
</section>
@endsection
