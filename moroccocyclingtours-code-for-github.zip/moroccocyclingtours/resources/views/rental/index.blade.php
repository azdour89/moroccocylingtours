@extends('layouts.app')
@section('title', __('Bike rental in Morocco: mountain, e-bike and gravel bikes').' | '.config('site.name'))
@section('meta_description', __('Rent a well-kept mountain bike, e-bike or gravel bike for your ride in Morocco. See every bike with its full specification, rider heights and daily price.'))
@section('content')
@include('partials.page-head', ['title' => __('Bike rental'), 'subtitle' => __('Every bike in our fleet with its full specification, so you can pick the right one before you arrive.'), 'crumb' => __('Bike rental')])
@php $cur = config('site.currency'); $money = fn ($v) => $cur.rtrim(rtrim(number_format($v, 2), '0'), '.'); @endphp
<script type="application/ld+json">{!! json_encode(['@context' => 'https://schema.org', '@type' => 'ItemList', 'itemListElement' => $bikes->values()->map(fn ($b, $i) => ['@type' => 'ListItem', 'position' => $i + 1, 'item' => array_filter([
    '@type' => 'Product', 'name' => $b->full_name, 'category' => 'Bicycle rental', 'description' => $b->tr('description'),
    'image' => $b->image ? url(\App\Support\Media::sized($b->image, 1280)) : null, 'brand' => $b->brand ? ['@type' => 'Brand', 'name' => $b->brand->name] : null,
    'offers' => $b->price_day ? ['@type' => 'Offer', 'price' => $b->price_day, 'priceCurrency' => config('site.currency_code'), 'availability' => 'https://schema.org/InStock', 'url' => route('rental')] : null,
])])->all()], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!}</script>
<section class="section">
    <div class="wrap">
        @if ($bikes->isEmpty())
            <p>{{ __('Our rental fleet will be listed here soon. Ask us about the bikes available for your dates.') }}</p>
            <p><a class="btn btn-saffron" href="{{ route('contact') }}">{{ __('Contact us') }}</a></p>
        @else
            @if ($types->count() > 1)
                <div class="album-filter" role="group" aria-label="{{ __('Bike types') }}">
                    <button type="button" class="is-on" data-type="">{{ __('All bikes') }}</button>
                    @foreach ($types as $t)<button type="button" data-type="{{ $t->slug }}">{{ $t->tr('name') }}</button>@endforeach
                </div>
            @endif
            <div class="rent-grid" id="rent-grid">
                @foreach ($bikes as $b)
                    <article class="rent-card" data-type="{{ $b->activity?->slug }}" id="bike-{{ $b->slug }}">
                        <div class="rent-photo">
                            @if ($b->image)
                                <x-img :src="$b->image" :alt="$b->full_name.($b->activity ? ' – '.$b->activity->tr('name') : '')" sizes="(max-width: 700px) 100vw, (max-width: 1100px) 50vw, 33vw" />
                            @else
                                <x-icon :name="$b->activity?->icon ?? 'wheel'" size="90" />
                            @endif
                            @if ($b->activity)<span class="bike-chip" style="--c: {{ $b->activity->color }}"><x-icon :name="$b->activity->icon" size="16" />{{ $b->activity->tr('name') }}</span>@endif
                        </div>
                        <div class="rent-body">
                            <p class="rent-brand">{{ $b->brand?->name }}@if ($b->model_year) · {{ $b->model_year }}@endif</p>
                            <h2>{{ $b->name }}</h2>
                            @if ($b->tr('description'))<p class="rent-desc">{{ $b->tr('description') }}</p>@endif
                            <dl class="rent-facts">
                                @foreach ($b->facts() as $label => $value)<div><dt>{{ __($label) }}</dt><dd>{{ $value }}</dd></div>@endforeach
                            </dl>
                            @if (count($b->specs ?? []))
                                <details class="rent-specs"><summary>{{ __('Full specification') }}</summary>
                                    <table class="spec-table"><tbody>@foreach ($b->specs as [$k, $v])<tr><th scope="row">{{ __($k) }}</th><td>{{ $v }}</td></tr>@endforeach</tbody></table>
                                </details>
                            @endif
                            <div class="rent-foot">
                                <p class="rent-price">@if ($b->price_day)<strong>{{ $money($b->price_day) }}</strong> <span>{{ __('per day') }}</span>@else<strong>{{ __('On request') }}</strong>@endif
                                    @if ($b->deposit)<small>{{ __('Deposit :amount', ['amount' => $money($b->deposit)]) }}</small>@endif</p>
                                <a class="btn btn-saffron" href="{{ route('contact', ['bike' => $b->slug]) }}">{{ __('Reserve this bike') }}</a>
                            </div>
                        </div>
                    </article>
                @endforeach
            </div>
            <p class="rent-note">{{ __('Helmet, repair kit and bike set-up are included with every rental bike. Specifications follow the manufacturer for the model year shown; the bike you collect may differ slightly in small parts.') }}</p>
        @endif

        @if ($items->count())
            <h2 class="rent-h2">{{ __('Equipment you can rent') }}</h2>
            <p>{{ __('Add any of these when you book a tour, or ask for them with a bike rental.') }}</p>
            <div class="rent-items">
                @foreach ($items as $cat => $list)
                    <div class="rent-cat">
                        <h3>{{ __(\App\Models\RentalItem::CATEGORIES[$cat] ?? ucfirst($cat)) }}</h3>
                        <ul>@foreach ($list as $it)<li><span>{{ $it->tr('name') }}</span><span class="rent-pr">{{ $money($it->price) }} <small>{{ $it->unit === 'day' ? __('per day') : __('per trip') }}</small></span></li>@endforeach</ul>
                    </div>
                @endforeach
            </div>
        @endif
    </div>
</section>
@endsection
@push('scripts')
<script>
document.querySelectorAll('[data-type]').forEach((b) => b.tagName === 'BUTTON' && b.addEventListener('click', () => {
    document.querySelectorAll('.album-filter button').forEach((x) => x.classList.toggle('is-on', x === b));
    document.querySelectorAll('#rent-grid .rent-card').forEach((c) => { c.hidden = !!b.dataset.type && c.dataset.type !== b.dataset.type; });
}));
</script>
@endpush
