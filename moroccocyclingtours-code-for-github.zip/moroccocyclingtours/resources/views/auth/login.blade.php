<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Staff login | {{ config('site.name') }}</title>
    <link rel="icon" href="{{ asset('img/favicon.svg') }}" type="image/svg+xml">
    <link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Marcellus&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ \App\Support\Asset::v('css/admin.css') }}">
</head>
<body class="login-page">
    <main class="login-card">
        <x-logo :height="124" class="login-logo" />
        <h1>Staff login</h1>
        <p class="muted">Manage tours, bike types and bookings.</p>
        <form method="post" action="{{ url('/login') }}">
            @csrf
            <div class="field">
                <label for="email">E-mail</label>
                <input id="email" type="email" name="email" value="{{ old('email') }}" autocomplete="username" required autofocus>
                @error('email')<p class="err">{{ $message }}</p>@enderror
            </div>
            <div class="field">
                <label for="password">Password</label>
                <input id="password" type="password" name="password" autocomplete="current-password" required>
            </div>
            <label class="check"><input type="checkbox" name="remember"> Keep me signed in</label>
            <button class="btn btn-primary btn-block" type="submit">Log in</button>
        </form>
        <a class="back" href="{{ route('home') }}"><x-icon name="arrow-left" size="16" /> Back to the website</a>
    </main>
</body>
</html>
