@extends('layouts.admin')
@section('title', 'Dashboard')
@section('heading', 'Dashboard')
@section('actions')
    <a class="btn btn-primary" href="{{ route('admin.tours.create') }}"><x-icon name="plus" size="18" /> New tour</a>
@endsection

@section('content')
<div class="stats">
    <a class="stat" href="{{ route('admin.content.index', ['leads', 'status' => 'new']) }}"><x-icon name="mail" size="26" /><span class="stat-n">{{ $stats['leads'] }}</span><span>New enquiries</span></a>
    <a class="stat" href="{{ route('admin.calendar') }}"><x-icon name="calendar" size="26" /><span class="stat-n">{{ $stats['departures'] }}</span><span>Upcoming fixed departures</span></a>
    <a class="stat" href="{{ route('admin.bookings.index', ['status' => 'pending']) }}"><x-icon name="pump" size="26" /><span class="stat-n">{{ $stats['pending'] }}</span><span>Requests to confirm</span></a>
    <a class="stat" href="{{ route('admin.bookings.index', ['when' => 'upcoming']) }}"><x-icon name="calendar" size="26" /><span class="stat-n">{{ $stats['upcoming'] }}</span><span>Upcoming bookings</span></a>
    <div class="stat"><x-icon name="helmet" size="26" /><span class="stat-n">{{ $stats['riders'] }}</span><span>Confirmed riders this month</span></div>
    <div class="stat"><x-icon name="tag" size="26" /><span class="stat-n">{{ config('site.currency') }}{{ number_format($stats['revenue']) }}</span><span>Confirmed revenue this month</span></div>
    <a class="stat" href="{{ route('admin.tours.index') }}"><x-icon name="map" size="26" /><span class="stat-n">{{ $stats['tours'] }}</span><span>Published tours @if ($stats['drafts'])({{ $stats['drafts'] }} drafts)@endif</span></a>
</div>

<div class="dash-grid">
    <section class="panel">
        <header class="panel-head"><h2>Next rides</h2><a href="{{ route('admin.bookings.index', ['when' => 'upcoming']) }}">All upcoming</a></header>
        @if ($upcoming->isEmpty())
            <p class="empty-line">No upcoming bookings yet. New requests from the website appear here.</p>
        @else
            <table class="table">
                <thead><tr><th>Date</th><th>Tour</th><th>Guest</th><th>Riders</th><th>Status</th></tr></thead>
                <tbody>
                @foreach ($upcoming as $b)
                    <tr>
                        <td class="nowrap">{{ $b->tour_date->format('D j M') }}</td>
                        <td><a href="{{ route('admin.bookings.show', $b) }}">{{ $b->tour_title }}</a></td>
                        <td>{{ $b->name }}</td>
                        <td>{{ $b->participants }}</td>
                        <td>@include('admin.partials.status', ['status' => $b->status])</td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        @endif
    </section>

    <section class="panel">
        <header class="panel-head"><h2>Bike types</h2><a href="{{ route('admin.activities.index') }}">Manage</a></header>
        <ul class="type-list">
            @foreach ($byActivity as $a)
                <li style="--c: {{ $a->color }}">
                    <span class="type-ico"><x-icon :name="$a->icon" size="26" /></span>
                    <span class="type-name">{{ $a->name }}</span>
                    <span class="type-n">{{ $a->tours_count }} tours</span>
                    <span class="type-n">{{ $a->bookings_count }} bookings</span>
                </li>
            @endforeach
        </ul>
    </section>

    @if ($postsWithNotes->count() || $postsDue->count())
    <section class="panel">
        <header class="panel-head"><h2>Blog to-do</h2><a href="{{ route('admin.content.index', 'posts') }}">All posts</a></header>
        <ul class="latest">
            @foreach ($postsWithNotes as $p)
                <li><a href="{{ route('admin.content.edit', ['posts', $p->id]) }}"><strong>{{ $p->title }}</strong></a><span class="muted">{{ count($p->notes()) }} guide note(s) to complete: add your own story, photos and author</span></li>
            @endforeach
            @foreach ($postsDue as $p)
                <li><a href="{{ route('admin.content.edit', ['posts', $p->id]) }}"><strong>{{ $p->title }}</strong></a><span class="muted">Not updated for 12 months: check prices, photos and dates</span></li>
            @endforeach
        </ul>
    </section>
    @endif

    <section class="panel">
        <header class="panel-head"><h2>Group pricing</h2><a href="{{ route('admin.pricing') }}">Edit</a></header>
        @if ($pricing['enabled'])
            <ul class="pricing-summary">
                @foreach (\App\Support\GroupPricing::tiers() as $t)
                    <li><span>{{ $t['min'] === $t['max'] ? $t['min'] : $t['min'].'–'.$t['max'] }} people</span>
                        <strong @class(['minus' => $t['mode'] === 'price' && $t['adjust'] < 0, 'plus' => $t['mode'] === 'price' && $t['adjust'] > 0])>{{ $t['mode'] === 'request' ? 'On request' : ($t['adjust'] > 0 ? '+' : '').$t['adjust'].'%' }}</strong></li>
                @endforeach
            </ul>
        @else
            <p class="muted">Switched off: tours show their base price for every group size.</p>
        @endif
    </section>

    <section class="panel">
        <header class="panel-head"><h2>Image optimisation</h2></header>
        <ul class="img-status">
            <li @class(['ok' => $images['avif']])><x-icon :name="$images['avif'] ? 'check' : 'x'" size="18" /> AVIF @if ($images['avif'])<small>via {{ $images['avif_engine'] }}</small>@else<small>not available</small>@endif</li>
            <li @class(['ok' => $images['webp']])><x-icon :name="$images['webp'] ? 'check' : 'x'" size="18" /> WebP</li>
        </ul>
        <p class="hint">Every photo uploaded in the admin is saved as {{ implode(' + ', array_map('strtoupper', $images['formats'])) ?: '—' }} in 4 sizes. Visitors get AVIF when their browser supports it, WebP otherwise.
            @unless ($images['avif']) To add AVIF, install libavif (<code>avifenc</code>) on the server or use a PHP build with AVIF support, then run <code>php artisan images:optimize</code>.@endunless</p>
    </section>

    <section class="panel">
        <header class="panel-head"><h2>Latest requests</h2><a href="{{ route('admin.bookings.index') }}">All bookings</a></header>
        <ul class="latest">
            @forelse ($latest as $b)
                <li>
                    <a href="{{ route('admin.bookings.show', $b) }}"><strong>{{ $b->name }}</strong> · {{ $b->tour_title }}</a>
                    <span class="muted">{{ $b->created_at->diffForHumans() }}</span>
                    @include('admin.partials.status', ['status' => $b->status])
                </li>
            @empty
                <li class="empty-line">Nothing yet.</li>
            @endforelse
        </ul>
    </section>
</div>
@endsection
