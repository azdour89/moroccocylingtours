<span class="status status-{{ $status }}">{{ \App\Models\Booking::STATUSES[$status] ?? ucfirst($status) }}</span>
