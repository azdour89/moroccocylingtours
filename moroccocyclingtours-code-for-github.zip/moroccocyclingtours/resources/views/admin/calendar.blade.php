@extends('layouts.admin')
@section('title', 'Tour calendar')
@section('heading', 'Tour calendar · '.$month->format('F Y'))
@section('actions')
    <a class="btn btn-outline" href="{{ route('admin.calendar', ['month' => $month->subMonth()->format('Y-m')]) }}">← {{ $month->subMonth()->format('M') }}</a>
    <a class="btn btn-outline" href="{{ route('admin.calendar') }}">Today</a>
    <a class="btn btn-outline" href="{{ route('admin.calendar', ['month' => $month->addMonth()->format('Y-m')]) }}">{{ $month->addMonth()->format('M') }} →</a>
    <a class="btn btn-outline" href="{{ route('admin.content.index', 'departures') }}"><x-icon name="list" size="18" /> List</a>
    <a class="btn btn-primary" href="{{ route('admin.content.create', 'departures') }}"><x-icon name="plus" size="18" /> New departure</a>
@endsection
@section('content')
<p class="intro">Fixed departures are shown in colour (by bike type); booking requests show as a count. Click a departure to edit it.</p>
<div class="cal">
    @foreach (['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] as $d)<div class="cal-head">{{ $d }}</div>@endforeach
    @foreach ($days as $key => $day)
        <div @class(['cal-day', 'out' => ! $day['in_month'], 'today' => $day['date']->isToday()])>
            <span class="cal-num">{{ $day['date']->day }}</span>
            @foreach ($day['departures'] as $d)
                <a class="cal-dep dep-{{ $d->status }}" style="--c: {{ $d->tour?->activity->color ?? '#0E7A5F' }}" href="{{ route('admin.content.edit', ['departures', $d->id]) }}"
                   title="{{ $d->tour?->title }} · {{ \App\Models\Departure::STATUSES[$d->status] ?? $d->status }}">
                    {{ \Illuminate\Support\Str::limit($d->tour?->title ?? 'Tour', 26) }}@if ($d->spots) <small>{{ $d->spots_left }}/{{ $d->spots }}</small>@endif
                </a>
            @endforeach
            @if ($day['bookings']->count())
                <a class="cal-book" href="{{ route('admin.bookings.index', ['q' => '']) }}">{{ $day['bookings']->count() }} booking{{ $day['bookings']->count() > 1 ? 's' : '' }} · {{ $day['bookings']->sum('participants') }} riders</a>
            @endif
        </div>
    @endforeach
</div>
@endsection
