{{-- One form field. Vars: $name, $f, $value, $inputName, $id, $readonly --}}
@php $ro = $readonly ?? false; if (($f['type'] ?? '') === 'faqs' && is_array($value)) { $value = \App\Models\Post::faqsToText($value); } if (($f['type'] ?? '') === 'specs' && is_array($value)) { $value = \App\Models\RentalBike::specsToText($value); } @endphp
<div @class(['field', 'half' => $f['half'] ?? false])>
    @if ($f['type'] === 'checkbox')
        <label class="check"><input type="checkbox" name="{{ $inputName }}" value="1" @checked($value) @disabled($ro)> {{ $f['label'] }}</label>
    @else
        <label for="{{ $id }}">{{ $f['label'] }}</label>
        @switch($f['type'])
            @case('textarea') @case('markdown') @case('faqs') @case('specs')
                <textarea id="{{ $id }}" name="{{ $inputName }}" rows="{{ $f['rows'] ?? 4 }}" @readonly($ro) @class(['mono' => in_array($f['type'], ['markdown', 'faqs', 'specs'])])>{{ $value }}</textarea>
                @break
            @case('select')
                <select id="{{ $id }}" name="{{ $inputName }}" @disabled($ro)>
                    @if (! empty($f['empty']) || ! str_contains($f['rules'] ?? '', 'required'))<option value="">{{ $f['empty'] ?? '—' }}</option>@endif
                    @foreach (\App\Admin\Resources::options($f['options']) as $k => $v)<option value="{{ $k }}" @selected((string) $value === (string) $k)>{{ $v }}</option>@endforeach
                </select>
                @break
            @case('image') @case('file')
                @if ($value)
                    <div class="file-current">
                        @if ($f['type'] === 'image')<img class="preview" src="{{ \App\Support\Media::sized($value, 800) }}" alt="">@else<a href="{{ \App\Support\Media::url($value) }}" target="_blank">{{ basename($value) }}</a>@endif
                        @if (($f['rules'] ?? '') === 'required_without:id')
                            <span class="hint">Required: choose a new file below to replace it.</span>
                        @else
                            <label class="check"><input type="checkbox" name="remove_{{ $name }}" value="1"> Remove</label>
                        @endif
                    </div>
                @endif
                <input id="{{ $id }}" type="file" name="{{ $inputName }}" @if ($f['type'] === 'image') accept="image/*" @elseif (! empty($f['accept'])) accept="{{ $f['accept'] }}" @endif>
                @if (! empty($f['hint']))<p class="hint">{{ $f['hint'] }}</p>@endif
                @if ($f['type'] === 'image')<p class="hint">{{ \App\Admin\ImageHint::text() }}</p>@endif
                @break
            @case('date')
                <input id="{{ $id }}" type="date" name="{{ $inputName }}" value="{{ $value ? \Illuminate\Support\Carbon::parse($value)->toDateString() : '' }}" @readonly($ro)>
                @break
            @case('datetime')
                <input id="{{ $id }}" type="datetime-local" name="{{ $inputName }}" value="{{ $value ? \Illuminate\Support\Carbon::parse($value)->format('Y-m-d\TH:i') : '' }}" @readonly($ro)>
                @break
            @case('number')
                <input id="{{ $id }}" type="number" step="{{ $f['step'] ?? 'any' }}" name="{{ $inputName }}" value="{{ $value }}" @readonly($ro)>
                @break
            @case('color')
                <input id="{{ $id }}" type="color" name="{{ $inputName }}" value="{{ $value ?: ($f['default'] ?? '#0E7A5F') }}">
                @break
            @case('slug')
                <div class="slug-input"><span>/</span><input id="{{ $id }}" name="{{ $inputName }}" value="{{ $value }}" placeholder="made from the {{ $f['from'] ?? 'title' }}"></div>
                @break
            @default
                <input id="{{ $id }}" type="{{ $f['type'] === 'url' ? 'text' : 'text' }}" name="{{ $inputName }}" value="{{ $value }}" @readonly($ro)
                       @if (str_contains($f['rules'] ?? '', 'max:')) maxlength="{{ \Illuminate\Support\Str::after(collect(explode('|', $f['rules']))->first(fn ($x) => str_starts_with($x, 'max:')) ?? 'max:', 'max:') }}" @endif>
        @endswitch
        @if (! empty($f['help']))<p class="hint">{{ $f['help'] }}</p>@endif
    @endif
    @error($name)<p class="err">{{ $message }}</p>@enderror
</div>
