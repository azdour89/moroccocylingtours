@extends('layouts.admin')
@section('title', $r['label'])
@section('heading', $r['label'])
@section('actions')
    @if (! empty($r['calendar']))<a class="btn btn-outline" href="{{ route('admin.calendar') }}"><x-icon name="calendar" size="18" /> Calendar view</a>@endif
    @if (($r['create'] ?? true) !== false)<a class="btn btn-primary" href="{{ route('admin.content.create', $r['key']) }}"><x-icon name="plus" size="18" /> New {{ $r['singular'] }}</a>@endif
@endsection
@section('content')
@if (! empty($r['help']))<p class="intro">{{ $r['help'] }}</p>@endif
<form class="toolbar" method="get">
    @if (! empty($r['search']))<div class="input-icon"><x-icon name="search" size="18" /><input type="search" name="q" value="{{ request('q') }}" placeholder="Search"></div>@endif
    @foreach ($r['filters'] ?? [] as $f)
        @php $field = $r['fields'][$f] ?? ['type' => 'text', 'label' => $f]; @endphp
        @if ($field['type'] === 'select')
            <select name="{{ $f }}" onchange="this.form.submit()">
                <option value="">All: {{ strtolower($field['label']) }}</option>
                @foreach (\App\Admin\Resources::options($field['options']) as $k => $v)<option value="{{ $k }}" @selected(request($f) == $k)>{{ $v }}</option>@endforeach
            </select>
        @else
            <input name="{{ $f }}" value="{{ request($f) }}" placeholder="{{ $field['label'] }}">
        @endif
    @endforeach
    @if (! empty($r['search']) || ! empty($r['filters']))<button class="btn btn-outline" type="submit">Filter</button>@endif
</form>
<div class="panel">
    <table class="table">
        <thead><tr>@foreach ($r['columns'] as $c)<th>{{ $r['fields'][$c]['label'] ?? ucfirst(str_replace('_', ' ', $c)) }}</th>@endforeach<th></th></tr></thead>
        <tbody>
        @forelse ($items as $item)
            <tr>
                @foreach ($r['columns'] as $i => $c)
                    @php $f = $r['fields'][$c] ?? ['type' => str_ends_with($c, '_at') ? 'datetime' : 'text']; $v = $item->{$c}; @endphp
                    <td @class(['thumb' => $f['type'] === 'image'])>
                        @if ($f['type'] === 'image')
                            @if ($v)<img src="{{ \App\Support\Media::sized($v, 480) }}" alt="">@else<span class="thumb-ph" style="--c:#B8C2BF"><x-icon name="eye" size="18" /></span>@endif
                        @elseif ($f['type'] === 'checkbox')
                            <span @class(['switch', 'on' => $v])>{{ $v ? 'Yes' : 'No' }}</span>
                        @elseif ($f['type'] === 'select')
                            {{ \App\Admin\Resources::options($f['options'])[$v] ?? $v }}
                        @elseif (in_array($f['type'], ['date', 'datetime']) && $v)
                            {{ \Illuminate\Support\Carbon::parse($v)->format($f['type'] === 'date' ? 'D j M Y' : 'j M Y, H:i') }}
                        @else
                            @if ($i === 0 || ($i === 1 && $r['fields'][$r['columns'][0]]['type'] === 'image'))
                                <a class="strong" href="{{ route('admin.content.edit', [$r['key'], $item->id]) }}">{{ \Illuminate\Support\Str::limit((string) $v, 70) ?: '(untitled)' }}</a>
                            @else
                                {{ \Illuminate\Support\Str::limit((string) $v, 60) }}
                            @endif
                        @endif
                    </td>
                @endforeach
                <td class="row-actions"><a href="{{ route('admin.content.edit', [$r['key'], $item->id]) }}" title="Edit"><x-icon name="edit" size="18" /></a></td>
            </tr>
        @empty
            <tr><td colspan="{{ count($r['columns']) + 1 }}" class="empty-line">Nothing here yet.@if (($r['create'] ?? true) !== false) <a href="{{ route('admin.content.create', $r['key']) }}">Add the first {{ $r['singular'] }}</a>.@endif</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
{{ $items->links('admin.partials.pagination') }}
@endsection
