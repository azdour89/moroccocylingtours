@extends('layouts.admin')
@php $editing = $item->exists; $trFields = array_filter($r['fields'], fn ($f) => $f['tr'] ?? false); $first = array_key_first($r['fields']); @endphp
@section('title', ($editing ? 'Edit ' : 'New ').$r['singular'])
@section('heading', $editing ? (\Illuminate\Support\Str::limit((string) ($item->title ?? $item->name ?? $item->question ?? $item->caption ?? $item->email ?? ucfirst($r['singular'])), 60) ?: ucfirst($r['singular'])) : 'New '.$r['singular'])
@section('back', route('admin.content.index', $r['key']))
@push('head')
    @if (! empty($r['map']))<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">@endif
@endpush
@section('content')
@if (! empty($r['help']))<p class="intro">{{ $r['help'] }}</p>@endif
<form method="post" enctype="multipart/form-data" class="content-form"
      action="{{ $editing ? route('admin.content.update', [$r['key'], $item->id]) : route('admin.content.store', $r['key']) }}">
    @csrf
    @if ($editing) @method('put') <input type="hidden" name="id" value="{{ $item->id }}"> @endif
    <div class="form-grid">
        <div class="form-main">
            <fieldset class="panel">
                <legend>{{ ucfirst($r['singular']) }}@if ($trFields) <span class="muted">(English)</span>@endif</legend>
                <div class="field-grid">
                    @foreach ($r['fields'] as $name => $f)
                        @if (! in_array($f['type'], ['checkbox'], true) || ($f['readonly'] ?? false))
                            @include('admin.content._field', ['name' => $name, 'f' => $f, 'value' => old($name, $item->{$name}), 'inputName' => $name, 'id' => 'f-'.$name, 'readonly' => $f['readonly'] ?? false])
                        @endif
                    @endforeach
                </div>
                @if (! empty($r['map']))
                    <div id="point-map" class="picker-map"></div>
                    <p class="hint">Click the map to set the latitude and longitude.</p>
                @endif
            </fieldset>

            @if ($trFields)
                <fieldset class="panel">
                    <legend>Translations</legend>
                    <p class="hint">Empty fields use the English text on the website.</p>
                    @foreach (\App\Support\Locale::translatable() as $code => $langName)
                        @php $done = filled($item->trRaw($code, array_key_first($trFields))); @endphp
                        <details class="tr-lang" @if ($errors->has("translations.$code.*")) open @endif>
                            <summary><span class="lang-dot {{ $done ? 'on' : '' }}">{{ strtoupper($code) }}</span> {{ $langName }} <span class="muted">{{ $done ? '· translated' : '· uses English' }}</span></summary>
                            <div class="tr-body field-grid" lang="{{ $code }}">
                                @foreach ($trFields as $name => $f)
                                    @include('admin.content._field', ['name' => "translations.$code.$name", 'f' => array_merge($f, ['half' => $f['half'] ?? false, 'help' => null]), 'value' => old("translations.$code.$name", $item->trRaw($code, $name)), 'inputName' => "translations[$code][$name]", 'id' => "tr-$code-$name"])
                                @endforeach
                            </div>
                        </details>
                    @endforeach
                </fieldset>
            @endif
        </div>
        <div class="form-side">
            <fieldset class="panel sticky">
                <legend>Save</legend>
                @foreach ($r['fields'] as $name => $f)
                    @if ($f['type'] === 'checkbox' && ! ($f['readonly'] ?? false))
                        @include('admin.content._field', ['name' => $name, 'f' => $f, 'value' => old($name, $item->{$name} ?? ($f['default'] ?? false)), 'inputName' => $name, 'id' => 'f-'.$name])
                    @endif
                @endforeach
                <button class="btn btn-primary btn-block" type="submit">{{ $editing ? 'Save' : 'Create' }}</button>
                @if ($editing && $item->updated_at)<p class="hint">Last saved {{ $item->updated_at->diffForHumans() }}</p>@endif
            </fieldset>
            @if (! empty($r['side_view']) && $editing)
                @include($r['side_view'], ['item' => $item])
            @endif
        </div>
    </div>
</form>
@if ($editing)
    <form method="post" action="{{ route('admin.content.destroy', [$r['key'], $item->id]) }}" class="danger-zone" onsubmit="return confirm('Delete this {{ $r['singular'] }}?')">
        @csrf @method('delete')
        <button class="btn btn-danger" type="submit"><x-icon name="trash" size="18" /> Delete {{ $r['singular'] }}</button>
    </form>
@endif
@endsection
@push('scripts')
@if (! empty($r['map']))
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
    <script src="{{ \App\Support\Asset::v('js/maps.js') }}"></script>
    <script>
    (function () {
        const lat = document.getElementById('f-latitude'), lng = document.getElementById('f-longitude');
        const map = MCT.base('point-map', { scroll: true }); let m = null;
        const set = (a, b, pan) => { lat.value = (+a).toFixed(6); lng.value = (+b).toFixed(6); if (!m) m = L.marker([a, b], { icon: MCT.pin('#6B4E9B'), draggable: true }).addTo(map).on('dragend', (e) => set(e.target.getLatLng().lat, e.target.getLatLng().lng)); else m.setLatLng([a, b]); if (pan) map.setView([a, b], 10); };
        if (lat.value && lng.value) set(lat.value, lng.value, true);
        map.on('click', (e) => set(e.latlng.lat, e.latlng.lng));
    })();
    </script>
@endif
@endpush
