@extends('layouts.admin')
@section('title', 'Group pricing')
@section('heading', 'Group pricing')
@section('content')
<p class="intro">Each tour has a <strong>base price per person</strong> (set on the tour). These rules adjust it by group size and apply to every tour.
Use a negative number for a discount (−15 = 15% cheaper) and a positive number for a supplement (10 = 10% more). Choose “On request” to hide the price and ask for a quote.</p>

<form method="post" action="{{ route('admin.pricing.update') }}" id="pricing-form">
    @csrf @method('put')
    <div class="form-grid">
        <div class="form-main">
            <fieldset class="panel">
                <legend>Group sizes</legend>
                <table class="table pricing-table">
                    <thead><tr><th>From (people)</th><th>To (people)</th><th>Price</th><th>Adjustment %</th><th>Example on €1,000</th><th></th></tr></thead>
                    <tbody id="tier-rows">
                    @foreach (old('tiers', $config['tiers']) as $i => $t)
                        <tr class="tier-row">
                            <td><input type="number" min="1" name="tiers[{{ $i }}][min]" value="{{ $t['min'] }}" required></td>
                            <td><input type="number" min="1" name="tiers[{{ $i }}][max]" value="{{ $t['max'] }}" required></td>
                            <td><select name="tiers[{{ $i }}][mode]">
                                <option value="price" @selected(($t['mode'] ?? 'price') === 'price')>Adjust base price</option>
                                <option value="request" @selected(($t['mode'] ?? '') === 'request')>On request</option>
                            </select></td>
                            <td><input type="number" step="0.5" min="-90" max="300" name="tiers[{{ $i }}][adjust]" value="{{ $t['adjust'] ?? 0 }}"></td>
                            <td class="example muted">–</td>
                            <td class="row-actions"><button type="button" class="remove-row" title="Remove row"><x-icon name="trash" size="18" /></button></td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
                @foreach ($errors->get('tiers.*') as $msgs)@foreach ($msgs as $m)<p class="err">{{ $m }}</p>@endforeach @endforeach
                @if (! empty($gaps))<p class="err">No row covers {{ \App\Support\GroupPricing::gapText($gaps) }} {{ \Illuminate\Support\Str::plural('person', 2) }}: groups of that size see “price on request”. Adjust the rows if that is not what you want.</p>@endif
                <button type="button" class="btn btn-outline btn-sm" id="add-row"><x-icon name="plus" size="16" /> Add a group size</button>
                <p class="hint">Groups larger than the last row see “please ask us for a quote”. Bookings for “on request” sizes arrive with a total of 0 so you can reply with a personal quote.</p>
            </fieldset>

            <fieldset class="panel">
                <legend>Preview with your tours</legend>
                <div class="field half"><label for="preview-tour">Tour</label>
                    <select id="preview-tour">
                        <option value="1000">Example: base price €1,000</option>
                        @foreach ($tours as $t)<option value="{{ $t->price }}">{{ $t->title }} (base {{ \App\Models\Tour::money($t->price) }})</option>@endforeach
                    </select>
                </div>
                <table class="table" id="preview"><thead><tr><th>Group size</th><th>Price per person</th><th>Total for the largest group</th></tr></thead><tbody></tbody></table>
            </fieldset>
        </div>
        <div class="form-side">
            <fieldset class="panel sticky">
                <legend>Settings</legend>
                <label class="check"><input type="checkbox" name="enabled" value="1" @checked(old('enabled', $config['enabled']))> Use group pricing on all tours</label>
                <p class="hint">When switched off, tours show their base price for any group size.</p>
                <div class="field"><label for="rounding">Round prices to the nearest</label>
                    <select id="rounding" name="rounding">
                        @foreach ([1 => '€1', 5 => '€5', 10 => '€10'] as $v => $l)<option value="{{ $v }}" @selected((int) old('rounding', $config['rounding']) === $v)>{{ $l }}</option>@endforeach
                    </select></div>
                <button class="btn btn-primary btn-block" type="submit">Save group pricing</button>
                <button class="btn btn-outline btn-block mt-s" type="button" id="reset-defaults">Reset to the default rules</button>
            </fieldset>
        </div>
    </div>
</form>
<template id="row-tpl">
    <tr class="tier-row">
        <td><input type="number" min="1" data-name="min" required></td>
        <td><input type="number" min="1" data-name="max" required></td>
        <td><select data-name="mode"><option value="price">Adjust base price</option><option value="request">On request</option></select></td>
        <td><input type="number" step="0.5" min="-90" max="300" data-name="adjust" value="0"></td>
        <td class="example muted">–</td>
        <td class="row-actions"><button type="button" class="remove-row" title="Remove row"><x-icon name="trash" size="18" /></button></td>
    </tr>
</template>
@endsection
@push('scripts')
<script>
(function () {
    const body = document.getElementById('tier-rows'), tpl = document.getElementById('row-tpl');
    const rounding = document.getElementById('rounding'), prevSel = document.getElementById('preview-tour');
    const defaults = @json(\App\Support\GroupPricing::defaults()['tiers']);
    const money = (v) => '€' + Math.round(v).toLocaleString('en');
    const renumber = () => body.querySelectorAll('.tier-row').forEach((tr, i) => tr.querySelectorAll('[name], [data-name]').forEach((el) => {
        const f = el.dataset.name || el.name.match(/\]\[(\w+)\]$/)[1]; el.dataset.name = f; el.name = `tiers[${i}][${f}]`;
    }));
    const rows = () => [...body.querySelectorAll('.tier-row')].map((tr) => ({
        tr, min: +tr.querySelector('[data-name=min]').value, max: +tr.querySelector('[data-name=max]').value,
        mode: tr.querySelector('[data-name=mode]').value, adjust: +tr.querySelector('[data-name=adjust]').value || 0,
    }));
    const price = (base, r) => { const step = +rounding.value || 1; return r.mode === 'request' ? null : Math.round(base * (1 + r.adjust / 100) / step) * step; };
    const update = () => {
        renumber();
        const base = +prevSel.value || 1000, tbody = document.querySelector('#preview tbody');
        tbody.innerHTML = '';
        rows().sort((a, b) => a.min - b.min).forEach((r) => {
            const p1 = price(1000, r), p = price(base, r);
            r.tr.querySelector('.example').textContent = p1 === null ? 'On request' : money(p1) + ' pp';
            r.tr.querySelector('[data-name=adjust]').disabled = r.mode === 'request';
            const label = r.min === r.max ? `${r.min} people` : `${r.min}–${r.max} people`;
            tbody.insertAdjacentHTML('beforeend', `<tr><td>${label}</td><td>${p === null ? 'On request' : money(p)}</td><td>${p === null ? '–' : money(p * r.max) + ' (' + r.max + ' people)'}</td></tr>`);
        });
    };
    const addRow = (t) => {
        const tr = tpl.content.firstElementChild.cloneNode(true); body.appendChild(tr);
        if (t) { tr.querySelector('[data-name=min]').value = t.min; tr.querySelector('[data-name=max]').value = t.max; tr.querySelector('[data-name=mode]').value = t.mode; tr.querySelector('[data-name=adjust]').value = t.adjust; }
        else { const last = rows().slice(-2, -1)[0]; if (last) { tr.querySelector('[data-name=min]').value = last.max + 1; tr.querySelector('[data-name=max]').value = last.max + 5; } }
        update();
    };
    document.getElementById('add-row').addEventListener('click', () => addRow());
    document.getElementById('reset-defaults').addEventListener('click', () => { if (confirm('Replace the rows with the default rules? (not saved until you click Save)')) { body.innerHTML = ''; defaults.forEach(addRow); } });
    body.addEventListener('click', (e) => { const b = e.target.closest('.remove-row'); if (b && body.querySelectorAll('.tier-row').length > 1) { b.closest('tr').remove(); update(); } });
    body.addEventListener('input', update); body.addEventListener('change', update);
    rounding.addEventListener('change', update); prevSel.addEventListener('change', update);
    update();
})();
</script>
@endpush
