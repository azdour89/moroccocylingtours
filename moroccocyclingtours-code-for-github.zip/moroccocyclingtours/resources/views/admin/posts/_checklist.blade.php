{{-- Publishing checklist (content guide), per language --}}
@php
    $code = request('check', 'en');
    $groups = \App\Support\PostSeo::check($item, $code);
    [$ok, $total] = \App\Support\PostSeo::score($groups);
@endphp
<fieldset class="panel checklist">
    <legend>Publishing checklist</legend>
    <div class="check-langs">
        @foreach (\App\Support\Locale::all() as $c => $n)
            <a href="{{ request()->fullUrlWithQuery(['check' => $c]) }}" @class(['lang-dot', 'on' => $c === 'en' || filled($item->trRaw($c, 'body')), 'current' => $c === $code])>{{ strtoupper($c) }}</a>
        @endforeach
    </div>
    <p class="check-score"><strong>{{ $ok }}/{{ $total }}</strong> done @if ($item->is_published && $item->exists)· <a href="{{ route('blog.show', ['locale' => $code, 'post' => $item->slug]) }}" target="_blank" rel="noopener">view {{ strtoupper($code) }} page</a>@endif</p>
    @foreach ($groups as $title => $items)
        <h4>{{ $title }}</h4>
        <ul>
            @foreach ($items as [$label, $pass, $hint])
                <li @class(['ok' => $pass])><x-icon :name="$pass ? 'check' : 'x'" size="15" /><span>{{ $label }}@if ($hint)<small>{{ $hint }}</small>@endif</span></li>
            @endforeach
        </ul>
    @endforeach
    <h4>After publishing</h4>
    <ul class="manual">
        <li>Link to this post from 1–2 older posts</li>
        <li>Share on social media and your Google Business Profile</li>
        <li>Ask recent happy guests for a Google review</li>
        <li>Check Google Search Console after a few weeks</li>
        <li>Update prices, photos and dates in 12 months (shown on the dashboard)</li>
    </ul>
</fieldset>
