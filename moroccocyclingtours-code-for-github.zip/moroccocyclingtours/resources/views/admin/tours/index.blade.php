@extends('layouts.admin')
@section('title', 'Tours')
@section('heading', 'Tours')
@section('actions')
    <a class="btn btn-primary" href="{{ route('admin.tours.create') }}"><x-icon name="plus" size="18" /> New tour</a>
@endsection

@section('content')
<form class="toolbar" method="get">
    <div class="input-icon"><x-icon name="search" size="18" /><input type="search" name="q" value="{{ request('q') }}" placeholder="Search tours"></div>
    <select name="activity" onchange="this.form.submit()">
        <option value="">All bike types</option>
        @foreach ($activities as $a)<option value="{{ $a->id }}" @selected(request('activity') == $a->id)>{{ $a->name }}</option>@endforeach
    </select>
    <select name="category" onchange="this.form.submit()">
        <option value="">All trip types</option>
        @foreach (\App\Models\Category::orderBy('sort_order')->get() as $c)<option value="{{ $c->slug }}" @selected(request('category') === $c->slug)>{{ $c->name }}</option>@endforeach
    </select>
    <select name="status" onchange="this.form.submit()">
        <option value="">Published and drafts</option>
        <option value="published" @selected(request('status') === 'published')>Published</option>
        <option value="draft" @selected(request('status') === 'draft')>Drafts</option>
    </select>
    <button class="btn btn-outline" type="submit">Filter</button>
</form>

<div class="panel">
    <table class="table table-tours">
        <thead><tr><th></th><th>Tour</th><th>Bike type</th><th>Level</th><th>Price</th><th>Languages</th><th>Bookings</th><th>Status</th><th><span class="sr">Actions</span></th></tr></thead>
        <tbody>
        @forelse ($tours as $t)
            <tr>
                <td class="thumb">
                    @if ($t->image_url)<img src="{{ $t->image_url }}" alt="">@else<span class="thumb-ph" style="--c: {{ $t->activity->color }}"><x-icon :name="$t->activity->icon" size="22" /></span>@endif
                </td>
                <td>
                    <a class="strong" href="{{ route('admin.tours.edit', $t) }}">{{ $t->title }}</a>
                    @if ($t->subtitle)<span class="block">{{ $t->subtitle }}</span>@endif<span class="muted block">{{ $t->category_label }} · {{ $t->region }} · {{ $t->duration_label }}@if ($t->distance_km) · {{ $t->distance_km + 0 }} km @endif @if ($t->is_featured)<span class="tag">Featured</span>@endif</span>
                </td>
                <td><span class="type-pill" style="--c: {{ $t->activity->color }}"><x-icon :name="$t->activity->icon" size="18" />{{ $t->activity->name }}</span></td>
                <td>{{ $t->level_label }}</td>
                <td class="nowrap">{{ $t->price_formatted }}</td>
                <td class="langs">
                    @foreach (\App\Support\Locale::translatable() as $code => $n)
                        <span @class(['lang-dot', 'on' => filled($t->trRaw($code, 'title'))]) title="{{ $n }}: {{ filled($t->trRaw($code, 'title')) ? 'translated' : 'uses English' }}">{{ strtoupper($code) }}</span>
                    @endforeach
                </td>
                <td>{{ $t->bookings_count }}</td>
                <td>
                    <form method="post" action="{{ route('admin.tours.toggle', $t) }}">@csrf @method('patch')
                        <button class="switch {{ $t->is_published ? 'on' : '' }}" type="submit" title="{{ $t->is_published ? 'Move to drafts' : 'Publish' }}">{{ $t->is_published ? 'Published' : 'Draft' }}</button>
                    </form>
                </td>
                <td class="row-actions">
                    @if ($t->is_published)<a href="{{ route('tours.show', ['tour' => $t->slug]) }}" target="_blank" rel="noopener" title="View on website"><x-icon name="eye" size="18" /></a>@endif
                    <a href="{{ route('admin.tours.edit', $t) }}" title="Edit"><x-icon name="edit" size="18" /></a>
                </td>
            </tr>
        @empty
            <tr><td colspan="9" class="empty-line">No tours yet. <a href="{{ route('admin.tours.create') }}">Create your first tour</a>.</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
{{ $tours->links('admin.partials.pagination') }}
@endsection
