@extends('layouts.admin')
@php $editing = $tour->exists; @endphp
@section('title', $editing ? 'Edit '.$tour->title : 'New tour')
@section('heading', $editing ? $tour->title : 'New tour')
@section('back', route('admin.tours.index'))
@section('actions')
    @if ($editing && $tour->is_published)
        <a class="btn btn-outline" href="{{ route('tours.show', ['tour' => $tour->slug]) }}" target="_blank" rel="noopener"><x-icon name="eye" size="18" /> View on website</a>
    @endif
@endsection

@push('head')
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">
@endpush

@section('content')
@php
    $lines = fn ($arr) => implode("\n", $arr ?? []);
    $itin = \App\Http\Controllers\Admin\TourController::itineraryToText($tour->itinerary);
@endphp

<form method="post" enctype="multipart/form-data" class="tour-form"
      action="{{ $editing ? route('admin.tours.update', $tour) : route('admin.tours.store') }}">
    @csrf
    @if ($editing) @method('put') @endif

    <div class="form-grid">
        <div class="form-main">
            <fieldset class="panel">
                <legend>Tour card</legend>
                <p class="hint">These fields make up the tour card on the website: image, title, description, price, bike type and level.</p>
                <div class="field">
                    <label for="title">Title</label>
                    <input id="title" name="title" value="{{ old('title', $tour->title) }}" required maxlength="160">
                    @error('title')<p class="err">{{ $message }}</p>@enderror
                </div>
                <div class="field">
                    <label for="subtitle">Subtitle <span class="muted">(shown under the title and used as the Google description, up to 200 characters)</span></label>
                    <input id="subtitle" name="subtitle" value="{{ old('subtitle', $tour->subtitle) }}" maxlength="200" placeholder="8-day gravel tour from Ait Bougmez to Imilchil">
                    @error('subtitle')<p class="err">{{ $message }}</p>@enderror
                </div>
                <div class="field">
                    <label for="excerpt">Short description <span class="muted">(card text, up to 300 characters)</span></label>
                    <textarea id="excerpt" name="excerpt" rows="3" maxlength="300" required>{{ old('excerpt', $tour->excerpt) }}</textarea>
                    @error('excerpt')<p class="err">{{ $message }}</p>@enderror
                </div>
                <div class="row3">
                    <div class="field">
                        <label for="activity_id">Bike type</label>
                        <select id="activity_id" name="activity_id">
                            <option value="" data-color="#8A5A2B" @selected(! old('activity_id', $tour->activity_id))>No bike (4×4 / culture tour)</option>
                            @foreach ($activities as $a)
                                <option value="{{ $a->id }}" data-color="{{ $a->color }}" @selected(old('activity_id', $tour->activity_id) == $a->id)>{{ $a->name }}</option>
                            @endforeach
                        </select>
                        @error('activity_id')<p class="err">{{ $message }}</p>@enderror
                    </div>
                    <div class="field">
                        <label for="level">Level</label>
                        <select id="level" name="level" required>
                            @foreach (\App\Models\Tour::LEVELS as $k => $label)<option value="{{ $k }}" @selected(old('level', $tour->level) === $k)>{{ $label }}</option>@endforeach
                        </select>
                    </div>
                    <div class="field">
                        <label for="price">Base price per person ({{ config('site.currency') }}, 0 = on request) <a href="{{ route('admin.pricing') }}" class="muted">· adjusted by group size</a></label>
                        <input id="price" name="price" type="number" step="0.01" min="0" value="{{ old('price', $tour->price) }}" required>
                        @error('price')<p class="err">{{ $message }}</p>@enderror
                    </div>
                </div>
                <div class="field">
                    <label for="category">Trip type</label>
                    <select id="category" name="category" required>
                        @foreach (\App\Models\Category::orderBy('sort_order')->get() as $c)<option value="{{ $c->slug }}" @selected(old('category', $tour->category ?? 'day') === $c->slug)>{{ $c->name }}</option>@endforeach
                    </select>
                </div>
                <div class="field">
                    <label for="image">Main image</label>
                    @if ($tour->image_url)<img class="preview" src="{{ $tour->image_url }}" alt="Current main image">@endif
                    <input id="image" name="image" type="file" accept="image/jpeg,image/png,image/webp,image/avif,image/gif">
                    <p class="hint">Landscape photo, at least 1600 px wide. {{ \App\Admin\ImageHint::text() }}</p>
                    @error('image')<p class="err">{{ $message }}</p>@enderror
                </div>
            </fieldset>

            <fieldset class="panel">
                <legend>Tour details</legend>
                <div class="row3">
                    <div class="field"><label for="duration_label">Duration (shown)</label><input id="duration_label" name="duration_label" value="{{ old('duration_label', $tour->duration_label) }}" placeholder="4 hours" required></div>
                    <div class="field"><label for="duration_hours">Duration in hours (for filters)</label><input id="duration_hours" name="duration_hours" type="number" step="0.5" min="0.5" value="{{ old('duration_hours', $tour->duration_hours) }}" required></div>
                    <div class="field"><label for="distance_km">Distance (km)</label><input id="distance_km" name="distance_km" type="number" step="0.1" min="0" value="{{ old('distance_km', $tour->distance_km) }}"></div>
                </div>
                <div class="row3">
                    <div class="field"><label for="elevation_m">Elevation gain (m)</label><input id="elevation_m" name="elevation_m" type="number" min="0" value="{{ old('elevation_m', $tour->elevation_m) }}"></div>
                    <div class="field"><label for="max_altitude_m">Highest point (m)</label><input id="max_altitude_m" name="max_altitude_m" type="number" min="0" value="{{ old('max_altitude_m', $tour->max_altitude_m) }}"></div>
                    <div class="field"><label for="terrain">Terrain</label><input id="terrain" name="terrain" value="{{ old('terrain', $tour->terrain) }}" placeholder="Asphalt, gravel"></div>
                </div>
                <div class="row3">
                    <div class="field"><label for="capacity">Max riders</label><input id="capacity" name="capacity" type="number" min="1" value="{{ old('capacity', $tour->capacity) }}"></div>
                    <div class="field"><label for="min_age">Minimum age</label><input id="min_age" name="min_age" type="number" min="0" value="{{ old('min_age', $tour->min_age) }}"></div>
                    <div class="field"><label for="season">Season</label><input id="season" name="season" value="{{ old('season', $tour->season) }}" placeholder="September to June"></div>
                </div>
                <div class="field">
                    <label for="description">Full description</label>
                    <textarea id="description" name="description" rows="8">{{ old('description', $tour->description) }}</textarea>
                    <p class="hint">Leave a blank line between paragraphs.</p>
                </div>
            </fieldset>

            <fieldset class="panel">
                <legend>Location and route</legend>
                <div class="row2">
                    <div class="field"><label for="region">Region</label><input id="region" name="region" value="{{ old('region', $tour->region) }}" list="regions" required placeholder="High Atlas">
                        <datalist id="regions">@foreach (\App\Models\Tour::distinct()->pluck('region') as $r)<option value="{{ $r }}">@endforeach</datalist>
                        @error('region')<p class="err">{{ $message }}</p>@enderror
                    </div>
                    <div class="field"><label for="start_point">Starting point</label><input id="start_point" name="start_point" value="{{ old('start_point', $tour->start_point) }}" placeholder="Imlil village square"></div>
                </div>
                <div class="map-tools" role="group" aria-label="Map mode">
                    <label class="seg"><input type="radio" name="_mode" value="start" checked> <span><x-icon name="pin" size="16" /> Set start</span></label>
                    <label class="seg"><input type="radio" name="_mode" value="route"> <span><x-icon name="wheel" size="16" /> Draw route</span></label>
                    <button type="button" class="btn btn-outline btn-sm" id="route-undo">Undo last point</button>
                    <button type="button" class="btn btn-outline btn-sm" id="route-clear">Clear route</button>
                    <span class="muted" id="route-count"></span>
                </div>
                <div id="picker-map" class="picker-map"></div>
                <p class="hint">Click the map to place the start pin, then switch to “Draw route” and click along the way. Drag the pin to adjust.</p>
                <div class="row2">
                    <div class="field"><label for="latitude">Latitude</label><input id="latitude" name="latitude" type="number" step="0.000001" value="{{ old('latitude', $tour->latitude) }}"></div>
                    <div class="field"><label for="longitude">Longitude</label><input id="longitude" name="longitude" type="number" step="0.000001" value="{{ old('longitude', $tour->longitude) }}"></div>
                </div>
                <input type="hidden" id="route_json" name="route_json" value="{{ old('route_json', json_encode($tour->route ?? [])) }}">
            </fieldset>

            <fieldset class="panel">
                <legend>Tour page content</legend>
                <p class="hint">One item per line.</p>
                <div class="field"><label for="highlights_text">Highlights</label><textarea id="highlights_text" name="highlights_text" rows="5">{{ old('highlights_text', $lines($tour->highlights)) }}</textarea></div>
                <div class="field"><label for="itinerary_text">Itinerary <span class="muted">(one line each: “09:00 | what happens” or “Day 2 | Asni – Ouirgane | what happens”)</span></label><textarea id="itinerary_text" name="itinerary_text" rows="6" placeholder="09:00 | Pick-up from your riad">{{ old('itinerary_text', $itin) }}</textarea></div>
                <div class="row2">
                    <div class="field"><label for="included_text">Included</label><textarea id="included_text" name="included_text" rows="5">{{ old('included_text', $lines($tour->included)) }}</textarea></div>
                    <div class="field"><label for="not_included_text">Not included</label><textarea id="not_included_text" name="not_included_text" rows="5">{{ old('not_included_text', $lines($tour->not_included)) }}</textarea></div>
                </div>
                <div class="field"><label for="what_to_bring_text">What to bring</label><textarea id="what_to_bring_text" name="what_to_bring_text" rows="4">{{ old('what_to_bring_text', $lines($tour->what_to_bring)) }}</textarea></div>
            </fieldset>

            <fieldset class="panel">
                <legend>Photos &amp; equipment</legend>
                <input type="hidden" name="picks_present" value="1">
                <p class="hint">Tick the gallery photos that belong to this tour. They appear on the tour page under “Photos from this tour”. A photo can belong to several tours; add or edit photos in Website → Gallery.</p>
                @php $picked = $tour->exists ? $tour->photosAll->pluck('id')->all() : []; @endphp
                <div class="pick-grid">
                    @foreach ($galleryPhotos as $gp)
                        <label class="pick" title="{{ $gp->caption }}">
                            <input type="checkbox" name="photos[]" value="{{ $gp->id }}" @checked(in_array($gp->id, old('photos', $picked)))>
                            <img src="{{ \App\Support\Media::sized($gp->image, 480) }}" alt="" loading="lazy">
                            <span>{{ $gp->activity?->name ?? '—' }}@unless($gp->is_published) · hidden @endunless</span>
                        </label>
                    @endforeach
                </div>
                <h3 class="pick-h">Equipment guests can rent for this tour</h3>
                <p class="hint">Items listed for this tour&rsquo;s trip type (“Shown automatically on trip types” in Rentals → Equipment) always appear. Tick more items here to add them to this tour.</p>
                @php $pickedItems = $tour->exists ? $tour->rentalItems->pluck('id')->all() : []; @endphp
                <div class="pick-list">
                    @forelse ($rentalItems as $ri)
                        <label class="check"><input type="checkbox" name="rental_items[]" value="{{ $ri->id }}" @checked(in_array($ri->id, old('rental_items', $pickedItems)))> {{ $ri->name }} <small>· {{ config('site.currency') }}{{ rtrim(rtrim(number_format($ri->price, 2), '0'), '.') }} {{ \App\Models\RentalItem::UNITS[$ri->unit] ?? '' }}</small></label>
                    @empty
                        <p class="hint">No equipment yet. Add items in Rentals → Equipment to rent.</p>
                    @endforelse
                </div>
            </fieldset>

            <fieldset class="panel">
                <legend>Translations</legend>
                <p class="hint">The fields above are the English version. Fill in any language below; empty fields fall back to English on the website.</p>
                @foreach (\App\Support\Locale::translatable() as $code => $langName)
                    @php
                        $tr = fn ($f) => old("translations.$code.$f", $tour->trRaw($code, $f));
                        $trList = fn ($f) => old("translations.$code.{$f}_text", implode("\n", $tour->trRaw($code, $f) ?? []));
                        $trItin = old("translations.$code.itinerary_text", \App\Http\Controllers\Admin\TourController::itineraryToText($tour->trRaw($code, 'itinerary')));
                        $done = filled($tour->trRaw($code, 'title'));
                    @endphp
                    <details class="tr-lang" @if ($errors->has("translations.$code.*")) open @endif>
                        <summary><span class="lang-dot {{ $done ? 'on' : '' }}">{{ strtoupper($code) }}</span> {{ $langName }} <span class="muted">{{ $done ? '· translated' : '· uses English' }}</span></summary>
                        <div class="tr-body" lang="{{ $code }}">
                            <div class="field"><label for="tr-{{ $code }}-title">Title</label><input id="tr-{{ $code }}-title" name="translations[{{ $code }}][title]" value="{{ $tr('title') }}" maxlength="160" placeholder="{{ $tour->title }}"></div>
                            <div class="field"><label for="tr-{{ $code }}-subtitle">Subtitle</label><input id="tr-{{ $code }}-subtitle" name="translations[{{ $code }}][subtitle]" value="{{ $tr('subtitle') }}" maxlength="200" placeholder="{{ $tour->subtitle }}"></div>
                            <div class="field"><label for="tr-{{ $code }}-excerpt">Short description</label><textarea id="tr-{{ $code }}-excerpt" name="translations[{{ $code }}][excerpt]" rows="3" maxlength="300" placeholder="{{ $tour->excerpt }}">{{ $tr('excerpt') }}</textarea></div>
                            <div class="field"><label for="tr-{{ $code }}-description">Full description</label><textarea id="tr-{{ $code }}-description" name="translations[{{ $code }}][description]" rows="6">{{ $tr('description') }}</textarea></div>
                            <div class="row3">
                                <div class="field"><label for="tr-{{ $code }}-duration">Duration (shown)</label><input id="tr-{{ $code }}-duration" name="translations[{{ $code }}][duration_label]" value="{{ $tr('duration_label') }}" placeholder="{{ $tour->duration_label }}"></div>
                                <div class="field"><label for="tr-{{ $code }}-terrain">Terrain</label><input id="tr-{{ $code }}-terrain" name="translations[{{ $code }}][terrain]" value="{{ $tr('terrain') }}" placeholder="{{ $tour->terrain }}"></div>
                                <div class="field"><label for="tr-{{ $code }}-season">Season</label><input id="tr-{{ $code }}-season" name="translations[{{ $code }}][season]" value="{{ $tr('season') }}" placeholder="{{ $tour->season }}"></div>
                            </div>
                            <div class="field"><label for="tr-{{ $code }}-highlights">Highlights <span class="muted">(one per line)</span></label><textarea id="tr-{{ $code }}-highlights" name="translations[{{ $code }}][highlights_text]" rows="4">{{ $trList('highlights') }}</textarea></div>
                            <div class="field"><label for="tr-{{ $code }}-itinerary">Itinerary <span class="muted">(time | what happens)</span></label><textarea id="tr-{{ $code }}-itinerary" name="translations[{{ $code }}][itinerary_text]" rows="5">{{ $trItin }}</textarea></div>
                            <div class="row3">
                                <div class="field"><label for="tr-{{ $code }}-inc">Included</label><textarea id="tr-{{ $code }}-inc" name="translations[{{ $code }}][included_text]" rows="5">{{ $trList('included') }}</textarea></div>
                                <div class="field"><label for="tr-{{ $code }}-not">Not included</label><textarea id="tr-{{ $code }}-not" name="translations[{{ $code }}][not_included_text]" rows="5">{{ $trList('not_included') }}</textarea></div>
                                <div class="field"><label for="tr-{{ $code }}-bring">What to bring</label><textarea id="tr-{{ $code }}-bring" name="translations[{{ $code }}][what_to_bring_text]" rows="5">{{ $trList('what_to_bring') }}</textarea></div>
                            </div>
                        </div>
                    </details>
                @endforeach
            </fieldset>
        </div>

        <div class="form-side">
            <fieldset class="panel sticky">
                <legend>Publishing</legend>
                <label class="check"><input type="checkbox" name="is_published" value="1" @checked(old('is_published', $tour->is_published))> Published on the website</label>
                <label class="check"><input type="checkbox" name="is_featured" value="1" @checked(old('is_featured', $tour->is_featured))> Show on the home page</label>
                <div class="field"><label for="slug">Web address</label><div class="slug-input"><span>/tours/</span><input id="slug" name="slug" value="{{ old('slug', $tour->slug) }}" placeholder="made from the title"></div>@error('slug')<p class="err">{{ $message }}</p>@enderror</div>
                <div class="field"><label for="sort_order">Order</label><input id="sort_order" name="sort_order" type="number" value="{{ old('sort_order', $tour->sort_order ?? 0) }}"><p class="hint">Lower numbers appear first.</p></div>
                <button class="btn btn-primary btn-block" type="submit">{{ $editing ? 'Save tour' : 'Create tour' }}</button>
            </fieldset>

            @if ($editing)
            <fieldset class="panel">
                <legend>Route details (per day)</legend>
                <p class="hint">Komoot-style route pages: map, points of interest, surfaces, elevation profile and weather for each riding day.</p>
                @forelse ($tour->stages as $st)
                    <a class="stage-row" href="{{ route('admin.tours.stages.edit', [$tour, $st]) }}">
                        <strong>Day {{ $st->day }}</strong> {{ $st->title }}
                        <small class="muted block">{{ $st->distance_km ? $st->distance_km.' km' : 'no distance' }} · {{ $st->profile ? ($st->profile_approximate ? 'approx. profile' : 'GPX profile') : 'no profile' }}</small>
                    </a>
                @empty
                    <p class="muted">No route stages yet.</p>
                @endforelse
                <a class="btn btn-outline btn-block" href="{{ route('admin.tours.stages.create', $tour) }}"><x-icon name="plus" size="18" /> Add a riding day</a>
            </fieldset>
            @endif

            <fieldset class="panel">
                <legend>Gallery</legend>
                @if ($tour->gallery)
                    <div class="gallery-admin">
                        @foreach ($tour->gallery as $path)
                            <label><img src="{{ \App\Models\Tour::mediaUrl($path) }}" alt=""><span><input type="checkbox" name="remove_gallery[]" value="{{ $path }}"> Remove</span></label>
                        @endforeach
                    </div>
                @endif
                <input type="file" name="gallery[]" accept="image/*" multiple aria-label="Add gallery photos">
                <p class="hint">Add several photos at once. They appear on the tour page.</p>
                @error('gallery.*')<p class="err">{{ $message }}</p>@enderror
            </fieldset>
        </div>
    </div>
</form>

@if ($editing)
    <form method="post" action="{{ route('admin.tours.destroy', $tour) }}" class="danger-zone" onsubmit="return confirm('Delete “{{ addslashes($tour->title) }}”? Existing bookings are kept without the tour link.')">
        @csrf @method('delete')
        <button class="btn btn-danger" type="submit"><x-icon name="trash" size="18" /> Delete tour</button>
    </form>
@endif
@endsection

@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
    <script src="{{ \App\Support\Asset::v('js/maps.js') }}"></script>
    <script>
        MCT.pickerMap('picker-map', {
            lat: document.getElementById('latitude'),
            lng: document.getElementById('longitude'),
            route: document.getElementById('route_json'),
            activity: document.getElementById('activity_id'),
            undo: document.getElementById('route-undo'),
            clear: document.getElementById('route-clear'),
            count: document.getElementById('route-count'),
        });
    </script>
@endpush
