@extends('layouts.admin')
@section('title', 'Bookings')
@section('heading', 'Bookings')

@section('content')
<nav class="tabs" aria-label="Booking status">
    <a href="{{ route('admin.bookings.index') }}" @class(['on' => ! request('status')])>All <span>{{ $counts->sum() }}</span></a>
    @foreach (\App\Models\Booking::STATUSES as $k => $label)
        <a href="{{ request()->fullUrlWithQuery(['status' => $k, 'page' => null]) }}" @class(['on' => request('status') === $k])>{{ $label }} <span>{{ $counts[$k] ?? 0 }}</span></a>
    @endforeach
</nav>

<form class="toolbar" method="get">
    @if (request('status'))<input type="hidden" name="status" value="{{ request('status') }}">@endif
    <div class="input-icon"><x-icon name="search" size="18" /><input type="search" name="q" value="{{ request('q') }}" placeholder="Name, e-mail, reference or tour"></div>
    <select name="when" onchange="this.form.submit()">
        <option value="">Any date</option>
        <option value="upcoming" @selected(request('when') === 'upcoming')>Upcoming</option>
        <option value="past" @selected(request('when') === 'past')>Past</option>
    </select>
    <button class="btn btn-outline" type="submit">Search</button>
</form>

<div class="panel">
    <table class="table">
        <thead><tr><th>Reference</th><th>Ride date</th><th>Tour</th><th>Guest</th><th>Riders</th><th>Total</th><th>Status</th></tr></thead>
        <tbody>
        @forelse ($bookings as $b)
            <tr>
                <td><a class="strong" href="{{ route('admin.bookings.show', $b) }}">{{ $b->reference }}</a><span class="muted block">{{ $b->created_at->format('j M, H:i') }}</span></td>
                <td class="nowrap">{{ $b->tour_date->format('D j M Y') }}</td>
                <td>
                    @if ($b->tour)<span class="type-dot" style="--c: {{ $b->tour->activity->color }}"></span>@endif
                    {{ $b->tour_title }}
                </td>
                <td>{{ $b->name }} <span class="lang-dot on" title="Guest language">{{ strtoupper($b->locale ?? 'en') }}</span><span class="muted block">{{ $b->email }}</span></td>
                <td>{{ $b->participants }}</td>
                <td class="nowrap">{{ $b->total_formatted }}</td>
                <td>@include('admin.partials.status', ['status' => $b->status])</td>
            </tr>
        @empty
            <tr><td colspan="7" class="empty-line">No bookings match. Booking requests from tour pages appear here.</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
{{ $bookings->links('admin.partials.pagination') }}
@endsection
