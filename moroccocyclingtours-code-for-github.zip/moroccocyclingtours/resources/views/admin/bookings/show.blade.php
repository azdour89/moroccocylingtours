@extends('layouts.admin')
@section('title', 'Booking '.$booking->reference)
@section('heading', 'Booking '.$booking->reference)
@section('back', route('admin.bookings.index'))
@section('actions')
    <a class="btn btn-outline" href="mailto:{{ $booking->email }}?subject={{ rawurlencode('Your '.config('site.name').' booking '.$booking->reference) }}"><x-icon name="mail" size="18" /> E-mail guest</a>
    @if ($booking->phone)
        <a class="btn btn-outline" href="https://wa.me/{{ preg_replace('/\D+/', '', $booking->phone) }}" target="_blank" rel="noopener"><x-icon name="phone" size="18" /> WhatsApp</a>
    @endif
@endsection

@section('content')
<div class="form-grid">
    <section class="panel">
        <h2 class="panel-title">Guest and ride</h2>
        <dl class="details">
            <dt>Tour</dt><dd>@if ($booking->tour)<a href="{{ route('admin.tours.edit', $booking->tour) }}">{{ $booking->tour_title }}</a> <span class="muted">({{ $booking->tour->activity->name }})</span>@else{{ $booking->tour_title }} <span class="muted">(tour deleted)</span>@endif</dd>
            <dt>Guest</dt><dd>{{ $booking->name }}</dd>
            <dt>E-mail</dt><dd><a href="mailto:{{ $booking->email }}">{{ $booking->email }}</a></dd>
            <dt>Phone</dt><dd>{{ $booking->phone ?: 'Not given' }}</dd>
            <dt>Language</dt><dd>{{ \App\Support\Locale::all()[$booking->locale ?? 'en'] ?? $booking->locale }} <span class="muted">(reply in this language)</span></dd>
            <dt>Country</dt><dd>{{ $booking->country ?: 'Not given' }}</dd>
            <dt>Pick-up</dt><dd>{{ $booking->pickup_location ?: 'Not given' }}</dd>
            <dt>Message</dt><dd>{!! $booking->message ? nl2br(e($booking->message)) : '<span class="muted">No message</span>' !!}</dd>
            <dt>Rented equipment</dt><dd>@forelse ($booking->addons ?? [] as $a){{ $a['qty'] }} × {{ $a['name'] }} <span class="muted">({{ config('site.currency') }}{{ rtrim(rtrim(number_format($a['unit_price'], 2), '0'), '.') }} {{ $a['unit'] === 'day' ? 'per day × '.$a['days'].' days' : 'per trip' }}) = {{ config('site.currency') }}{{ rtrim(rtrim(number_format($a['total'], 2), '0'), '.') }}</span><br>@empty<span class="muted">None</span>@endforelse @if ($booking->addons_total > 0)<strong>Equipment total: {{ config('site.currency') }}{{ rtrim(rtrim(number_format($booking->addons_total, 2), '0'), '.') }}</strong>@endif</dd>
            <dt>Requested</dt><dd>{{ $booking->created_at->format('j M Y, H:i') }}</dd>
        </dl>
    </section>

    <form method="post" action="{{ route('admin.bookings.update', $booking) }}" class="panel">
        @csrf @method('put')
        <h2 class="panel-title">Manage</h2>
        <div class="field">
            <label for="status">Status</label>
            <select id="status" name="status">
                @foreach (\App\Models\Booking::STATUSES as $k => $label)<option value="{{ $k }}" @selected($booking->status === $k)>{{ $label }}</option>@endforeach
            </select>
        </div>
        <div class="row2">
            <div class="field"><label for="tour_date">Ride date</label><input id="tour_date" type="date" name="tour_date" value="{{ $booking->tour_date->toDateString() }}"></div>
            <div class="field"><label for="participants">Riders</label><input id="participants" type="number" min="1" name="participants" value="{{ $booking->participants }}"></div>
        </div>
        <div class="field"><label for="total_price">Total ({{ config('site.currency') }})</label><input id="total_price" type="number" step="0.01" min="0" name="total_price" value="{{ $booking->total_price }}"></div>
        <div class="field"><label for="admin_notes">Internal notes</label><textarea id="admin_notes" name="admin_notes" rows="5" placeholder="Bike sizes, guide assigned, deposit received…">{{ $booking->admin_notes }}</textarea></div>
        <button class="btn btn-primary btn-block" type="submit">Save booking</button>
    </form>
</div>

<form method="post" action="{{ route('admin.bookings.destroy', $booking) }}" class="danger-zone" onsubmit="return confirm('Delete booking {{ $booking->reference }}?')">
    @csrf @method('delete')
    <button class="btn btn-danger" type="submit"><x-icon name="trash" size="18" /> Delete booking</button>
</form>
@endsection
