@extends('layouts.admin')
@php use App\Models\RouteStage; $editing = $stage->exists; @endphp
@section('title', ($editing ? 'Day '.$stage->day : 'New riding day').' · '.$tour->title)
@section('heading', ($editing ? 'Day '.$stage->day.': '.$stage->title : 'New riding day'))
@section('back', route('admin.tours.edit', $tour))
@push('head')<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">@endpush
@section('content')
<p class="intro">Route details for <strong>{{ $tour->title }}</strong>. The fastest way: plan the day in Komoot, paste the Komoot link for the preview, and upload the GPX export (Komoot → ⋯ → Download GPX). Distance, ascent, descent, highest/lowest point, map line and elevation profile are then filled in for you. The website shows this data in its own design, not the Komoot frame.</p>
<form method="post" enctype="multipart/form-data" action="{{ $editing ? route('admin.tours.stages.update', [$tour, $stage]) : route('admin.tours.stages.store', $tour) }}">
    @csrf @if ($editing) @method('put') @endif
    <div class="form-grid">
        <div class="form-main">
            <fieldset class="panel">
                <legend>Day</legend>
                <div class="field-grid">
                    <div class="field half"><label for="day">Day number</label><input id="day" type="number" min="1" name="day" value="{{ old('day', $stage->day) }}" required></div>
                    <div class="field half"><label for="duration_label">Riding time (e.g. 4–5 h)</label><input id="duration_label" name="duration_label" value="{{ old('duration_label', $stage->duration_label) }}"></div>
                    <div class="field"><label for="title">Title (e.g. Asni – Ouirgane)</label><input id="title" name="title" value="{{ old('title', $stage->title) }}" required maxlength="200">@error('title')<p class="err">{{ $message }}</p>@enderror</div>
                    <div class="field"><label for="description">Short description</label><textarea id="description" name="description" rows="3">{{ old('description', $stage->description) }}</textarea></div>
                </div>
            </fieldset>

            <fieldset class="panel">
                <legend>Komoot route &amp; GPX</legend>
                <div class="field"><label for="komoot_url">Komoot tour link or embed link</label>
                    <input id="komoot_url" name="komoot_url" value="{{ old('komoot_url', $stage->komoot_url) }}" placeholder="https://www.komoot.com/tour/123456789?share_token=…">
                    <p class="hint">Use “Share” in Komoot and make the tour public or share with link, otherwise the preview stays empty.</p></div>
                @if ($stage->komoot_embed)
                    <div class="komoot-frame"><iframe src="{{ $stage->komoot_embed }}" width="100%" height="580" frameborder="0" scrolling="no" loading="lazy" title="Komoot preview"></iframe></div>
                @endif
                <div class="field-grid">
                    <div class="field"><label for="gpx">GPX file (fills in the numbers, map line and profile)</label><input id="gpx" type="file" name="gpx" accept=".gpx,application/gpx+xml,application/xml,text/xml">@error('gpx')<p class="err">{{ $message }}</p>@enderror
                        @if ($stage->gpx_file)<p class="hint">Current file: <a href="{{ \App\Support\Media::url($stage->gpx_file) }}">{{ basename($stage->gpx_file) }}</a> · <label class="check inline"><input type="checkbox" name="remove_gpx" value="1"> remove</label></p>@endif</div>
                    <label class="check"><input type="checkbox" name="gpx_public" value="1" @checked(old('gpx_public', $stage->gpx_public))> Let visitors download the GPX file</label>
                </div>
            </fieldset>

            <fieldset class="panel">
                <legend>Route details</legend>
                <div class="field-grid">
                    <div class="field third"><label for="distance_km">Distance (km)</label><input id="distance_km" type="number" step="0.1" name="distance_km" value="{{ old('distance_km', $stage->distance_km) }}"></div>
                    <div class="field third"><label for="ascent_m">Ascent (m)</label><input id="ascent_m" type="number" name="ascent_m" value="{{ old('ascent_m', $stage->ascent_m) }}"></div>
                    <div class="field third"><label for="descent_m">Descent (m)</label><input id="descent_m" type="number" name="descent_m" value="{{ old('descent_m', $stage->descent_m) }}"></div>
                    <div class="field third"><label for="max_alt_m">Highest point (m)</label><input id="max_alt_m" type="number" name="max_alt_m" value="{{ old('max_alt_m', $stage->max_alt_m) }}"></div>
                    <div class="field third"><label for="min_alt_m">Lowest point (m)</label><input id="min_alt_m" type="number" name="min_alt_m" value="{{ old('min_alt_m', $stage->min_alt_m) }}"></div>
                </div>
                <div class="field"><label for="surfaces_text">Types of paths and surfaces <span class="muted">(one per line: type | km, copy Komoot’s labels in English or French)</span></label>
                    <textarea id="surfaces_text" name="surfaces_text" rows="5" class="mono" placeholder="Asphalte | 16.1 km&#10;Pierres plates | 11.6 km&#10;Non pavé | 8.58 km&#10;Naturel | 7.99 km">{{ old('surfaces_text', RouteStage::surfacesToText($stage->surfaces)) }}</textarea>
                    <p class="hint">Recognised: {{ implode(', ', array_keys(RouteStage::SURFACES)) }} and Komoot’s labels (Asphalte, Pierres plates, Gravillon, Non pavé, Naturel, Alpin, Inconnu).</p></div>
                <div class="field"><label for="profile_text">Elevation profile without GPX <span class="muted">(optional, one point per line: km | altitude)</span></label>
                    <textarea id="profile_text" name="profile_text" rows="4" class="mono" placeholder="0 | 1150&#10;10 | 1320&#10;23 | 780&#10;36 | 1250&#10;44 | 1000">{{ old('profile_text', $stage->profile_approximate ? RouteStage::profileToText($stage->profile) : '') }}</textarea>
                    <p class="hint">Shown as an approximate profile. A GPX upload replaces it with the exact one.</p></div>
            </fieldset>

            <fieldset class="panel">
                <legend>Route overview &amp; points of interest</legend>
                <div class="map-tools" role="group" aria-label="Map mode">
                    <label class="seg"><input type="radio" name="_mode" value="route" checked> <span><x-icon name="wheel" size="16" /> Draw route</span></label>
                    <label class="seg"><input type="radio" name="_mode" value="poi"> <span><x-icon name="pin" size="16" /> Add point of interest</span></label>
                    <button type="button" class="btn btn-outline btn-sm" id="route-undo">Undo last point</button>
                    <button type="button" class="btn btn-outline btn-sm" id="route-clear">Clear route</button>
                    <span class="muted" id="route-count"></span>
                </div>
                <div id="stage-map" class="picker-map"></div>
                <input type="hidden" id="route_json" name="route_json" value="{{ old('route_json', json_encode($stage->route ?? [])) }}">
                <div class="field"><label for="pois_text">Points of interest <span class="muted">(name | type | latitude, longitude)</span></label>
                    <textarea id="pois_text" name="pois_text" rows="5" class="mono" placeholder="Tizi n’Tamatert | pass | 31.150, -7.888">{{ old('pois_text', RouteStage::poisToText($stage->pois)) }}</textarea>
                    <p class="hint">Types: {{ implode(', ', array_keys(RouteStage::POI_TYPES)) }}. Historic sites near the route are added automatically on the website.</p></div>
            </fieldset>

            <fieldset class="panel">
                <legend>Translations</legend>
                @foreach (\App\Support\Locale::translatable() as $code => $langName)
                    <details class="tr-lang">
                        <summary><span class="lang-dot {{ filled($stage->trRaw($code, 'title')) ? 'on' : '' }}">{{ strtoupper($code) }}</span> {{ $langName }}</summary>
                        <div class="tr-body" lang="{{ $code }}">
                            <div class="field"><label>Title</label><input name="translations[{{ $code }}][title]" value="{{ old("translations.$code.title", $stage->trRaw($code, 'title')) }}" placeholder="{{ $stage->title }}"></div>
                            <div class="field"><label>Description</label><textarea name="translations[{{ $code }}][description]" rows="3">{{ old("translations.$code.description", $stage->trRaw($code, 'description')) }}</textarea></div>
                        </div>
                    </details>
                @endforeach
            </fieldset>
        </div>
        <div class="form-side">
            <fieldset class="panel sticky">
                <legend>Save</legend>
                <button class="btn btn-primary btn-block" type="submit">{{ $editing ? 'Save riding day' : 'Create riding day' }}</button>
                @if ($editing && $tour->is_published)<a class="btn btn-outline btn-block mt-s" href="{{ route('tours.show', ['tour' => $tour->slug]) }}#route" target="_blank" rel="noopener"><x-icon name="eye" size="18" /> Preview on the website</a>@endif
                @if ($editing && $stage->profile)<p class="hint">Profile: {{ count($stage->profile) }} points ({{ $stage->profile_approximate ? 'approximate' : 'from GPX' }})</p>@endif
            </fieldset>
        </div>
    </div>
</form>
@if ($editing)
    <form method="post" action="{{ route('admin.tours.stages.destroy', [$tour, $stage]) }}" class="danger-zone" onsubmit="return confirm('Delete this riding day?')">@csrf @method('delete')
        <button class="btn btn-danger" type="submit"><x-icon name="trash" size="18" /> Delete riding day</button></form>
@endif
@endsection
@push('scripts')
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
<script src="{{ \App\Support\Asset::v('js/maps.js') }}"></script>
<script>
MCT.stageEditor('stage-map', {
    route: document.getElementById('route_json'), pois: document.getElementById('pois_text'),
    undo: document.getElementById('route-undo'), clear: document.getElementById('route-clear'), count: document.getElementById('route-count'),
});
</script>
@endpush
