@extends('layouts.admin')
@php $editing = $activity->exists; @endphp
@section('title', $editing ? 'Edit '.$activity->name : 'New bike type')
@section('heading', $editing ? $activity->name : 'New bike type')
@section('back', route('admin.activities.index'))

@section('content')
<form method="post" enctype="multipart/form-data" class="panel narrow" action="{{ $editing ? route('admin.activities.update', $activity) : route('admin.activities.store') }}">
    @csrf @if ($editing) @method('put') @endif
    <div class="row2">
        <div class="field"><label for="name">Name</label><input id="name" name="name" value="{{ old('name', $activity->name) }}" required>@error('name')<p class="err">{{ $message }}</p>@enderror</div>
        <div class="field"><label for="slug">Web address</label><input id="slug" name="slug" value="{{ old('slug', $activity->slug) }}" placeholder="made from the name">@error('slug')<p class="err">{{ $message }}</p>@enderror</div>
    </div>
    <fieldset class="field">
        <legend>Icon</legend>
        <div class="icon-choices">
            @foreach (\App\Models\Activity::ICONS as $key => $label)
                <label class="icon-choice"><input type="radio" name="icon" value="{{ $key }}" @checked(old('icon', $activity->icon) === $key)><span><x-icon :name="$key" size="40" /><small>{{ $label }}</small></span></label>
            @endforeach
        </div>
    </fieldset>
    <div class="row2">
        <div class="field"><label for="color">Colour (map pins and badges)</label><input id="color" name="color" type="color" value="{{ old('color', $activity->color) }}">@error('color')<p class="err">{{ $message }}</p>@enderror</div>
        <div class="field"><label for="sort_order">Order</label><input id="sort_order" name="sort_order" type="number" value="{{ old('sort_order', $activity->sort_order ?? 0) }}"></div>
    </div>
    <div class="field"><label for="image">Photo (home page and bike-type page)</label>
        @if ($activity->image)<img class="preview" src="{{ \App\Support\Media::sized($activity->image, 800) }}" alt="">@endif
        <input id="image" type="file" name="image" accept="image/*"><p class="hint">{{ \App\Admin\ImageHint::text() }}</p>@error('image')<p class="err">{{ $message }}</p>@enderror</div>
    <div class="field"><label for="description">Description <span class="muted">(shown at the top of the finder)</span></label><textarea id="description" name="description" rows="3" maxlength="500">{{ old('description', $activity->description) }}</textarea></div>
    <fieldset class="field">
        <legend>Translations <span class="muted">(empty fields use English)</span></legend>
        <div class="tr-grid">
            @foreach (\App\Support\Locale::translatable() as $code => $langName)
                <div class="tr-row" lang="{{ $code }}">
                    <span class="lang-dot {{ filled($activity->trRaw($code, 'name')) ? 'on' : '' }}" title="{{ $langName }}">{{ strtoupper($code) }}</span>
                    <input name="translations[{{ $code }}][name]" value="{{ old("translations.$code.name", $activity->trRaw($code, 'name')) }}" placeholder="Name in {{ $langName }}" aria-label="Name in {{ $langName }}">
                    <input name="translations[{{ $code }}][description]" value="{{ old("translations.$code.description", $activity->trRaw($code, 'description')) }}" placeholder="Description in {{ $langName }}" aria-label="Description in {{ $langName }}">
                </div>
            @endforeach
        </div>
    </fieldset>
    <button class="btn btn-primary" type="submit">{{ $editing ? 'Save bike type' : 'Add bike type' }}</button>
</form>
@endsection
