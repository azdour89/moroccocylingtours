@extends('layouts.admin')
@section('title', 'Bike types')
@section('heading', 'Bike types')
@section('actions')
    <a class="btn btn-primary" href="{{ route('admin.activities.create') }}"><x-icon name="plus" size="18" /> New bike type</a>
@endsection

@section('content')
<p class="intro">Bike types are the activities visitors filter by: enduro, gravel, road, e-bike, city and cross-country. Each has an icon and a colour used for map pins and tour cards.</p>
<div class="type-cards">
    @foreach ($activities as $a)
        <article class="type-card" style="--c: {{ $a->color }}">
            <span class="type-ico"><x-icon :name="$a->icon" size="40" /></span>
            <div>
                <h2>{{ $a->name }}</h2>
                <p class="muted">{{ $a->tours_count }} tours · {{ $a->bookings_count }} bookings</p>
                @if ($a->description)<p>{{ $a->description }}</p>@endif
            </div>
            <div class="row-actions">
                <a href="{{ route('admin.activities.edit', $a) }}" title="Edit"><x-icon name="edit" size="18" /></a>
                <form method="post" action="{{ route('admin.activities.destroy', $a) }}" onsubmit="return confirm('Delete {{ addslashes($a->name) }}?')">@csrf @method('delete')<button type="submit" title="Delete"><x-icon name="trash" size="18" /></button></form>
            </div>
        </article>
    @endforeach
</div>
@endsection
