@extends('layouts.app')

@php
    $title    = $tour->tr('title');
    $subtitle = $tour->tr('subtitle');
    $bike     = $tour->activity->tr('name');
    $images   = array_values(array_filter(array_merge([$tour->image_url], $tour->gallery_urls)));
    $duration = $tour->tr('duration_label');
    $terrain  = $tour->tr('terrain');
    $season   = $tour->tr('season');
@endphp

@section('title', $title.($subtitle ? ' | '.$subtitle : ' | '.config('site.name')))
@section('meta_description', $subtitle ? $subtitle.'. '.$tour->tr('excerpt') : $tour->tr('excerpt'))

@section('og_type', 'product')
@section('og_image', $tour->image ? url(\App\Support\Media::sized($tour->image, 1280)) : '')

@push('head')
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">
    <script type="application/ld+json">{!! json_encode(array_filter([
        '@context' => 'https://schema.org',
        '@type' => 'TouristTrip',
        'name' => $title,
        'description' => $tour->tr('excerpt'),
        'url' => url()->current(),
        'image' => $tour->image ? url(\App\Support\Media::sized($tour->image, 1280)) : null,
        'touristType' => $tour->activity_id ? $tour->activity->tr('name') : $tour->category_label,
        'itinerary' => ['@type' => 'ItemList', 'itemListElement' => collect($tour->tr('itinerary') ?? [])->values()->map(fn ($s, $i) => ['@type' => 'ListItem', 'position' => $i + 1, 'name' => trim(($s['time'] ?? '').' '.($s['title'] ?? $s['text'] ?? ''))])->all()],
        'provider' => ['@type' => 'TravelAgency', 'name' => config('site.name'), 'url' => route('home')],
                'offers' => $tour->on_request ? null : ['@type' => 'AggregateOffer', 'lowPrice' => $tour->lowest_price, 'highPrice' => $tour->highest_price, 'priceCurrency' => config('site.currency_code'), 'availability' => 'https://schema.org/InStock', 'url' => url()->current()],
        'aggregateRating' => $tour->reviews->count() ? ['@type' => 'AggregateRating', 'ratingValue' => round($tour->reviews->avg('rating'), 1), 'reviewCount' => $tour->reviews->count()] : null,
    ]), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) !!}</script>
@endpush

@section('content')
<section class="tour-hero" style="--c: {{ $tour->activity->color }}">
    <div class="wrap tour-hero-grid">
        <div class="tour-hero-copy">
            <nav class="crumbs" aria-label="{{ __('Breadcrumb') }}">
                <a href="{{ route('home') }}">{{ __('Home') }}</a> <span>/</span>
                <a href="{{ route('tours.index', ['category' => $tour->category]) }}">{{ $tour->category_label }}</a> <span>/</span>
                <span aria-current="page">{{ $title }}</span>
            </nav>
            <span class="bike-chip bike-chip-lg"><x-icon :name="$tour->activity->icon" size="22" />{{ $tour->activity_id ? __(':name tour', ['name' => $bike]) : $bike }}</span>
            <span class="cat-chip"><x-icon :name="$tour->category_icon" size="18" />{{ $tour->category_label }}</span>
            <h1>{{ $title }}</h1>
            @if ($subtitle)<p class="subtitle">{{ $subtitle }}</p>@endif
            <p class="lede">{{ $tour->tr('excerpt') }}</p>
            <div class="tour-hero-price">
                @if ($tour->on_request)
                    <p><strong>{{ __('Price on request') }}</strong></p>
                @else
                    <p><small>{{ __('from') }}</small> <strong>{{ $tour->price_formatted }}</strong> <small>{{ __('per person') }}</small></p>
                @endif
                <x-level :level="$tour->level" />
            </div>
            <div class="btn-row">
                <a class="btn btn-saffron" href="#book">{{ __('Book this tour') }}</a>
                <a class="btn btn-ghost" href="#details">{{ __('Tour details') }}</a>
            </div>
        </div>
        <div class="tour-hero-media">
            @if ($tour->image)
                <x-img :src="$tour->image" :alt="$title" class="arch" sizes="(max-width: 900px) 100vw, 45vw" :eager="true" />
            @elseif (count($images))
                <img class="arch" src="{{ $images[0] }}" alt="{{ $title }}">
            @else
                <div class="arch arch-ph"><x-icon :name="$tour->activity->icon" size="120" /></div>
            @endif
        </div>
    </div>
</section>

<section class="facts" id="details" aria-label="{{ __('Key facts') }}">
    <div class="wrap facts-grid">
        @php
            $facts = array_filter([
                ['wheel', __('Distance'), $tour->distance_km ? ($tour->distance_km + 0).' km' : null],
                ['stopwatch', __('Duration'), $duration],
                ['gauge', __('Difficulty'), $tour->level_label],
                ['mountain', __('Elevation gain'), $tour->elevation_m ? number_format($tour->elevation_m).' m' : null],
                ['peak', __('Highest point'), $tour->max_altitude_m ? number_format($tour->max_altitude_m).' m' : null],
                ['terrain', __('Terrain'), $terrain],
                ['helmet', __('Group size'), $tour->capacity ? __('Up to :count riders', ['count' => $tour->capacity]) : null],
                ['age', __('Minimum age'), $tour->min_age ? __(':age+ years', ['age' => $tour->min_age]) : null],
            ], fn ($f) => $f[2]);
        @endphp
        @foreach ($facts as [$icon, $label, $value])
            <div class="fact"><x-icon :name="$icon" size="26" /><span class="fact-label">{{ $label }}</span><span class="fact-value">{{ $value }}</span></div>
        @endforeach
    </div>
</section>

@if (count($tour->gallery ?? []))
<section class="gallery wrap" aria-label="{{ __('Photos') }}">
    @foreach (array_slice($tour->gallery ?? [], 0, 8) as $path)
        <a href="{{ \App\Support\Media::sized($path, 1920) }}" target="_blank" rel="noopener"><x-img :src="$path" :alt="__(':title photo', ['title' => $title])" sizes="(max-width: 700px) 50vw, 220px" /></a>
    @endforeach
</section>
@endif

<div class="wrap tour-layout">
    <article class="tour-main">
        @if ($highlights = $tour->tr('highlights'))
            <section class="block">
                <h2>{{ __('Highlights') }}</h2>
                <ul class="star-list">
                    @foreach ($highlights as $h)<li><x-icon name="star8" size="16" />{{ $h }}</li>@endforeach
                </ul>
            </section>
        @endif

        <section class="block prose">
            <h2>{{ __('What awaits you') }}</h2>
            {!! nl2br(e($tour->tr('description') ?: $tour->tr('excerpt'))) !!}
        </section>

        @if ($itinerary = $tour->tr('itinerary'))
            <section class="block">
                <h2>{{ __('Itinerary') }}</h2>
                <ol class="timeline">
                    @foreach ($itinerary as $step)
                        <li>@if (! empty($step['time']))<time>{{ $step['time'] }}</time>@endif
                            @if (! empty($step['title']))<h3>{{ $step['title'] }}</h3>@endif
                            <p>{{ $step['text'] }}</p></li>
                    @endforeach
                </ol>
                <p class="note">{{ __('Timings are a guide. Your guide adapts the pace to the group and the weather.') }}</p>
            </section>
        @endif

        @if ($tour->departures->count())
            <section class="block" id="dates">
                <h2>{{ __('Upcoming departures') }}</h2>
                <div class="table-scroll">
                <table class="dep-table">
                    <thead><tr><th>{{ __('Dates') }}</th><th>{{ __('Status') }}</th><th>{{ __('Places left') }}</th><th>{{ __('Price') }}</th><th></th></tr></thead>
                    <tbody>
                    @foreach ($tour->departures as $d)
                        <tr>
                            <td>{{ $d->start_date->translatedFormat('D j M Y') }}@if ($d->end_date && ! $d->end_date->eq($d->start_date)) – {{ $d->end_date->translatedFormat('D j M Y') }}@endif
                                @if ($d->note)<small class="block muted">{{ $d->note }}</small>@endif</td>
                            <td><span class="dep-status dep-{{ $d->status }}">{{ __(\App\Models\Departure::STATUSES[$d->status] ?? $d->status) }}</span></td>
                            <td>{{ $d->spots ? $d->spots_left : '–' }}</td>
                            <td>{{ $d->price ? config('site.currency').number_format($d->price) : $tour->price_formatted }}</td>
                            <td>@if ($d->status !== 'full')<button type="button" class="btn btn-outline btn-sm" data-pick-date="{{ $d->start_date->toDateString() }}">{{ __('Choose this date') }}</button>@endif</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
                </div>
            </section>
        @endif

        @if ($tour->stages->count())
            @include('tours.partials.stages', ['stages' => $tour->stages])
        @else
        <section class="block" aria-label="{{ __('Route') }}">
            <h2>{{ __('Route') }}</h2>
            @if ($tour->start_point)<p class="start-point"><x-icon name="pin" size="18" /> {{ __('Starts at :place', ['place' => $tour->start_point]) }}</p>@endif
            <div id="tour-map" class="tour-map"></div>
        </section>
        @endif

        @if ($sites->count())
            <section class="block">
                <h2>{{ __('Historic sites along the way') }}</h2>
                <div class="site-cards">
                    @foreach ($sites->take(6) as $site)
                        <article class="site-card">
                            @if ($site->image)<x-img :src="$site->image" :alt="$site->tr('name')" sizes="(max-width: 700px) 100vw, 33vw" />@endif
                            <div><h3>{{ $site->tr('name') }}</h3>
                                <p class="muted">@if ($site->tr('period')){{ $site->tr('period') }} · @endif{{ __(':km km from the route', ['km' => max(1, round($site->distance))]) }}</p>
                                <p>{{ \Illuminate\Support\Str::limit($site->tr('description'), 160) }}</p></div>
                        </article>
                    @endforeach
                </div>
            </section>
        @endif

        @php $tourVideos = $tour->photos->filter(fn ($p) => $p->isVideo()); $tourPhotos = $tour->photos->reject(fn ($p) => $p->isVideo()); @endphp
        @if ($tourVideos->count())
            <section class="block">
                <h2>{{ __('Watch the ride') }}</h2>
                <div class="video-row">@foreach ($tourVideos as $vp)@include('partials.media-figure', ['p' => $vp])@endforeach</div>
            </section>
        @endif

        @if ($tourPhotos->count())
            <section class="block">
                <h2>{{ __('Photos from this tour') }}</h2>
                <script type="application/ld+json">{!! json_encode($tourPhotos->map(fn ($ph) => array_filter(['@context' => 'https://schema.org', '@type' => 'ImageObject', 'contentUrl' => url(\App\Support\Media::sized($ph->image, 1920)), 'name' => $ph->titleText(), 'description' => $ph->descriptionText(), 'caption' => $ph->tr('caption'), 'creator' => ['@type' => 'Organization', 'name' => config('site.name')]]))->values()->all(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!}</script>
                <div class="gallery-grid small">
                    @foreach ($tourPhotos as $ph)
                        <figure @class(['is-portrait' => \App\Support\Media::isPortrait($ph->image)])><x-img :src="$ph->image" :alt="$ph->altText() ?: $title" :title="$ph->titleText()" sizes="(max-width: 700px) 50vw, 25vw" />@if ($ph->tr('caption'))<figcaption>{{ $ph->tr('caption') }}</figcaption>@endif</figure>
                    @endforeach
                </div>
            </section>
        @endif

        @if ($tour->reviews->count())
            <section class="block">
                <h2>{{ __('What riders say about this tour') }}</h2>
                <p class="rating-summary"><x-stars :rating="round($tour->reviews->avg('rating'))" /> {{ __(':avg out of 5 from :n reviews', ['avg' => number_format($tour->reviews->avg('rating'), 1), 'n' => $tour->reviews->count()]) }}</p>
                <div class="review-grid two">@foreach ($tour->reviews->take(4) as $r)<x-review :review="$r" />@endforeach</div>
            </section>
        @endif

        <div class="two-col">
            @if ($included = $tour->tr('included'))
                <section class="block">
                    <h2>{{ __('What’s included') }}</h2>
                    <ul class="tick-list">@foreach ($included as $i)<li><x-icon name="check" size="18" />{{ $i }}</li>@endforeach</ul>
                </section>
            @endif
            @if ($notIncluded = $tour->tr('not_included'))
                <section class="block">
                    <h2>{{ __('Not included') }}</h2>
                    <ul class="tick-list tick-no">@foreach ($notIncluded as $i)<li><x-icon name="x" size="18" />{{ $i }}</li>@endforeach</ul>
                </section>
            @endif
        </div>

        <div class="two-col">
            @if ($bring = $tour->tr('what_to_bring'))
                <section class="block">
                    <h2>{{ __('What to bring') }}</h2>
                    <ul class="tool-list">@foreach ($bring as $i)<li><x-icon name="bottle" size="18" />{{ $i }}</li>@endforeach</ul>
                </section>
            @endif
            @if ($season)
                <section class="block">
                    <h2>{{ __('Season') }}</h2>
                    <p class="tool-line"><x-icon name="chainring" size="20" />{{ $season }}</p>
                </section>
            @endif
        </div>
    </article>

    <aside class="book-card" id="book" aria-label="{{ __('Book this tour') }}">
        <div class="book-head">
            @if ($tour->on_request)
                <p><strong>{{ __('Price on request') }}</strong><br>{{ __('Send your dates and group size and we’ll reply with a quote.') }}</p>
            @else
                <p><small>{{ __('from') }}</small> <strong>{{ $tour->price_formatted }}</strong> <small>{{ __('per person') }}</small></p>
            @endif
        </div>

        @if ($tour->group_prices)
            <table class="group-prices" aria-label="{{ __('Price per person by group size') }}">
                <caption>{{ __('Price per person by group size') }}</caption>
                <tbody>
                @foreach ($tour->group_prices as $row)
                    <tr data-min="{{ $row['min'] }}" data-max="{{ $row['max'] }}">
                        <th scope="row"><x-icon name="helmet" size="15" /> {{ \App\Support\GroupPricing::label($row) }}</th>
                        <td>
                            @if ($row['price'] === null)
                                <span class="gp-request">{{ __('On request') }}</span>
                            @else
                                <strong>{{ \App\Models\Tour::money($row['price']) }}</strong>
                                @if ($row['adjust'] < 0)<span class="gp-tag gp-save">−{{ abs($row['adjust']) }}%</span>@endif
                            @endif
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            <p class="note">{{ __('Groups larger than :n people: please ask us for a quote.', ['n' => $tour->group_max]) }}</p>
        @endif

        @if (session('booking_ref'))
            <div class="flash flash-ok" role="status">
                <x-icon name="check" size="20" />
                <div><strong>{{ __('Request sent. Reference :ref.', ['ref' => session('booking_ref')]) }}</strong><br>{{ __('We’ll confirm availability by e-mail within 24 hours.') }}</div>
            </div>
        @endif

        <form method="post" action="{{ route('bookings.store', ['tour' => $tour->slug]) }}" class="book-form" novalidate>
            @csrf
            <div class="hp" aria-hidden="true"><label>{{ __('Website') }} <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
            <div class="row2">
                <div class="field">
                    <label for="b-date">{{ __('Date') }}</label>
                    <input id="b-date" type="date" name="tour_date" min="{{ now()->toDateString() }}" value="{{ old('tour_date') }}" required>
                    @error('tour_date')<p class="err">{{ $message }}</p>@enderror
                </div>
                <div class="field">
                    <label for="b-pax">{{ __('People') }}</label>
                    <input id="b-pax" type="number" name="participants" min="1" max="{{ $tour->capacity ?: 50 }}" value="{{ old('participants', $tour->default_people) }}" required data-price="{{ $tour->price }}">
                    @error('participants')<p class="err">{{ $message }}</p>@enderror
                </div>
            </div>
            <div class="field">
                <label for="b-name">{{ __('Full name') }}</label>
                <input id="b-name" type="text" name="name" value="{{ old('name') }}" autocomplete="name" required>
                @error('name')<p class="err">{{ $message }}</p>@enderror
            </div>
            <div class="field">
                <label for="b-email">{{ __('E-mail') }}</label>
                <input id="b-email" type="email" name="email" value="{{ old('email') }}" autocomplete="email" required>
                @error('email')<p class="err">{{ $message }}</p>@enderror
            </div>
            <div class="row2">
                <div class="field">
                    <label for="b-phone">{{ __('Phone / WhatsApp') }}</label>
                    <input id="b-phone" type="tel" name="phone" value="{{ old('phone') }}" autocomplete="tel">
                </div>
                <div class="field">
                    <label for="b-country">{{ __('Country') }}</label>
                    <input id="b-country" type="text" name="country" value="{{ old('country') }}" autocomplete="country-name">
                </div>
            </div>
            <div class="field">
                <label for="b-pickup">{{ __('Riad or hotel for pick-up') }}</label>
                <input id="b-pickup" type="text" name="pickup_location" value="{{ old('pickup_location') }}">
            </div>
            <div class="field">
                <label for="b-msg">{{ __('Heights, experience or questions') }}</label>
                <textarea id="b-msg" name="message" rows="3">{{ old('message') }}</textarea>
            </div>
            @if ($tour->addons->count())
                @php $cur = config('site.currency'); @endphp
                <fieldset class="addons" id="addons" data-days="{{ $tour->duration_days }}">
                    <legend>{{ __('Rent equipment from our shop') }}</legend>
                    <p class="addons-intro">{{ __('Add gear to your booking: we prepare it for the start of your tour and you pay with the rest of the trip.') }}</p>
                    @foreach ($tour->addons as $it)
                        <div class="addon" data-price="{{ $it->price }}" data-unit="{{ $it->unit }}">
                            <label for="ad-{{ $it->id }}">
                                <span class="addon-name">{{ $it->tr('name') }}</span>
                                <span class="addon-price">{{ $cur }}{{ rtrim(rtrim(number_format($it->price, 2), '0'), '.') }} {{ $it->unit === 'day' ? __('per day') : __('per trip') }}</span>
                                @if ($it->tr('description'))<span class="addon-desc">{{ $it->tr('description') }}</span>@endif
                            </label>
                            <input id="ad-{{ $it->id }}" type="number" inputmode="numeric" min="0" max="{{ $it->max_qty }}" name="addons[{{ $it->id }}]" value="{{ old('addons.'.$it->id, 0) }}" aria-label="{{ __('Quantity') }}: {{ $it->tr('name') }}">
                            <span class="addon-sum" aria-hidden="true"></span>
                        </div>
                    @endforeach
                    <p class="bt-row addons-sum" id="b-eq-row" hidden><span>{{ __('Equipment rental') }}</span> <strong id="b-eq">–</strong></p>
                    <p class="bt-row bt-main" id="b-grand-row" hidden><span>{{ __('Total with equipment') }}</span> <strong id="b-grand">–</strong></p>
                </fieldset>
            @endif
            @unless ($tour->on_request)
                <div class="book-total" aria-live="polite">
                    <p class="bt-row"><span>{{ __('Price per person') }}</span> <strong id="b-pp">–</strong></p>
                    <p class="bt-row bt-main"><span id="b-total-label">{{ __('Estimated total') }}</span> <strong id="b-total">{{ $tour->price_formatted }}</strong></p>
                    <p class="bt-request" id="b-request" hidden>{{ __('For this group size the price is on request. Send your request and we’ll reply with a personal quote within 24 hours.') }}</p>
                </div>
            @endunless
            <button class="btn btn-saffron btn-block" type="submit">{{ __('Request booking') }}</button>
            <p class="note">{{ __('No payment now. We confirm availability first.') }}</p>
        </form>
    </aside>
</div>

@if ($related->count())
<section class="section section-tint">
    <div class="wrap">
        <div class="section-head"><h2>{{ __('More rides you may like') }}</h2></div>
        <div class="card-grid">@foreach ($related as $r)<x-tour-card :tour="$r" />@endforeach</div>
    </div>
</section>
@endif
@endsection

@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
    <script src="{{ \App\Support\Asset::v('js/maps.js') }}"></script>
    <script>
        document.querySelectorAll('[data-pick-date]').forEach((b) => b.addEventListener('click', () => {
            const i = document.getElementById('b-date'); i.value = b.dataset.pickDate; document.getElementById('book').scrollIntoView({ behavior: 'smooth' }); i.focus();
        }));
        if (document.getElementById('tour-map')) MCT.routeMap('tour-map', {
            lat: @json($tour->latitude), lng: @json($tour->longitude),
            route: @json($tour->route ?? []), color: @json($tour->activity->color), title: @json($title)
        });
        (function () {
            const pax = document.getElementById('b-pax'), out = document.getElementById('b-total');
            if (!out) return;
            // price per person for each group size, calculated on the server from Admin → Group pricing
            const tiers = {{ \Illuminate\Support\Js::from(collect($tour->group_prices)->map(fn ($r) => ['min' => $r['min'], 'max' => $r['max'], 'price' => $r['price']])->values()) }};
            const base = parseFloat(pax.dataset.price);
            const cur = @json(config('site.currency')), lang = document.documentElement.lang;
            const pp = document.getElementById('b-pp'), req = document.getElementById('b-request'), label = document.getElementById('b-total-label');
            const totalFor = @json(__('Total for :n people')), totalForOne = @json(__('Total for 1 person'));
            const money = (v) => cur + Math.round(v).toLocaleString(lang);
            const upd = () => {
                const n = Math.max(1, parseInt(pax.value || '1', 10));
                const tier = tiers.length ? tiers.find((t) => n >= t.min && n <= t.max) : { price: base };
                const price = tier ? tier.price : null;
                document.querySelectorAll('.group-prices tr').forEach((tr) => tr.classList.toggle('is-current', n >= +tr.dataset.min && n <= +tr.dataset.max));
                label.textContent = n === 1 ? totalForOne : totalFor.replace(':n', n);
                if (price === null || price === undefined) {
                    pp.textContent = @json(__('On request')); out.textContent = '–'; req.hidden = false;
                } else {
                    pp.textContent = money(price); out.textContent = money(price * n); req.hidden = true;
                }
                window.__tourTotal = (price === null || price === undefined) ? null : price * n;
                document.dispatchEvent(new CustomEvent('mct:total'));
            };
            pax.addEventListener('input', upd); upd();
        })();
        (function () {
            const box = document.getElementById('addons');
            if (!box) return;
            const days = parseInt(box.dataset.days || '1', 10), cur = @json(config('site.currency')), lang = document.documentElement.lang;
            const money = (v) => cur + Math.round(v).toLocaleString(lang);
            const rows = [...box.querySelectorAll('.addon')], eqRow = document.getElementById('b-eq-row'), eq = document.getElementById('b-eq');
            const grandRow = document.getElementById('b-grand-row'), grand = document.getElementById('b-grand');
            const calc = () => {
                let t = 0;
                rows.forEach((r) => {
                    const input = r.querySelector('input'), max = parseInt(input.max || '50', 10);
                    const q = Math.min(max, Math.max(0, parseInt(input.value || '0', 10) || 0));
                    const sum = (+r.dataset.price) * q * (r.dataset.unit === 'day' ? days : 1);
                    r.querySelector('.addon-sum').textContent = q ? money(sum) : '';
                    r.classList.toggle('is-on', q > 0);
                    t += sum;
                });
                eqRow.hidden = t === 0; eq.textContent = money(t);
                const base = window.__tourTotal;
                grandRow.hidden = !(t > 0 && typeof base === 'number' && base > 0);
                if (!grandRow.hidden) grand.textContent = money(base + t);
            };
            box.addEventListener('input', calc);
            document.addEventListener('mct:total', calc);
            calc();
        })();
    </script>
@endpush
