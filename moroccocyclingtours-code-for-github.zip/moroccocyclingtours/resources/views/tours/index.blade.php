@extends('layouts.app')

@php
    $heading = $currentCategory ? $currentCategory->tr('name') : ($currentActivity ? __(':name tours', ['name' => $currentActivity->tr('name')]) : __('Find your ride'));
    $intro = $currentCategory?->tr('description') ?: $currentActivity?->tr('description');
@endphp
@section('title', ($currentCategory ? $currentCategory->tr('name').' '.__('in Morocco') : ($currentActivity ? __(':name tours in Morocco', ['name' => $currentActivity->tr('name')]) : __('Find a cycling tour in Morocco'))).' | '.config('site.name'))
@section('meta_description', $intro ?: __('Discover Morocco on two wheels. Guided gravel, road and e-bike tours through the High Atlas Mountains, Dades Valley and Sahara Desert. Book your trip today!'))
@if (request()->routeIs('trips.show', 'bikes.show'))@section('canonical', url()->current())@endif
@section('body_class', 'page-finder')

@push('head')
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">
@endpush

@section('content')
<section class="finder-head">
    <div class="wrap">
        <nav class="crumbs" aria-label="{{ __('Breadcrumb') }}"><a href="{{ route('home') }}">{{ __('Home') }}</a> <span>/</span> <span aria-current="page">{{ __('Find a tour') }}</span></nav>
        <h1>{{ $heading }}</h1>
        @if ($intro)<p class="lede">{{ $intro }}</p>@endif

        <div class="chips" role="list" aria-label="{{ __('Bike type') }}">
            <a role="listitem" href="{{ request()->fullUrlWithQuery(['activity' => null]) }}" @class(['chip', 'is-on' => ! $currentActivity])>
                <x-icon name="star8" size="28" /><span>{{ __('All bikes') }}</span>
            </a>
            @foreach ($activities as $a)
                <a role="listitem" href="{{ request()->fullUrlWithQuery(['activity' => $a->slug]) }}" style="--c: {{ $a->color }}"
                   @class(['chip', 'is-on' => $currentActivity?->id === $a->id]) @if ($currentActivity?->id === $a->id) aria-current="true" @endif>
                    <x-icon :name="$a->icon" size="28" /><span>{{ $a->tr('name') }}</span><small>{{ $a->tours_count }}</small>
                </a>
            @endforeach
        </div>
    </div>
</section>

<section class="finder">
    <div class="wrap">
        <form class="filters" method="get" action="{{ route('tours.index') }}" id="filters">
            @if (! empty($filters['activity']))<input type="hidden" name="activity" value="{{ $filters['activity'] }}">@endif
            @if (! empty($filters['style']))<input type="hidden" name="style" value="{{ $filters['style'] }}">@endif

            <div class="f-field f-search">
                <label for="f-q">{{ __('Search') }}</label>
                <div class="input-icon"><x-icon name="search" size="18" /><input id="f-q" type="search" name="q" value="{{ $filters['q'] ?? '' }}" placeholder="{{ __('Place or tour name') }}"></div>
            </div>
            <div class="f-field">
                <label for="f-category">{{ __('Trip type') }}</label>
                <select id="f-category" name="category" data-autosubmit>
                    <option value="">{{ __('All trip types') }}</option>
                    @foreach ($categories as $c)
                        @if ($categoryCounts[$c->slug] ?? 0)<option value="{{ $c->slug }}" @selected(($filters['category'] ?? '') === $c->slug)>{{ $c->tr('name') }} ({{ $categoryCounts[$c->slug] }})</option>@endif
                    @endforeach
                </select>
            </div>
            <div class="f-field">
                <label for="f-region">{{ __('Region') }}</label>
                <select id="f-region" name="region" data-autosubmit>
                    <option value="">{{ __('All regions') }}</option>
                    @foreach ($regions as $r)<option value="{{ $r }}" @selected(($filters['region'] ?? '') === $r)>{{ $r }}</option>@endforeach
                </select>
            </div>
            <div class="f-field">
                <label for="f-duration">{{ __('Duration') }}</label>
                <select id="f-duration" name="duration" data-autosubmit>
                    <option value="">{{ __('Any length') }}</option>
                    @foreach (\App\Models\Tour::DURATIONS as $k => $label)<option value="{{ $k }}" @selected(($filters['duration'] ?? '') === $k)>{{ __($label) }}</option>@endforeach
                </select>
            </div>
            <div class="f-field">
                <label for="f-price">{{ __('Price per rider') }}</label>
                <select id="f-price" name="max_price" data-autosubmit>
                    <option value="">{{ __('Any price') }}</option>
                    @foreach ([50, 75, 100, 150] as $p)<option value="{{ $p }}" @selected(($filters['max_price'] ?? '') == $p)>{{ __('Up to :price', ['price' => config('site.currency').$p]) }}</option>@endforeach
                </select>
            </div>
            <fieldset class="f-field f-levels">
                <legend>{{ __('Level') }}</legend>
                <div class="level-toggles">
                    @foreach (\App\Models\Tour::LEVELS as $k => $label)
                        <label class="lt lt-{{ $k }}"><input type="checkbox" name="level[]" value="{{ $k }}" data-autosubmit @checked(in_array($k, (array) ($filters['level'] ?? [])))><span>{{ __($label) }}</span></label>
                    @endforeach
                </div>
            </fieldset>
            <div class="f-actions">
                <button class="btn btn-green" type="submit">{{ __('Apply') }}</button>
                <a class="link-quiet" href="{{ route('tours.index') }}">{{ __('Reset') }}</a>
            </div>
        </form>

        <div class="results-bar">
            <p>{!! trans_choice(':count tour found|:count tours found', $tours->count(), ['count' => '<strong>'.$tours->count().'</strong>']) !!}</p>
            <div class="results-tools">
                <label class="sr" for="f-sort">{{ __('Sort') }}</label>
                <select id="f-sort" name="sort" form="filters" data-autosubmit>
                    <option value="recommended" @selected(($filters['sort'] ?? '') === 'recommended')>{{ __('Recommended') }}</option>
                    <option value="price_asc" @selected(($filters['sort'] ?? '') === 'price_asc')>{{ __('Price: low to high') }}</option>
                    <option value="price_desc" @selected(($filters['sort'] ?? '') === 'price_desc')>{{ __('Price: high to low') }}</option>
                    <option value="duration" @selected(($filters['sort'] ?? '') === 'duration')>{{ __('Shortest first') }}</option>
                </select>
                <button type="button" class="btn btn-outline" data-map-toggle aria-pressed="true"
                        data-show-label="{{ __('Show map') }}" data-hide-label="{{ __('Hide map') }}"><x-icon name="map" size="18" /><span>{{ __('Hide map') }}</span></button>
            </div>
        </div>

        <div class="area-bar" aria-live="polite">
            <x-icon name="pin" size="18" />
            <span data-area-status>{{ __('Tip: click anywhere on the map to see the adventures available in that area.') }}</span>
            <label class="sr" for="area-radius">{{ __('Search radius') }}</label>
            <select id="area-radius">@foreach ([25, 50, 100, 200] as $km)<option value="{{ $km }}" @selected($km === 50)>{{ $km }} km</option>@endforeach</select>
            <button type="button" class="link-quiet" data-area-clear hidden>{{ __('Clear the area search') }}</button>
        </div>

        <div class="finder-split">
            <div class="finder-list">
                @forelse ($tours as $tour)
                    <x-tour-card :tour="$tour" />
                @empty
                    <div class="empty">
                        <x-icon name="wheel" size="44" />
                        <h3>{{ __('No tours match these filters') }}</h3>
                        <p>{{ __('Try another bike type or level, or remove the price limit.') }}</p>
                        <a class="btn btn-green" href="{{ route('tours.index') }}">{{ __('Show all tours') }}</a>
                    </div>
                @endforelse
            </div>
            <aside class="finder-map-wrap" aria-label="{{ __('Map of results') }}">
                <div id="finder-map" class="finder-map"></div>
            </aside>
        </div>
    </div>
</section>
@endsection

@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
    <script src="{{ \App\Support\Asset::v('js/maps.js') }}"></script>
    <script>
        const finderMap = MCT.pointsMap('finder-map', @json($mapTours), { linkCards: true });
        MCT.finderControls(finderMap);
        MCT.areaSearch(finderMap, @json($mapTours), {
            radius: document.getElementById('area-radius'),
            status: document.querySelector('[data-area-status]'),
            clear: document.querySelector('[data-area-clear]'),
            items: '.finder-list [data-tour-id]',
            text: { found: @json(__(':count tours within :km km of this point')), none: @json(__('No tours within :km km. Try a bigger radius.')), all: @json(__('Tip: click anywhere on the map to see the adventures available in that area.')) },
        });
    </script>
@endpush
