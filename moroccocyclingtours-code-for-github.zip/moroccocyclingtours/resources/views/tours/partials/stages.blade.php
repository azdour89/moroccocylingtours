{{-- Route details per day: overview, points of interest, surfaces, details, ascents & descents, weather --}}
@php
    use App\Models\RouteStage;
    $stageData = $stages->map(fn ($s) => [
        'route' => $s->route ?? [],
        'profile' => $s->profile ?? [],
        'color' => $tour->activity->color,
        'start' => $s->route[0] ?? ($tour->latitude ? [$tour->latitude, $tour->longitude] : null),
        'pois' => collect($s->pois ?? [])->map(fn ($p) => $p + ['color' => RouteStage::POI_TYPES[$p['type']][1] ?? '#0E7A5F', 'label' => __(RouteStage::POI_TYPES[$p['type']][0] ?? 'Point of interest')])
            ->merge($sites->filter(fn ($site) => collect($s->route ?? [])->contains(fn ($pt) => \App\Support\Gpx::haversine($site->latitude, $site->longitude, $pt[0], $pt[1]) < 8))
                ->map(fn ($site) => ['name' => $site->tr('name'), 'lat' => $site->latitude, 'lng' => $site->longitude, 'color' => '#6B4E9B', 'label' => __('Historic site')]))
            ->values(),
    ])->values();
@endphp
<section class="block stages" id="route" data-stages aria-label="{{ __('Route details') }}">
    <h2>{{ __('Route details, day by day') }}</h2>
    @if ($stages->count() > 1)
        <div class="stage-tabs" role="tablist" aria-label="{{ __('Riding days') }}">
            @foreach ($stages as $i => $s)
                <button type="button" role="tab" data-stage-tab="{{ $i }}" aria-selected="{{ $i === 0 ? 'true' : 'false' }}" aria-controls="stage-{{ $i }}">
                    <span>{{ __('Day :n', ['n' => $s->day]) }}</span>@if ($s->distance_km)<small>{{ $s->distance_km + 0 }} km</small>@endif
                </button>
            @endforeach
        </div>
    @endif

    @foreach ($stages as $i => $s)
        <div class="stage-panel" id="stage-{{ $i }}" role="tabpanel" data-stage-panel="{{ $i }}" @if ($i > 0) hidden @endif>
            <h3 class="stage-title">{{ $s->tr('title') }}</h3>
            @if ($s->tr('description'))<p class="stage-desc">{{ $s->tr('description') }}</p>@endif

            <ul class="stage-stats">
                @if ($s->distance_km)<li><x-icon name="wheel" size="22" /><span>{{ __('Distance') }}</span><strong>{{ $s->distance_km + 0 }} km</strong></li>@endif
                @if ($s->duration_label)<li><x-icon name="stopwatch" size="22" /><span>{{ __('Duration') }}</span><strong>{{ $s->duration_label }}</strong></li>@endif
                @if ($s->ascent_m)<li><x-icon name="mountain" size="22" /><span>{{ __('Ascent') }}</span><strong>↗ {{ number_format($s->ascent_m) }} m</strong></li>@endif
                @if ($s->descent_m)<li><x-icon name="mountain" size="22" class="flipx" /><span>{{ __('Descent') }}</span><strong>↘ {{ number_format($s->descent_m) }} m</strong></li>@endif
                @if ($s->max_alt_m)<li><x-icon name="peak" size="22" /><span>{{ __('Highest point') }}</span><strong>{{ number_format($s->max_alt_m) }} m</strong></li>@endif
                @if ($s->min_alt_m)<li><x-icon name="terrain" size="22" /><span>{{ __('Lowest point') }}</span><strong>{{ number_format($s->min_alt_m) }} m</strong></li>@endif
            </ul>

            <div class="stage-grid">
                <div>
                    <h4>{{ __('Route overview') }}</h4>
                    <div class="stage-map"></div>
                </div>
                <div>
                    <h4>{{ __('Ascents and descents') }}</h4>
                    <div class="stage-profile" id="profile-{{ $i }}"></div>
                    @if ($s->profile_approximate)<p class="note">{{ __('Approximate profile') }}</p>@endif
                    @if (! $s->profile)<p class="note">{{ __('The elevation profile will be added soon.') }}</p>@endif

                    @if ($s->surfaces)
                        <h4>{{ __('Types of paths and surfaces') }}</h4>
                        @php $total = $s->surface_total ?: 1; @endphp
                        <div class="surface-bar" role="img" aria-label="{{ __('Types of paths and surfaces') }}">
                            @foreach ($s->surfaces as $sf)<span style="width: {{ max(1, $sf['km'] / $total * 100) }}%; background: {{ RouteStage::SURFACES[$sf['type']][1] ?? '#B8C2BF' }}"></span>@endforeach
                        </div>
                        <ul class="surface-legend">
                            @foreach ($s->surfaces as $sf)
                                <li><i style="background: {{ RouteStage::SURFACES[$sf['type']][1] ?? '#B8C2BF' }}"></i>{{ __(RouteStage::SURFACES[$sf['type']][0] ?? 'Unknown') }}
                                    <strong>{{ $sf['km'] < 0.1 ? '< 0.1' : number_format($sf['km'], 1) }} km</strong><small>{{ round($sf['km'] / $total * 100) }}%</small></li>
                            @endforeach
                        </ul>
                    @endif
                </div>
            </div>

            @php $pois = collect($stageData[$i]['pois']); @endphp
            @if ($pois->count())
                <h4>{{ __('Points of interest') }}</h4>
                <ul class="poi-list">
                    @foreach ($pois as $p)<li><i style="background: {{ $p['color'] }}"></i><strong>{{ $p['name'] }}</strong><small>{{ $p['label'] }}</small></li>@endforeach
                </ul>
            @endif

            <h4>{{ __('Weather report') }} <small class="muted">· {{ __('5-day forecast at the start of the stage') }}</small></h4>
            <ul class="stage-weather"><li class="wload">{{ __('Loading the forecast…') }}</li></ul>

            <div class="stage-actions">
                @if ($s->gpx_file && $s->gpx_public)<a class="btn btn-outline" href="{{ \App\Support\Media::url($s->gpx_file) }}" download><x-icon name="download" size="18" /> {{ __('Download GPX') }}</a>@endif
                @if ($s->komoot_url)<a class="btn btn-outline" href="{{ $s->komoot_url }}" target="_blank" rel="noopener"><x-icon name="map" size="18" /> {{ __('Open in Komoot') }}</a>@endif
            </div>
        </div>
    @endforeach
</section>
@push('scripts')
    <script src="{{ \App\Support\Asset::v('js/site.js') }}"></script>
    <script>
        window.addEventListener('DOMContentLoaded', () => MCT.stages(document.querySelector('[data-stages]'), @json($stageData), {
            profile: @json(__('Elevation profile')), start: @json(__('Start')), finish: @json(__('Finish')),
            rain: @json(__('Rain')), wind: @json(__('Wind')), unavailable: @json(__('The forecast is not available right now.')),
            codes: { 'sun': @json(__('Sunny')), 'cloud-sun': @json(__('Partly cloudy')), 'cloud': @json(__('Cloudy')), 'rain': @json(__('Rain')), 'snow': @json(__('Snow')), 'storm': @json(__('Thunderstorms')) },
        }));
    </script>
@endpush
