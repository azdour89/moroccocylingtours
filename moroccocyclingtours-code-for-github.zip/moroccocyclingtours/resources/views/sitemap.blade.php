{!! '<?xml version="1.0" encoding="UTF-8"?>' !!}
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">
@foreach ($paths as $path)
@foreach ($locales as $code)
  <url>
    <loc>{{ url($code.$path) }}</loc>
@foreach ($locales as $alt)
    <xhtml:link rel="alternate" hreflang="{{ $alt }}" href="{{ url($alt.$path) }}"/>
@endforeach
@foreach (($images[$path] ?? []) as $p)
    <image:image>
      <image:loc>{{ url(\App\Support\Media::sized($p->image, 1920)) }}</image:loc>
      <image:title>{{ $p->tr('seo_title', $code) ?: $p->tr('caption', $code) }}</image:title>
      <image:caption>{{ $p->tr('description', $code) ?: $p->tr('caption', $code) }}</image:caption>
    </image:image>
@endforeach
@foreach (($videos[$path] ?? []) as $p)
    <video:video>
      <video:thumbnail_loc>{{ url(\App\Support\Media::sized($p->image, 1280)) }}</video:thumbnail_loc>
      <video:title>{{ \Illuminate\Support\Str::limit($p->tr('seo_title', $code) ?: $p->tr('caption', $code), 95, '') }}</video:title>
      <video:description>{{ \Illuminate\Support\Str::limit($p->tr('description', $code) ?: $p->tr('caption', $code), 2000, '') }}</video:description>
      <video:content_loc>{{ url(\App\Support\Media::url($p->video)) }}</video:content_loc>
@if ($p->video_seconds)
      <video:duration>{{ $p->video_seconds }}</video:duration>
@endif
      <video:publication_date>{{ optional($p->created_at)->toIso8601String() }}</video:publication_date>
      <video:family_friendly>yes</video:family_friendly>
    </video:video>
@endforeach
  </url>
@endforeach
@endforeach
</urlset>
