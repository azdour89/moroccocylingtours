<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Admin') | {{ config('site.name') }}</title>
    <link rel="icon" href="{{ asset('img/favicon.svg') }}" type="image/svg+xml">
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Marcellus&display=swap" rel="stylesheet">
    @stack('head')
    <link rel="stylesheet" href="{{ \App\Support\Asset::v('css/admin.css') }}">
</head>
<body>
<div class="admin">
    <aside class="sidebar">
        <a class="side-brand" href="{{ route('admin.dashboard') }}">
            <span class="brand-plaque"><x-logo :height="44" alt="" /></span>
            <span>Morocco<br><small>Cycling Tours admin</small></span>
        </a>
        <nav class="side-nav" aria-label="Admin">
            @php
                $res = \App\Admin\Resources::all();
                $pending = \App\Models\Booking::where('status', 'pending')->count();
                $newLeads = \App\Models\Lead::where('status', 'new')->count();
                $link = fn ($key) => ['url' => route('admin.content.index', $key), 'on' => request()->route('resource') === $key, 'label' => $res[$key]['label'], 'icon' => $res[$key]['icon']];
                $groups = [
                    '' => [
                        ['url' => route('admin.dashboard'), 'on' => request()->routeIs('admin.dashboard'), 'label' => 'Dashboard', 'icon' => 'grid'],
                    ],
                    'Sales' => [
                        ['url' => route('admin.bookings.index'), 'on' => request()->routeIs('admin.bookings.*'), 'label' => 'Bookings', 'icon' => 'pump', 'count' => $pending],
                        $link('leads') + ['count' => $newLeads],
                    ],
                    'Tours' => [
                        ['url' => route('admin.tours.index'), 'on' => request()->routeIs('admin.tours.*'), 'label' => 'Tours', 'icon' => 'map'],
                        ['url' => route('admin.pricing'), 'on' => request()->routeIs('admin.pricing*'), 'label' => 'Group pricing', 'icon' => 'tag'],
                        ['url' => route('admin.calendar'), 'on' => request()->routeIs('admin.calendar') || request()->route('resource') === 'departures', 'label' => 'Tour calendar', 'icon' => 'calendar'],
                        ['url' => route('admin.activities.index'), 'on' => request()->routeIs('admin.activities.*'), 'label' => 'Activities (bike types)', 'icon' => 'wrench'],
                        $link('categories'), $link('historic-sites'),
                    ],
                    'Rentals' => [$link('rental-bikes'), $link('rental-items'), $link('bike-brands')],
                    'Website' => [
                        $link('pages'), $link('hero-slides'), $link('gallery'), $link('team'), $link('reviews'), $link('posts'), $link('faqs'), $link('events'),
                    ],
                ];
            @endphp
            @foreach ($groups as $title => $items)
                @if ($title)<p class="side-group">{{ $title }}</p>@endif
                @foreach ($items as $it)
                    <a href="{{ $it['url'] }}" @class(['on' => $it['on']])><x-icon :name="$it['icon']" size="20" /> {{ $it['label'] }}@if (! empty($it['count']))<span class="count">{{ $it['count'] }}</span>@endif</a>
                @endforeach
            @endforeach
        </nav>
        <div class="side-foot">
            <a href="{{ route('home') }}" target="_blank" rel="noopener"><x-icon name="eye" size="18" /> View website</a>
            <form method="post" action="{{ route('logout') }}">@csrf<button type="submit"><x-icon name="logout" size="18" /> Log out</button></form>
        </div>
    </aside>

    <div class="content">
        <header class="topbar">
            <div>
                @hasSection('back')<a class="back" href="@yield('back')"><x-icon name="arrow-left" size="16" /> Back</a>@endif
                <h1>@yield('heading')</h1>
            </div>
            <div class="topbar-actions">@yield('actions')</div>
        </header>

        @if (session('status'))<div class="flash flash-ok" role="status"><x-icon name="check" size="18" /> {{ session('status') }}</div>@endif
        @if (session('error'))<div class="flash flash-err" role="alert"><x-icon name="x" size="18" /> {{ session('error') }}</div>@endif
        @if ($errors->any())
            <div class="flash flash-err" role="alert"><x-icon name="x" size="18" /> Check the highlighted fields: {{ $errors->count() }} {{ Str::plural('problem', $errors->count()) }} found.</div>
        @endif

        @yield('content')
    </div>
</div>
@stack('scripts')
</body>
</html>
