@php use App\Support\Locale; @endphp
<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @php
        $metaTitle = trim($__env->yieldContent('title')) ?: config('site.name').' | '.__(config('site.tagline'));
        $metaDesc = trim($__env->yieldContent('meta_description')) ?: __(config('site.tagline'));
        $metaImage = trim($__env->yieldContent('og_image')) ?: asset('img/og-default.png');   // share preview: page photo, else the logo
    @endphp
    <title>{{ $metaTitle }}</title>
    <meta name="description" content="{{ $metaDesc }}">
    <link rel="canonical" href="{{ trim($__env->yieldContent('canonical')) ?: url()->current() }}">
    @foreach (Locale::all() as $code => $label)
        <link rel="alternate" hreflang="{{ $code }}" href="{{ Locale::switchUrl($code) }}">
    @endforeach
    <link rel="alternate" hreflang="x-default" href="{{ Locale::switchUrl(Locale::fallback()) }}">
    <meta property="og:type" content="@yield('og_type', 'website')">
    <meta property="og:site_name" content="{{ config('site.name') }}">
    <meta property="og:title" content="{{ $metaTitle }}">
    <meta property="og:description" content="{{ $metaDesc }}">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:locale" content="{{ app()->getLocale() }}">
    <meta property="og:image" content="{{ $metaImage }}"><meta name="twitter:card" content="summary_large_image">
    <link rel="icon" href="{{ asset('img/favicon.svg') }}" type="image/svg+xml">
    <link rel="apple-touch-icon" href="{{ asset('img/apple-touch-icon.png') }}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Marcellus&display=swap" rel="stylesheet">
    @stack('head')
    <link rel="stylesheet" href="{{ \App\Support\Asset::v('css/site.css') }}">
</head>
<body class="@yield('body_class')">
<a class="skip" href="#main">{{ __('Skip to content') }}</a>

<header class="site-header">
    <div class="wrap header-inner">
        <a href="{{ route('home') }}" class="brand" aria-label="{{ config('site.name') }}">
            <span class="brand-plaque"><x-logo :height="64" alt="" /></span>
            <span class="brand-name">Morocco<span>Cycling Tours</span></span>
        </a>
        <button class="nav-toggle" aria-expanded="false" aria-controls="main-nav"><x-icon name="menu" /><span class="sr">{{ __('Menu') }}</span></button>
        <nav class="main-nav" id="main-nav" aria-label="{{ __('Main') }}">
            <div class="nav-item has-menu">
                <a href="{{ route('tours.index') }}" @class(['active' => request()->routeIs('tours.*', 'trips.*')])>{{ __('Tours') }}</a>
                <button type="button" class="menu-toggle" aria-expanded="false" aria-label="{{ __('Tours') }}"><x-icon name="chevron" size="14" /></button>
                <ul class="menu">
                    <li><a href="{{ route('tours.index') }}"><x-icon name="map" size="18" /> {{ __('All tours on the map') }}</a></li>
                    @foreach ($navCategories as $c)
                        <li><a href="{{ route('trips.show', $c->slug) }}"><x-icon :name="$c->icon" size="18" /> {{ $c->tr('name') }}</a></li>
                    @endforeach
                </ul>
            </div>
            <div class="nav-item has-menu">
                <a href="{{ route('bikes.index') }}" @class(['active' => request()->routeIs('bikes.*')])>{{ __('Bike types') }}</a>
                <button type="button" class="menu-toggle" aria-expanded="false" aria-label="{{ __('Bike types') }}"><x-icon name="chevron" size="14" /></button>
                <ul class="menu">
                    <li><a href="{{ route('bikes.index') }}"><x-icon name="star8" size="18" /> {{ __('All bike types') }}</a></li>
                    <li><a href="{{ route('rental') }}"><x-icon name="wrench" size="18" /> {{ __('Bike rental') }}</a></li>
                    @foreach ($navActivities as $a)
                        <li><a href="{{ route('bikes.show', $a->slug) }}" style="--c: {{ $a->color }}"><x-icon :name="$a->icon" size="18" class="c-ico" /> {{ $a->tr('name') }}</a></li>
                    @endforeach
                </ul>
            </div>
            <div class="nav-item has-menu">
                <a href="{{ route('about') }}" @class(['active' => request()->routeIs('about', 'testimonials', 'events', 'gallery', 'historic-sites')])>{{ __('Discover') }}</a>
                <button type="button" class="menu-toggle" aria-expanded="false" aria-label="{{ __('Discover') }}"><x-icon name="chevron" size="14" /></button>
                <ul class="menu">
                    <li><a href="{{ route('about') }}"><x-icon name="helmet" size="18" /> {{ __('About us') }}</a></li>
                    <li><a href="{{ route('testimonials') }}"><x-icon name="check" size="18" /> {{ __('Testimonials') }}</a></li>
                    <li><a href="{{ route('events') }}"><x-icon name="calendar" size="18" /> {{ __('Events') }}</a></li>
                    <li><a href="{{ route('gallery') }}"><x-icon name="eye" size="18" /> {{ __('Gallery') }}</a></li>
                    <li><a href="{{ route('historic-sites') }}"><x-icon name="peak" size="18" /> {{ __('Historic sites') }}</a></li>
                </ul>
            </div>
            <a href="{{ route('blog.index') }}" @class(['active' => request()->routeIs('blog.*')])>{{ __('Blog') }}</a>
            <a href="{{ route('faq') }}" @class(['active' => request()->routeIs('faq')])>{{ __('FAQ') }}</a>
            <a href="{{ route('contact') }}" class="nav-cta">{{ __('Plan a private trip') }}</a>
        </nav>
        <details class="lang">
            <summary aria-label="{{ __('Language') }}: {{ Locale::all()[app()->getLocale()] }}"><x-icon name="globe" size="18" /><span>{{ strtoupper(app()->getLocale()) }}</span></summary>
            <ul>
                @foreach (Locale::all() as $code => $label)
                    <li><a href="{{ Locale::switchUrl($code) }}" hreflang="{{ $code }}" lang="{{ $code }}" @if ($code === app()->getLocale()) aria-current="true" @endif>{{ $label }}</a></li>
                @endforeach
            </ul>
        </details>
    </div>
</header>

<main id="main">
    @yield('content')
</main>

<x-frieze />
<footer class="site-footer" id="footer">
    <div class="wrap footer-grid footer-grid-4">
        <div>
            <a href="{{ route('home') }}" class="footer-logo" aria-label="{{ config('site.name') }}"><span class="brand-plaque"><x-logo :height="108" :eager="false" alt="" /></span></a>
            <p class="footer-brand">{{ config('site.name') }}</p>
            <p class="muted-light">{{ __(config('site.tagline')) }}. {{ __('Local guides, serviced bikes and pick-up from your riad.') }}</p>
            <p><a class="btn btn-saffron" href="{{ route('contact') }}">{{ __('Plan a private trip') }}</a></p>
        </div>
        <div>
            <h4>{{ __('Tours') }}</h4>
            <ul>
                @foreach ($navCategories as $c)<li><a href="{{ route('trips.show', $c->slug) }}">{{ $c->tr('name') }}</a></li>@endforeach
            </ul>
        </div>
        <div>
            <h4>{{ __('Bike types') }}</h4>
            <ul>
                @foreach ($navActivities as $a)<li><a href="{{ route('bikes.show', $a->slug) }}">{{ __(':name tours', ['name' => $a->tr('name')]) }}</a></li>@endforeach
                <li><a href="{{ route('rental') }}">{{ __('Bike rental') }}</a></li>
            </ul>
        </div>
        <div>
            <h4>{{ __('Discover') }}</h4>
            <ul>
                <li><a href="{{ route('about') }}">{{ __('About us') }}</a></li>
                <li><a href="{{ route('testimonials') }}">{{ __('Testimonials') }}</a></li>
                <li><a href="{{ route('events') }}">{{ __('Events') }}</a></li>
                <li><a href="{{ route('blog.index') }}">{{ __('Blog') }}</a></li>
                <li><a href="{{ route('faq') }}">{{ __('FAQ') }}</a></li>
                <li><a href="{{ route('gallery') }}">{{ __('Gallery') }}</a></li>
                <li><a href="{{ route('historic-sites') }}">{{ __('Historic sites') }}</a></li>
            </ul>
            <h4 class="mt">{{ __('Contact') }}</h4>
            <ul>
                <li><a href="mailto:{{ config('site.email') }}"><x-icon name="mail" size="16" /> {{ config('site.email') }}</a></li>
                <li><a href="tel:{{ preg_replace('/\s+/', '', config('site.phone')) }}"><x-icon name="phone" size="16" /> {{ config('site.phone') }}</a></li>
                <li><a href="https://wa.me/{{ config('site.whatsapp') }}" rel="noopener">{{ __('WhatsApp us') }}</a></li>
            </ul>
        </div>
    </div>
    <div class="wrap footer-base">
        <span>© {{ date('Y') }} {{ config('site.name') }} · {{ config('site.address') }}</span>
        <nav class="footer-langs" aria-label="{{ __('Language') }}">
            @foreach (Locale::all() as $code => $label)
                <a href="{{ Locale::switchUrl($code) }}" lang="{{ $code }}" @if ($code === app()->getLocale()) aria-current="true" @endif>{{ $label }}</a>
            @endforeach
        </nav>
        <a href="{{ route('login') }}">{{ __('Staff login') }}</a>
    </div>
</footer>

<script>
document.querySelector('.nav-toggle')?.addEventListener('click', function () {
    const open = document.body.classList.toggle('nav-open');
    this.setAttribute('aria-expanded', open);
});
document.querySelectorAll('.menu-toggle').forEach((b) => b.addEventListener('click', () => {
    const item = b.closest('.nav-item'), open = !item.classList.contains('open');
    document.querySelectorAll('.nav-item.open').forEach((i) => { i.classList.remove('open'); i.querySelector('.menu-toggle').setAttribute('aria-expanded', 'false'); });
    item.classList.toggle('open', open); b.setAttribute('aria-expanded', String(open));
}));
document.addEventListener('click', (e) => {
    const d = document.querySelector('details.lang');
    if (d && d.open && !d.contains(e.target)) d.open = false;
    if (!e.target.closest('.nav-item')) document.querySelectorAll('.nav-item.open').forEach((i) => i.classList.remove('open'));
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') document.querySelectorAll('.nav-item.open').forEach((i) => i.classList.remove('open')); });
</script>
@stack('scripts')
</body>
</html>
