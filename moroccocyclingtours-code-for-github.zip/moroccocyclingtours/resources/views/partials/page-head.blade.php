{{-- Page header: $title, $subtitle, $crumb, optional $image --}}
<section class="page-head" @if (! empty($image)) style="--head-img: url('{{ \App\Support\Media::sized($image, 1920) }}')" @endif>
    <div class="wrap">
        <nav class="crumbs" aria-label="{{ __('Breadcrumb') }}"><a href="{{ route('home') }}">{{ __('Home') }}</a> <span>/</span> <span aria-current="page">{{ $crumb ?? $title }}</span></nav>
        <h1>{{ $title }}</h1>
        @if (! empty($subtitle))<p class="lede">{{ $subtitle }}</p>@endif
    </div>
</section>
