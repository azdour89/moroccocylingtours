{{-- A gallery item as a figure: optimised photo, or a video player with VideoObject data. Vars: $p (GalleryImage) --}}
@php use App\Support\Media; $dim = Media::dimensions($p->image); @endphp
<figure @class(['post-media', 'is-video' => $p->isVideo()])>
    @if ($p->isVideo())
        <video controls preload="none" playsinline poster="{{ Media::sized($p->image, 1280) }}" @if ($dim) width="{{ $dim[0] }}" height="{{ $dim[1] }}" @endif aria-label="{{ $p->altText() }}">
            <source src="{{ Media::url($p->video) }}" type="video/mp4">
        </video>
        <script type="application/ld+json">{!! json_encode(array_filter(['@context' => 'https://schema.org', '@type' => 'VideoObject', 'name' => $p->titleText(), 'description' => $p->descriptionText(),
            'thumbnailUrl' => url(Media::sized($p->image, 1280)), 'contentUrl' => url(Media::url($p->video)), 'uploadDate' => optional($p->created_at)->toIso8601String(),
            'duration' => $p->video_seconds ? 'PT'.intdiv($p->video_seconds, 60).'M'.($p->video_seconds % 60).'S' : null, 'inLanguage' => app()->getLocale(),
            'publisher' => ['@type' => 'Organization', 'name' => config('site.name')]]), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!}</script>
    @else
        <x-img :src="$p->image" :alt="$p->altText()" :title="$p->titleText()" sizes="(max-width: 900px) 100vw, 760px" />
    @endif
    @if ($p->tr('caption'))<figcaption>{{ $p->tr('caption') }}</figcaption>@endif
</figure>
