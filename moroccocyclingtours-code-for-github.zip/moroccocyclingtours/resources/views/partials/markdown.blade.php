@if (! empty($text)){!! \Illuminate\Support\Str::markdown($text, ['html_input' => 'escape', 'allow_unsafe_links' => false]) !!}@endif
