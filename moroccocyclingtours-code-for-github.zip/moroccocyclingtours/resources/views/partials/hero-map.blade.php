{{-- Semi-transparent mountain-trails map behind the home slider: contour rings around the High Atlas summits, ridge lines, winding trails, tour start points as pins.
     Decorative only (not a survey map). $points = map points of the published tours --}}
@php
    $W = 1000; $H = 640; $lat0 = 32.7; $lat1 = 29.3; $lng0 = -10.4; $lng1 = -4.15;   // High Atlas, equirectangular (1° lng ≈ 0.85° lat)
    $X = fn ($lng) => ($lng - $lng0) / ($lng1 - $lng0) * $W;
    $Y = fn ($lat) => ($lat0 - $lat) / ($lat0 - $lat1) * $H;
    $f = fn ($n) => round($n, 1);
    // [name, lat, lng, height m, rings]
    $peaks = [['Toubkal', 31.059, -7.916, 4167, 7], ['M’Goun', 31.522, -6.447, 4071, 6], ['Ayyachi', 32.483, -4.983, 3737, 5], ['Siroua', 30.09, -7.82, 3304, 5], ['Saghro', 31.0, -5.5, 2712, 4], ['Jbel Lekst', 29.8, -9.15, 2359, 4]];
    // closed, slightly irregular contour ring around a summit, stretched along the Atlas direction (SW to NE)
    $ring = function ($cx, $cy, $r, $seed) use ($f) {
        $pts = [];
        for ($i = 0; $i < 40; $i++) {
            $t = $i / 40 * 2 * M_PI;
            $m = 1 + .2 * sin(3 * $t + $seed) + .1 * sin(5 * $t + 2 * $seed) + .05 * sin(8 * $t + $seed * 3);
            $x = cos($t) * $r * $m * 1.55; $y = sin($t) * $r * $m * .8;
            $a = -.38;   // tilt
            $pts[] = $f($cx + $x * cos($a) - $y * sin($a)).' '.$f($cy + $x * sin($a) + $y * cos($a));
        }

        return 'M'.implode(' L', $pts).'Z';
    };
    // wavy line through two points (ridge / trail); $amp = wiggle size
    $wave = function ($x1, $y1, $x2, $y2, $amp, $seed, $off = 0) use ($f) {
        $len = hypot($x2 - $x1, $y2 - $y1) ?: 1; $nx = -($y2 - $y1) / $len; $ny = ($x2 - $x1) / $len; $n = max(8, (int) ($len / 14)); $pts = [];
        for ($i = 0; $i <= $n; $i++) {
            $u = $i / $n; $w = sin($u * 9 + $seed) * $amp + sin($u * 17 + $seed * 2) * $amp * .45;
            $pts[] = $f($x1 + ($x2 - $x1) * $u + $nx * ($w + $off)).' '.$f($y1 + ($y2 - $y1) * $u + $ny * ($w + $off));
        }

        return 'M'.implode(' L', $pts);
    };
    $px = collect($peaks)->map(fn ($p) => [$p[0], $X($p[2]), $Y($p[1]), $p[3], $p[4]])->all();
    $pins = collect($points ?? [])->filter(fn ($p) => $p['lat'] && $p['lng'] && $p['lat'] <= $lat0 && $p['lat'] >= $lat1 && $p['lng'] >= $lng0 && $p['lng'] <= $lng1)
        ->unique(fn ($p) => round($p['lat'], 2).'|'.round($p['lng'], 2))->values()->map(fn ($p) => [$X($p['lng']), $Y($p['lat'])])->all();
    $marrakech = [$X(-8.0), $Y(31.63)];
@endphp
<div class="hero-map" aria-hidden="true">
    <svg viewBox="0 0 {{ $W }} {{ $H }}" xmlns="http://www.w3.org/2000/svg" focusable="false">
        {{-- the main chain: ridge lines from the Toubkal massif through M'Goun to Ayyachi --}}
        @foreach ([-30, -15, 0, 15, 30] as $k => $off)
            <path class="hm-ridge" d="{{ $wave($px[0][1], $px[0][2], $px[2][1], $px[2][2], 7, 1 + $k, $off) }}"/>
        @endforeach
        {{-- contour rings --}}
        @foreach ($px as $pi => [$name, $cx, $cy, $h, $rings])
            @for ($k = 1; $k <= $rings; $k++)
                <path class="hm-contour {{ $k % 3 === 0 ? 'is-index' : '' }}" d="{{ $ring($cx, $cy, 9 + $k * (7 + $h / 900), $pi * 1.7) }}"/>
            @endfor
        @endforeach
        {{-- winding trails from Marrakech and between the tour start points --}}
        @foreach ($pins as $i => [$x, $y])
            <path class="hm-trail" d="{{ $wave($marrakech[0], $marrakech[1], $x, $y, 9 + ($i % 4) * 3, $i + 2) }}"/>
        @endforeach
        @foreach ($pins as $i => [$x, $y])
            @if ($i > 0 && hypot($x - $pins[$i - 1][0], $y - $pins[$i - 1][1]) < 170)
                <path class="hm-trail alt" d="{{ $wave($pins[$i - 1][0], $pins[$i - 1][1], $x, $y, 6, $i * 3) }}"/>
            @endif
        @endforeach
        {{-- summits --}}
        @foreach ($px as [$name, $cx, $cy, $h, $rings])
            <path class="hm-peak" d="M{{ $f($cx - 7) }} {{ $f($cy + 5) }} L{{ $f($cx) }} {{ $f($cy - 8) }} L{{ $f($cx + 7) }} {{ $f($cy + 5) }}Z"/>
            <text class="hm-label" x="{{ $f($cx) }}" y="{{ $f($cy + 22) }}" text-anchor="middle">{{ $name }}</text>
            <text class="hm-alt" x="{{ $f($cx) }}" y="{{ $f($cy + 36) }}" text-anchor="middle">{{ number_format($h) }} m</text>
        @endforeach
        <circle class="hm-city" cx="{{ $f($marrakech[0]) }}" cy="{{ $f($marrakech[1]) }}" r="4"/>
        <text class="hm-label" x="{{ $f($marrakech[0] - 10) }}" y="{{ $f($marrakech[1] + 5) }}" text-anchor="end">Marrakech</text>
        @foreach ($pins as $i => [$x, $y])
            <circle class="hm-pulse" cx="{{ $f($x) }}" cy="{{ $f($y) }}" r="5" style="animation-delay: {{ round(($i % 7) * .45, 2) }}s"/>
            <circle class="hm-pin" cx="{{ $f($x) }}" cy="{{ $f($y) }}" r="4"/>
        @endforeach
    </svg>
</div>
