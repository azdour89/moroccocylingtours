@extends('layouts.app')
@php
    use App\Support\Media;
    use Illuminate\Support\Str;
    $h1 = $page->tr('title') ?: __('Guided Cycling & Gravel Bike Tours in Morocco');
    $sub = $page->tr('subtitle') ?: __('Experience the High Atlas Mountains, ancient Kasbahs and Saharan tracks with Morocco’s premier local cycling guides.');
    $badges = $page->badgeList() ?: [__('Licensed Moroccan tour operator'), __('100% supported trips with support vehicles'), __('Top-rated local guides')];
    $firstSlide = $slides->first();
@endphp

@section('title', $page->tr('meta_title') ?: __('Guided Morocco Cycling Tours & Bike Holidays | Atlas to Sahara'))
@section('meta_description', $page->tr('meta_description') ?: __('Discover Morocco on two wheels. Guided gravel, road and e-bike tours through the High Atlas Mountains, Dades Valley and Sahara Desert. Book your trip today!'))
@section('og_image', $firstSlide ? url(Media::sized($firstSlide->image, 1280)) : '')
@section('body_class', 'page-home')

@push('head')
    @if ($firstSlide && Media::srcset($firstSlide->image))
        @if (Media::hasAvif($firstSlide->image))
            <link rel="preload" as="image" type="image/avif" imagesrcset="{{ Media::srcset($firstSlide->image, 'avif') }}" imagesizes="100vw" fetchpriority="high">
        @else
            <link rel="preload" as="image" type="image/webp" imagesrcset="{{ Media::srcset($firstSlide->image) }}" imagesizes="100vw" fetchpriority="high">
        @endif
    @endif
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">
    <script type="application/ld+json">{!! json_encode(array_filter([
        '@context' => 'https://schema.org',
        '@type' => ['TravelAgency', 'LocalBusiness'],
        'name' => config('site.name'),
        'url' => route('home'),
        'logo' => asset('img/logo/logo-round-640.png'),
        'image' => $firstSlide ? url(Media::sized($firstSlide->image, 1280)) : null,
        'description' => __('Discover Morocco on two wheels. Guided gravel, road and e-bike tours through the High Atlas Mountains, Dades Valley and Sahara Desert. Book your trip today!'),
        'email' => config('site.email'),
        'telephone' => config('site.phone'),
        'priceRange' => '€€',
        'address' => ['@type' => 'PostalAddress', 'streetAddress' => config('site.address'), 'addressLocality' => 'Marrakech', 'addressRegion' => 'Marrakech-Safi', 'addressCountry' => 'MA'],
        'areaServed' => ['Marrakech', 'High Atlas', 'Middle Atlas', 'Dades Valley', 'Draa Valley', 'Sahara', 'Morocco'],
        'openingHours' => config('site.opening_hours'),
        'aggregateRating' => $rating && $rating->n > 0 ? ['@type' => 'AggregateRating', 'ratingValue' => round($rating->avg, 1), 'reviewCount' => $rating->n] : null,
    ]), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) !!}</script>
    @if ($faqs->count())
    <script type="application/ld+json">{!! json_encode([
        '@context' => 'https://schema.org', '@type' => 'FAQPage',
        'mainEntity' => $faqs->map(fn ($f) => ['@type' => 'Question', 'name' => $f->tr('question'), 'acceptedAnswer' => ['@type' => 'Answer', 'text' => strip_tags(Str::markdown($f->answerText()))]])->values(),
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) !!}</script>
    @endif
@endpush

@section('content')
{{-- 1. Hero slider --}}
<section @class(['hero-slider', 'no-slides' => $slides->isEmpty()]) aria-label="{{ __('Featured photos') }}" data-slider>
    @if ($slides->count())
        <div class="slides">
            @foreach ($slides as $i => $s)
                <figure @class(['slide', 'is-active' => $i === 0, 'has-video' => $s->video]) aria-hidden="{{ $i === 0 ? 'false' : 'true' }}" data-caption="{{ $s->tr('caption') }}" data-link="{{ $s->link_url }}">
                    <x-img :src="$s->image" :alt="$s->tr('caption') ?? ''" sizes="100vw" :eager="$i === 0" />
                    @if ($s->video)<video class="slide-video" muted loop playsinline preload="none" disablepictureinpicture tabindex="-1" aria-hidden="true" data-src="{{ Media::url($s->video) }}"></video>@endif
                </figure>
            @endforeach
        </div>
    @endif
    <div class="hero-shade" aria-hidden="true"></div>
    @include('partials.hero-map', ['points' => $mapTours])
    <div class="hero-content wrap">
        <p class="hero-eyebrow">{{ __('Guided cycling tours across Morocco') }}</p>
        <h1>{{ $h1 }}</h1>
        <p class="lede">{{ $sub }}</p>
        <div class="btn-row">
            <a class="btn btn-terra btn-lg" href="{{ route('tours.index') }}">{{ __('Explore all tours') }}</a>
            <a class="btn btn-glass btn-lg" href="{{ route('contact') }}">{{ __('Custom / private trips') }}</a>
        </div>
        <ul class="trust">
            @foreach ($badges as $b)<li><x-icon name="check" size="16" />{{ $b }}</li>@endforeach
        </ul>
    </div>
    @if ($slides->count() > 1)
        <div class="slider-ui wrap">
            <div class="slider-info">
                <p class="slider-count" aria-hidden="true"><span data-cur>01</span><i></i><span>{{ str_pad($slides->count(), 2, '0', STR_PAD_LEFT) }}</span></p>
                <p class="hero-caption" data-cap hidden></p>
            </div>
            <div class="slider-dots" role="tablist">
                @foreach ($slides as $i => $s)<button type="button" role="tab" aria-label="{{ __('Photo :n', ['n' => $i + 1]) }}" @class(['is-active' => $i === 0]) data-dot="{{ $i }}"><i></i></button>@endforeach
            </div>
            <div class="slider-arrows">
                <button type="button" class="slider-btn" data-prev aria-label="{{ __('Previous photo') }}"><x-icon name="arrow-left" size="20" /></button>
                <button type="button" class="slider-btn flip" data-next aria-label="{{ __('Next photo') }}"><x-icon name="arrow-left" size="20" /></button>
            </div>
        </div>
    @endif
</section>

{{-- 2. Quick search --}}
<section class="quick-search-wrap">
    <form class="quick-search wrap" action="{{ route('tours.index') }}" method="get" role="search" aria-label="{{ __('Find your tour') }}">
        <div class="qs-field">
            <label for="qs-style"><x-icon name="gravel" size="18" /> {{ __('Riding style') }}</label>
            <select id="qs-style" name="style">
                <option value="">{{ __('Any style') }}</option>
                @foreach (\App\Models\Tour::STYLES as $k => $st)<option value="{{ $k }}">{{ __($st['label']) }}</option>@endforeach
            </select>
        </div>
        <div class="qs-field">
            <label for="qs-duration"><x-icon name="stopwatch" size="18" /> {{ __('Duration') }}</label>
            <select id="qs-duration" name="duration">
                <option value="">{{ __('Any length') }}</option>
                @foreach (\App\Models\Tour::DURATIONS as $k => $label)<option value="{{ $k }}">{{ __($label) }}</option>@endforeach
            </select>
        </div>
        <div class="qs-field">
            <label for="qs-level"><x-icon name="gauge" size="18" /> {{ __('Difficulty') }}</label>
            <select id="qs-level" name="level[]">
                <option value="">{{ __('Any level') }}</option>
                @foreach (\App\Models\Tour::LEVELS as $k => $label)<option value="{{ $k }}">{{ __($label) }}</option>@endforeach
            </select>
        </div>
        <button class="btn btn-green btn-lg" type="submit"><x-icon name="search" size="18" /> {{ __('Find my tour') }}</button>
    </form>
</section>

{{-- 3. Featured cycling categories --}}
<section class="section">
    <div class="wrap">
        <div class="section-head center">
            <h2>{{ __('Choose Your Moroccan Cycling Adventure') }}</h2>
        </div>
        @php
            $featuredTypes = [
                ['slug' => 'gravel-bike', 'title' => __('Gravel & Adventure Biking'), 'text' => __('Ride remote dirt tracks, ancient caravan routes and high-desert passes from the High Atlas to Erg Chebbi.')],
                ['slug' => 'road-bike', 'title' => __('Road Cycling & Iconic Passes'), 'text' => __('Conquer North Africa’s highest paved roads, including the legendary Tizi n’Tichka and Tizi n’Test passes.')],
                ['slug' => 'e-bike', 'title' => __('E-Bike & Scenic Cultural Tours'), 'text' => __('Explore Berber villages, palm oases and coastal roads with pedal-assist power and full support.')],
            ];
        @endphp
        <div class="type-feature-grid">
            @foreach ($featuredTypes as $ft)
                @php $a = $activities->firstWhere('slug', $ft['slug']); @endphp
                @if ($a)
                <a class="type-feature" href="{{ route('bikes.show', $a->slug) }}" style="--c: {{ $a->color }}">
                    <span class="tf-media">
                        @if ($a->image)<x-img :src="$a->image" alt="" sizes="(max-width: 900px) 100vw, 33vw" />@else<span class="tf-ph"><x-icon :name="$a->icon" size="80" /></span>@endif
                    </span>
                    <span class="tf-body">
                        <span class="bike-chip"><x-icon :name="$a->icon" size="18" />{{ trans_choice(':count tour|:count tours', $a->tours_count) }}</span>
                        <span class="tf-title">{{ $ft['title'] }}</span>
                        <span class="tf-text">{{ $ft['text'] }}</span>
                        <span class="tf-more">{{ __('See the tours') }} →</span>
                    </span>
                </a>
                @endif
            @endforeach
        </div>
        <div class="type-chips">
            <span>{{ __('All bike types:') }}</span>
            @foreach ($activities as $a)
                <a href="{{ route('bikes.show', $a->slug) }}" style="--c: {{ $a->color }}"><x-icon :name="$a->icon" size="18" />{{ $a->tr('name') }}</a>
            @endforeach
            <a class="all" href="{{ route('bikes.index') }}">{{ __('Compare bike types') }} →</a>
        </div>
    </div>
</section>

{{-- 4. Best-selling packages --}}
<section class="section section-tint">
    <div class="wrap">
        <div class="section-head">
            <h2>{{ __('Our Most Popular Bike Itineraries') }}</h2>
            <a class="link-strong" href="{{ route('tours.index') }}">{{ __('See all :count tours', ['count' => $allTours->count()]) }}</a>
        </div>
        <div class="card-grid">
            @foreach ($popular as $tour)<x-tour-card :tour="$tour" />@endforeach
        </div>
    </div>
</section>

{{-- 5. All tours on the map, search by area --}}
<section class="section section-map" id="map-search">
    <div class="wrap">
        <div class="section-head">
            <div>
                <h2>{{ __('Find adventures on the map') }}</h2>
                <p class="section-lede">{{ __('Click anywhere on the map to see the tours that start or pass nearby.') }}</p>
            </div>
            <a class="btn btn-saffron" href="{{ route('tours.index') }}"><x-icon name="map" size="18" /> {{ __('Open the full tour finder') }}</a>
        </div>
        <div class="area-search">
            <div class="area-map-wrap">
                <div id="home-map" class="area-map" aria-label="{{ __('Map of tour starting points') }}"></div>
                <div class="area-controls">
                    <label for="area-radius">{{ __('Search radius') }}</label>
                    <select id="area-radius">
                        @foreach ([25, 50, 100, 200] as $km)<option value="{{ $km }}" @selected($km === 50)>{{ $km }} km</option>@endforeach
                    </select>
                </div>
            </div>
            <div class="area-results" id="area-results" aria-live="polite">
                <p class="area-status" data-area-status>{{ __('Showing all :count tours. Click the map to search an area.', ['count' => $allTours->count()]) }}</p>
                <button type="button" class="link-quiet area-clear" data-area-clear hidden>{{ __('Clear the area search') }}</button>
                <ul class="area-list">
                    @foreach ($allTours as $t)
                        <li data-tour-id="{{ $t->id }}">
                            <a href="{{ route('tours.show', ['tour' => $t->slug]) }}" style="--c: {{ $t->activity->color }}">
                                <span class="al-ico"><x-icon :name="$t->activity->icon" size="22" /></span>
                                <span class="al-text"><strong>{{ $t->tr('title') }}</strong><small>{{ $t->region }} · {{ $t->tr('duration_label') }} · {{ $t->level_label }}</small></span>
                                <span class="al-price">{{ $t->on_request ? __('On request') : $t->price_formatted }}</span>
                            </a>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
</section>

{{-- 6. SEO content block --}}
<section class="section">
    <div class="wrap seo-block">
        <div class="prose">
            <h2>{{ __('Why Ride Morocco? The Ultimate Cycling Destination') }}</h2>
            @if ($page->tr('body'))
                {!! Str::markdown($page->tr('body'), ['html_input' => 'escape', 'allow_unsafe_links' => false]) !!}
            @else
                <p>{{ __('Morocco offers one of the most diverse riding landscapes on earth. From 2,000-metre High Atlas passes to the gravel trails of the Draa Valley oases, every ride blends challenging terrain with rich Berber culture.') }}</p>
            @endif
        </div>
        <aside class="seo-links">
            <h3>{{ __('Popular searches') }}</h3>
            <ul>
                @foreach ($categories as $c)<li><a href="{{ route('trips.show', $c->slug) }}">{{ $c->tr('name') }}</a></li>@endforeach
                @foreach ($activities as $a)<li><a href="{{ route('bikes.show', $a->slug) }}">{{ __(':name tours in Morocco', ['name' => $a->tr('name')]) }}</a></li>@endforeach
            </ul>
        </aside>
    </div>
</section>

{{-- 7. What's included --}}
<section class="section section-dark">
    <div class="wrap">
        <div class="section-head center"><h2>{{ __('The Morocco Cycling Tours Difference') }}</h2></div>
        <div class="feature-grid">
            <div class="feature"><x-icon name="van" size="40" /><h3>{{ __('Full van & luggage support') }}</h3><p>{{ __('A support vehicle on every stage for safety, snacks and your bags.') }}</p></div>
            <div class="feature"><x-icon name="gravel" size="40" /><h3>{{ __('Premium fleet') }}</h3><p>{{ __('High-spec gravel bikes, carbon road bikes, full-suspension MTBs and e-bikes, serviced after every ride.') }}</p></div>
            <div class="feature"><x-icon name="gps" size="40" /><h3>{{ __('GPX tracks & local guides') }}</h3><p>{{ __('Expert local guides lead the way, and every rider gets offline GPS tracks.') }}</p></div>
            <div class="feature"><x-icon name="house" size="40" /><h3>{{ __('Authentic hospitality') }}</h3><p>{{ __('Boutique riads, traditional mountain gîtes and luxury Saharan camps.') }}</p></div>
        </div>
    </div>
</section>

{{-- Trip types --}}
<section class="section">
    <div class="wrap">
        <div class="section-head"><h2>{{ __('Choose your kind of trip') }}</h2></div>
        <div class="trip-types">
            @foreach ($categories as $c)
                @if ($categoryCounts[$c->slug] ?? 0)
                    <a class="trip-type" href="{{ route('trips.show', $c->slug) }}" style="border-top-color: {{ $c->color }}">
                        <x-icon :name="$c->icon" size="34" />
                        <span class="trip-type-name">{{ $c->tr('name') }}</span>
                        <span class="trip-type-n">{{ trans_choice(':count tour|:count tours', $categoryCounts[$c->slug]) }}</span>
                    </a>
                @endif
            @endforeach
        </div>
    </div>
</section>

{{-- 8. Testimonials --}}
@if ($reviews->count())
<section class="section section-tint">
    <div class="wrap">
        <div class="section-head">
            <h2>{{ __('What our riders say') }}</h2>
            @if ($rating->n)<p class="rating-summary"><x-stars :rating="round($rating->avg)" /> {{ __(':avg out of 5 from :n reviews', ['avg' => number_format($rating->avg, 1), 'n' => $rating->n]) }}</p>@endif
        </div>
        <div class="review-grid">@foreach ($reviews as $r)<x-review :review="$r" />@endforeach</div>
        <p class="center"><a class="link-strong" href="{{ route('testimonials') }}">{{ __('Read all testimonials') }} →</a></p>
    </div>
</section>
@endif

{{-- 9. FAQ --}}
@if ($faqs->count())
<section class="section">
    <div class="wrap faq-wrap">
        <h2>{{ __('Frequently Asked Questions About Cycling in Morocco') }}</h2>
        <div class="faq-list">
            @foreach ($faqs as $f)
                <details class="faq" @if ($loop->first) open @endif>
                    <summary>{{ $f->tr('question') }}</summary>
                    <div class="prose">{!! Str::markdown($f->answerText(), ['html_input' => 'escape', 'allow_unsafe_links' => false]) !!}</div>
                </details>
            @endforeach
        </div>
        <p><a class="link-strong" href="{{ route('faq') }}">{{ __('All questions and answers') }} →</a></p>
    </div>
</section>
@endif

{{-- Bike brands --}}
@if ($brands->count())
<section class="brands-strip" aria-label="{{ __('Bikes in our fleet') }}">
    <div class="wrap">
        <p>{{ __('Bikes in our fleet') }}</p>
        <ul>@foreach ($brands as $b)<li>@if ($b->logo)<img src="{{ Media::url($b->logo) }}" alt="{{ $b->name }}" loading="lazy">@else<span>{{ $b->name }}</span>@endif</li>@endforeach</ul>
    </div>
</section>
@endif

{{-- Blog --}}
@if ($posts->count())
<section class="section section-tint">
    <div class="wrap">
        <div class="section-head"><h2>{{ __('From the blog') }}</h2><a class="link-strong" href="{{ route('blog.index') }}">{{ __('All articles') }} →</a></div>
        <div class="card-grid">@foreach ($posts as $p)<x-post-card :post="$p" />@endforeach</div>
    </div>
</section>
@endif

{{-- 10. Lead capture --}}
<section class="section lead-cta" id="guide">
    <div class="wrap lead-grid">
        <div>
            <h2>{{ __('Ready to Plan Your Moroccan Cycling Journey?') }}</h2>
            <p class="lede">{{ __('Get our :year Morocco route guide and packing list, or ask us for a custom itinerary.', ['year' => now()->year.'/'.(now()->year + 1)]) }}</p>
            <a class="link-light" href="{{ route('contact') }}">{{ __('Plan a private trip') }} →</a>
        </div>
        <div>
            @if (session('lead_ok') === 'guide')
                <div class="flash flash-ok" role="status">
                    <x-icon name="check" size="20" />
                    <div><strong>{{ __('Thank you!') }}</strong>
                        @if (session('guide_url'))<br><a href="{{ session('guide_url') }}" download>{{ __('Download the route guide') }}</a>@else<br>{{ __('We’ll e-mail you the route guide shortly.') }}@endif
                    </div>
                </div>
            @endif
            <form class="lead-form" method="post" action="{{ route('leads.store') }}">
                @csrf
                <input type="hidden" name="type" value="guide">
                <div class="hp" aria-hidden="true"><label>{{ __('Website') }} <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
                <label class="sr" for="lg-name">{{ __('First name') }}</label>
                <input id="lg-name" name="name" placeholder="{{ __('First name') }}" autocomplete="given-name" value="{{ old('name') }}">
                <label class="sr" for="lg-email">{{ __('E-mail address') }}</label>
                <input id="lg-email" type="email" name="email" placeholder="{{ __('E-mail address') }}" autocomplete="email" required value="{{ old('email') }}">
                <button class="btn btn-saffron" type="submit"><x-icon name="download" size="18" /> {{ __('Send me the guide') }}</button>
                @error('email')<p class="err">{{ $message }}</p>@enderror
                <p class="note-light">{{ __('No spam. One e-mail with the guide, and you can unsubscribe at any time.') }}</p>
            </form>
        </div>
    </div>
</section>
@endsection

@push('scripts')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin="" defer></script>
    <script src="{{ \App\Support\Asset::v('js/maps.js') }}" defer></script>
    <script src="{{ \App\Support\Asset::v('js/site.js') }}" defer></script>
    <script>
        window.addEventListener('DOMContentLoaded', () => {
            MCT.slider(document.querySelector('[data-slider]'));
            // load the map only when it scrolls into view (keeps the first load light)
            const el = document.getElementById('home-map');
            const start = () => {
                const map = MCT.pointsMap('home-map', @json($mapTours), { linkCards: true });
                MCT.areaSearch(map, @json($mapTours), {
                    radius: document.getElementById('area-radius'),
                    status: document.querySelector('[data-area-status]'),
                    clear: document.querySelector('[data-area-clear]'),
                    items: '#area-results [data-tour-id]',
                    text: { found: @json(__(':count tours within :km km of this point')), none: @json(__('No tours within :km km. Try a bigger radius.')), all: {{ \Illuminate\Support\Js::from(__('Showing all :count tours. Click the map to search an area.', ['count' => $allTours->count()])) }} },
                });
            };
            if ('IntersectionObserver' in window) {
                const io = new IntersectionObserver((e) => { if (e[0].isIntersecting) { io.disconnect(); start(); } }, { rootMargin: '300px' });
                io.observe(el);
            } else { start(); }
        });
    </script>
@endpush
