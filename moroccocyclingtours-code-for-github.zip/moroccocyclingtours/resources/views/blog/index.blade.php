@extends('layouts.app')
@section('title', ($page->tr('meta_title') ?: ($page->tr('title') ?: __('Blog'))).' | '.config('site.name'))
@section('meta_description', $page->tr('meta_description') ?: $page->tr('subtitle'))
@section('content')
@include('partials.page-head', ['title' => $page->tr('title') ?: __('Blog'), 'subtitle' => $page->tr('subtitle'), 'crumb' => __('Blog')])
<section class="section">
    <div class="wrap">
        <nav class="topic-chips" aria-label="{{ __('Topics') }}">
            <a href="{{ route('blog.index') }}" @class(['on' => ! $topic])>{{ __('All articles') }}</a>
            @foreach (\App\Models\Post::TOPICS as $k => $label)<a href="{{ route('blog.index', ['topic' => $k]) }}" @class(['on' => $topic === $k])>{{ __($label) }}</a>@endforeach
        </nav>
        @if ($posts->count())
            <div class="card-grid">@foreach ($posts as $p)<x-post-card :post="$p" />@endforeach</div>
            {{ $posts->links('admin.partials.pagination') }}
        @else
            <p>{{ __('Articles will appear here soon.') }}</p>
        @endif
    </div>
</section>
@endsection
