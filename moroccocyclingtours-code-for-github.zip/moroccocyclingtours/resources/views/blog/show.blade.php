@extends('layouts.app')
@php
    use App\Support\Markdown;
    use App\Support\Media;
    $title = $post->tr('title');
    $body = Markdown::render($post->publicText($post->tr('body')), true);
    $toc = Markdown::toc($body);
    $faqs = $post->faqList();
    $summary = $post->publicText($post->tr('summary'));
    $minutes = $post->readingMinutes();
    $metaTitle = $post->tr('meta_title') ?: \Illuminate\Support\Str::limit($title, 57);
    $metaDesc = $post->tr('meta_description') ?: $post->short_excerpt;
    $coverAlt = $post->tr('cover_alt') ?: $title;
    $shareUrl = urlencode(url()->current());
    $related = $post->related();
@endphp
@section('title', $metaTitle)
@section('meta_description', $metaDesc)
@section('og_type', 'article')
@section('og_image', $post->cover ? url(Media::sized($post->cover, 1280)) : '')
@push('head')
    <meta property="article:published_time" content="{{ $post->published_at?->toAtomString() }}">
    <meta property="article:modified_time" content="{{ $post->updated_at?->toAtomString() }}">
    <script type="application/ld+json">{!! json_encode(['@context' => 'https://schema.org', '@graph' => array_values(array_filter([
        array_filter(['@type' => 'BlogPosting', 'headline' => $title, 'description' => $metaDesc, 'inLanguage' => app()->getLocale(),
            'datePublished' => $post->published_at?->toAtomString(), 'dateModified' => $post->updated_at?->toAtomString(),
            'image' => $post->cover ? url(Media::sized($post->cover, 1280)) : null, 'keywords' => $post->tr('focus_keyword'),
            'wordCount' => str_word_count(strip_tags($body)), 'timeRequired' => 'PT'.$minutes.'M',
            'author' => ['@type' => $post->author && ! str_contains(strtolower($post->author), 'team') ? 'Person' : 'Organization', 'name' => $post->author ?: config('site.name')],
            'publisher' => ['@type' => 'Organization', 'name' => config('site.name'), 'logo' => ['@type' => 'ImageObject', 'url' => asset('img/logo/logo-round-640.png')]],
            'mainEntityOfPage' => url()->current()]),
        $faqs ? ['@type' => 'FAQPage', 'mainEntity' => array_map(fn ($f) => ['@type' => 'Question', 'name' => $f['q'], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $f['a']]], $faqs)] : null,
        ['@type' => 'BreadcrumbList', 'itemListElement' => [
            ['@type' => 'ListItem', 'position' => 1, 'name' => __('Home'), 'item' => route('home')],
            ['@type' => 'ListItem', 'position' => 2, 'name' => __('Blog'), 'item' => route('blog.index')],
            ['@type' => 'ListItem', 'position' => 3, 'name' => $title, 'item' => url()->current()]]],
    ]))], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) !!}</script>
@endpush

@section('content')
<article class="article">
    <header class="post-head">
        <div class="wrap narrow">
            <nav class="crumbs" aria-label="{{ __('Breadcrumb') }}"><a href="{{ route('home') }}">{{ __('Home') }}</a> <span>/</span> <a href="{{ route('blog.index') }}">{{ __('Blog') }}</a>@if ($post->topic) <span>/</span> <a href="{{ route('blog.index', ['topic' => $post->topic]) }}">{{ __(\App\Models\Post::TOPICS[$post->topic] ?? $post->topic) }}</a>@endif</nav>
            <h1>{{ $title }}</h1>
            <p class="post-meta">
                @if ($post->author)<span>{{ __('By :name', ['name' => $post->author]) }}</span> · @endif
                <time datetime="{{ $post->published_at?->toDateString() }}">{{ $post->published_at?->translatedFormat('j F Y') }}</time>
                @if ($post->updated_at && $post->published_at && $post->updated_at->gt($post->published_at->copy()->addDays(2))) · {{ __('Updated :date', ['date' => $post->updated_at->translatedFormat('j F Y')]) }}@endif
                · {{ trans_choice(':count min read|:count min read', $minutes) }}
            </p>
        </div>
    </header>

    @if ($post->cover)
        <figure class="wrap narrow post-cover"><x-img :src="$post->cover" :alt="$coverAlt" sizes="(max-width: 900px) 100vw, 860px" :eager="true" /></figure>
    @endif

    <div class="wrap narrow">
        @if ($summary)
            <aside class="quick-answer" aria-label="{{ __('Quick answer') }}">
                <p class="qa-label"><x-icon name="check" size="18" /> {{ __('Quick answer') }}</p>
                <div class="prose">{!! Markdown::render($summary) !!}</div>
            </aside>
        @endif

        @if (count($toc) > 2)
            <nav class="toc" aria-label="{{ __('In this article') }}">
                <details open>
                    <summary>{{ __('In this article') }}</summary>
                    <ol>
                        @foreach ($toc as [$id, $text])<li><a href="#{{ $id }}">{{ $text }}</a></li>@endforeach
                        @if ($faqs)<li><a href="#faq">{{ __('Frequently asked questions') }}</a></li>@endif
                    </ol>
                </details>
            </nav>
        @endif

        <div class="prose post-body">{!! $body !!}</div>

        @if ($faqs)
            <section class="post-faq" id="faq">
                <h2>{{ __('Frequently asked questions') }}</h2>
                @foreach ($faqs as $f)
                    <div class="post-faq-item">
                        <h3>{{ $f['q'] }}</h3>
                        <div class="prose">{!! Markdown::render(str_replace('{lang}', app()->getLocale(), $f['a'])) !!}</div>
                    </div>
                @endforeach
            </section>
        @endif

        <div class="callout book-callout">
            <h2>{{ __('Ready to ride Morocco with us?') }}</h2>
            <p>{{ __('Tell us your dates and your level, and we’ll suggest the right tour, or design a private trip for you.') }}</p>
            <div class="btn-row">
                <a class="btn btn-saffron" href="{{ route('tours.index') }}">{{ __('See all tours') }}</a>
                <a class="btn btn-outline" href="{{ route('contact') }}">{{ __('Plan a private trip') }}</a>
            </div>
        </div>

        @if ($post->author)
            <aside class="author-box">
                <span class="author-ava"><x-icon name="helmet" size="30" /></span>
                <div>
                    <p class="author-name">{{ __('Written by :name', ['name' => $post->author]) }}</p>
                    @if ($post->author_bio)<p>{{ $post->author_bio }}</p>@endif
                </div>
            </aside>
        @endif

        <div class="share" aria-label="{{ __('Share this article') }}">
            <span>{{ __('Share this article') }}:</span>
            <a href="https://wa.me/?text={{ urlencode($title) }}%20{{ $shareUrl }}" target="_blank" rel="noopener">WhatsApp</a>
            <a href="https://www.facebook.com/sharer/sharer.php?u={{ $shareUrl }}" target="_blank" rel="noopener">Facebook</a>
            <a href="https://twitter.com/intent/tweet?url={{ $shareUrl }}&text={{ urlencode($title) }}" target="_blank" rel="noopener">X</a>
            <a href="https://www.pinterest.com/pin/create/button/?url={{ $shareUrl }}&description={{ urlencode($title) }}" target="_blank" rel="noopener">Pinterest</a>
            <button type="button" data-copy="{{ url()->current() }}">{{ __('Copy link') }}</button>
        </div>
    </div>
</article>

@if ($related->count())
<section class="section section-tint">
    <div class="wrap">
        <div class="section-head"><h2>{{ __('Related articles') }}</h2><a class="link-strong" href="{{ route('blog.index') }}">{{ __('All articles') }} →</a></div>
        <div class="card-grid">@foreach ($related as $p)<x-post-card :post="$p" />@endforeach</div>
    </div>
</section>
@endif
@endsection
@push('scripts')
<script>
document.querySelector('[data-copy]')?.addEventListener('click', function () {
    navigator.clipboard?.writeText(this.dataset.copy).then(() => { const t = this.textContent; this.textContent = '✓'; setTimeout(() => (this.textContent = t), 1500); });
});
</script>
@endpush
