# Deploying moroccocyclingtours.com (GitHub + Laravel Forge)

This folder is the project's own code. It is laid on top of a fresh Laravel install:

    composer create-project laravel/laravel moroccocyclingtours
    cd moroccocyclingtours
    composer require league/commonmark
    # copy the contents of this folder over it (overwrite), then:
    cp .env.example .env && php artisan key:generate
    php artisan migrate --seed && php artisan storage:link

Photos and videos are in the separate media zip: unzip it so the files end up in storage/app/public/.
Then push to GitHub (the media stays out because of .gitignore) and deploy with Forge.
After the first deploy upload the media with:

    rsync -avz storage/app/public/ forge@YOUR-SERVER-IP:/home/forge/moroccocyclingtours.com/storage/app/public/

and on the server run:  php artisan storage:link && php artisan db:seed --force
then the extra batches: FleetSeeder, GalleryEnrichSeeder, HeroQualitySeeder, BlogMediaSeeder
(php artisan db:seed --class=NAME --force).

Forge deploy script (do not add db:seed):

    cd $FORGE_SITE_PATH
    git pull origin $FORGE_SITE_BRANCH
    $FORGE_COMPOSER install --no-dev --no-interaction --prefer-dist --optimize-autoloader
    ( flock -w 10 9 || exit 1; sudo -S service $FORGE_PHP_FPM reload ) 9>/tmp/fpmlock
    $FORGE_PHP artisan migrate --force
    $FORGE_PHP artisan config:cache && $FORGE_PHP artisan route:cache && $FORGE_PHP artisan view:cache
