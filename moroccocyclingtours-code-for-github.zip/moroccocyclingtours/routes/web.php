<?php

use App\Http\Controllers\Admin\ActivityController as AdminActivityController;
use App\Http\Controllers\Admin\BookingController as AdminBookingController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\TourController as AdminTourController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Admin\CalendarController;
use App\Http\Controllers\Admin\ContentController;
use App\Http\Controllers\Admin\StageController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\LeadController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\SitemapController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LocaleRedirectController;
use App\Http\Controllers\TourController;
use App\Support\Locale;
use Illuminate\Support\Facades\Route;

// "/" and old un-prefixed links → the visitor's language (saved choice, then browser language)
Route::get('/', LocaleRedirectController::class);
Route::get('/sitemap.xml', SitemapController::class)->name('sitemap');
Route::get('/tours/{path?}', LocaleRedirectController::class)->where('path', '.*');

// Public site in every language: /en, /fr/tours, /de/tours/agafay-desert-gravel-loop …
Route::prefix('{locale}')
    ->where(['locale' => implode('|', Locale::codes())])
    ->middleware('locale')
    ->group(function () {
        Route::get('/', HomeController::class)->name('home');
        Route::get('/tours', [TourController::class, 'index'])->name('tours.index');
        Route::get('/tours/{tour:slug}', [TourController::class, 'show'])->name('tours.show');
        Route::post('/tours/{tour:slug}/book', [BookingController::class, 'store'])
            ->middleware('throttle:10,1')->name('bookings.store');
        Route::get('/trips/{category:slug}', [TourController::class, 'category'])->name('trips.show');
        Route::get('/bikes', [PageController::class, 'bikes'])->name('bikes.index');
        Route::get('/bikes/{activity:slug}', [TourController::class, 'bike'])->name('bikes.show');
        Route::get('/about', [PageController::class, 'about'])->name('about');
        Route::get('/faq', [PageController::class, 'faq'])->name('faq');
        Route::get('/events', [PageController::class, 'events'])->name('events');
        Route::get('/testimonials', [PageController::class, 'testimonials'])->name('testimonials');
        Route::get('/gallery', [PageController::class, 'gallery'])->name('gallery');
        Route::get('/bike-rental', [App\Http\Controllers\RentalController::class, 'index'])->name('rental');
        Route::get('/historic-sites', [PageController::class, 'historicSites'])->name('historic-sites');
        Route::get('/contact', [PageController::class, 'contact'])->name('contact');
        Route::post('/contact', [LeadController::class, 'store'])->middleware('throttle:6,1')->name('leads.store');
        Route::get('/blog', [BlogController::class, 'index'])->name('blog.index');
        Route::get('/blog/{post:slug}', [BlogController::class, 'show'])->name('blog.show');
    });

// Staff login
Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'show'])->name('login');
    Route::post('/login', [LoginController::class, 'login'])->middleware('throttle:5,1');
});
Route::post('/logout', [LoginController::class, 'logout'])->middleware('auth')->name('logout');

// Admin panel (English)
Route::prefix('admin')->name('admin.')->middleware(['auth', 'admin'])->group(function () {
    Route::get('/', DashboardController::class)->name('dashboard');
    Route::patch('tours/{tour}/toggle', [AdminTourController::class, 'toggle'])->name('tours.toggle');
    Route::resource('tours', AdminTourController::class)->except('show');
    Route::resource('activities', AdminActivityController::class)->except('show');
    Route::resource('bookings', AdminBookingController::class)->only(['index', 'show', 'update', 'destroy']);
    Route::get('calendar', CalendarController::class)->name('calendar');
    Route::get('pricing', [\App\Http\Controllers\Admin\PricingController::class, 'edit'])->name('pricing');
    Route::put('pricing', [\App\Http\Controllers\Admin\PricingController::class, 'update'])->name('pricing.update');
    Route::resource('tours.stages', StageController::class)->except(['index', 'show']);

    // Content sections (pages, slider, categories, gallery, team, brands, reviews, blog, FAQs, events, leads…)
    Route::prefix('content/{resource}')->name('content.')->group(function () {
        Route::get('/', [ContentController::class, 'index'])->name('index');
        Route::get('/create', [ContentController::class, 'create'])->name('create');
        Route::post('/', [ContentController::class, 'store'])->name('store');
        Route::get('/{id}/edit', [ContentController::class, 'edit'])->whereNumber('id')->name('edit');
        Route::put('/{id}', [ContentController::class, 'update'])->whereNumber('id')->name('update');
        Route::delete('/{id}', [ContentController::class, 'destroy'])->whereNumber('id')->name('destroy');
    });
});
