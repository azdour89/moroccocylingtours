<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // gallery: bike category, SEO fields, optional video
        Schema::table('gallery_images', function (Blueprint $t) {
            $t->unsignedBigInteger('activity_id')->nullable()->index();
            $t->string('seo_title', 160)->nullable();
            $t->string('alt_text', 255)->nullable();
            $t->text('description')->nullable();
            $t->string('video')->nullable();
        });
        Schema::table('hero_slides', fn (Blueprint $t) => $t->string('video')->nullable());
        Schema::table('bike_brands', fn (Blueprint $t) => $t->string('image')->nullable());

        // one photo can belong to several tours
        Schema::create('gallery_image_tour', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('gallery_image_id');
            $t->unsignedBigInteger('tour_id')->index();
            $t->unique(['gallery_image_id', 'tour_id']);
        });
        DB::table('gallery_images')->whereNotNull('tour_id')->get(['id', 'tour_id'])->each(
            fn ($r) => DB::table('gallery_image_tour')->insertOrIgnore(['gallery_image_id' => $r->id, 'tour_id' => $r->tour_id])
        );

        // rental fleet
        Schema::create('rental_bikes', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('bike_brand_id')->nullable()->index();
            $t->unsignedBigInteger('activity_id')->nullable()->index();
            $t->string('name');
            $t->string('slug')->unique();
            $t->unsignedSmallInteger('model_year')->nullable();
            $t->text('description')->nullable();
            $t->string('sizes', 80)->nullable();
            $t->string('rider_height', 80)->nullable();
            $t->string('wheel_size', 40)->nullable();
            $t->unsignedSmallInteger('travel_front')->nullable();
            $t->unsignedSmallInteger('travel_rear')->nullable();
            $t->string('frame_material', 80)->nullable();
            $t->decimal('weight_kg', 5, 1)->nullable();
            $t->string('motor', 120)->nullable();
            $t->unsignedSmallInteger('battery_wh')->nullable();
            $t->decimal('price_day', 8, 2)->nullable();
            $t->decimal('deposit', 8, 2)->nullable();
            $t->unsignedSmallInteger('quantity')->default(1);
            $t->string('image')->nullable();
            $t->json('specs')->nullable();
            $t->string('source_url')->nullable();
            $t->boolean('is_published')->default(true);
            $t->unsignedSmallInteger('sort_order')->default(0);
            $t->json('translations')->nullable();
            $t->timestamps();
        });

        // equipment that guests can rent with a tour
        Schema::create('rental_items', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('slug')->unique();
            $t->string('category', 30)->default('gear');
            $t->text('description')->nullable();
            $t->decimal('price', 8, 2)->default(0);
            $t->string('unit', 12)->default('day');
            $t->unsignedSmallInteger('max_qty')->default(10);
            $t->string('applies_to')->nullable();
            $t->string('image')->nullable();
            $t->boolean('is_published')->default(true);
            $t->unsignedSmallInteger('sort_order')->default(0);
            $t->json('translations')->nullable();
            $t->timestamps();
        });
        Schema::create('rental_item_tour', function (Blueprint $t) {
            $t->id();
            $t->unsignedBigInteger('rental_item_id');
            $t->unsignedBigInteger('tour_id')->index();
            $t->unique(['rental_item_id', 'tour_id']);
        });

        Schema::table('bookings', function (Blueprint $t) {
            $t->json('addons')->nullable();
            $t->decimal('addons_total', 10, 2)->default(0);
        });
    }

    public function down(): void
    {
        Schema::table('bookings', fn (Blueprint $t) => $t->dropColumn(['addons', 'addons_total']));
        Schema::dropIfExists('rental_item_tour');
        Schema::dropIfExists('rental_items');
        Schema::dropIfExists('rental_bikes');
        Schema::dropIfExists('gallery_image_tour');
        Schema::table('bike_brands', fn (Blueprint $t) => $t->dropColumn('image'));
        Schema::table('hero_slides', fn (Blueprint $t) => $t->dropColumn('video'));
        Schema::table('gallery_images', fn (Blueprint $t) => $t->dropColumn(['activity_id', 'seo_title', 'alt_text', 'description', 'video']));
    }
};
