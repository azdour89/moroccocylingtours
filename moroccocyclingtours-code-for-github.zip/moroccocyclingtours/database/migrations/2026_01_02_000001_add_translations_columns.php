<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('activities', function (Blueprint $table) {
            $table->json('translations')->nullable()->after('description');
        });
        Schema::table('tours', function (Blueprint $table) {
            $table->json('translations')->nullable()->after('what_to_bring');
        });
        Schema::table('bookings', function (Blueprint $table) {
            $table->string('locale', 5)->default('en')->after('status');
        });
    }

    public function down(): void
    {
        Schema::table('activities', fn (Blueprint $t) => $t->dropColumn('translations'));
        Schema::table('tours', fn (Blueprint $t) => $t->dropColumn('translations'));
        Schema::table('bookings', fn (Blueprint $t) => $t->dropColumn('locale'));
    }
};
