<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('gallery_images', fn (Blueprint $t) => $t->unsignedSmallInteger('video_seconds')->nullable());
    }

    public function down(): void
    {
        Schema::table('gallery_images', fn (Blueprint $t) => $t->dropColumn('video_seconds'));
    }
};
