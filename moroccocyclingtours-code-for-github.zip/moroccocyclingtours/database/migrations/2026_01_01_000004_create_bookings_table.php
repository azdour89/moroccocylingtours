<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('bookings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tour_id')->nullable()->constrained()->nullOnDelete();
            $table->string('tour_title');
            $table->string('reference', 20)->unique();
            $table->string('name');
            $table->string('email');
            $table->string('phone', 40)->nullable();
            $table->string('country', 80)->nullable();
            $table->date('tour_date');
            $table->unsignedSmallInteger('participants')->default(1);
            $table->string('pickup_location', 160)->nullable();
            $table->text('message')->nullable();
            $table->decimal('total_price', 10, 2)->default(0);
            $table->string('status', 20)->default('pending');
            $table->text('admin_notes')->nullable();
            $table->timestamps();

            $table->index(['status', 'tour_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('bookings');
    }
};
