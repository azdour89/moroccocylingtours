<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tours', function (Blueprint $table) {
            $table->string('category', 30)->default('day')->after('activity_id')->index();
            // 4×4 desert & culture tours have no bike type
            $table->foreignId('activity_id')->nullable()->change();
        });
    }

    public function down(): void
    {
        Schema::table('tours', function (Blueprint $table) {
            $table->dropColumn('category');
        });
    }
};
