<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('categories', function (Blueprint $t) {
            $t->id();
            $t->string('slug')->unique();
            $t->string('name');
            $t->string('icon')->default('map');
            $t->string('color', 7)->default('#0E7A5F');
            $t->text('description')->nullable();
            $t->string('image')->nullable();
            $t->integer('sort_order')->default(0);
            $t->json('translations')->nullable();
            $t->timestamps();
        });

        Schema::table('activities', fn (Blueprint $t) => $t->string('image')->nullable()->after('color'));

        Schema::create('pages', function (Blueprint $t) {
            $t->id();
            $t->string('slug')->unique();
            $t->string('title');
            $t->string('subtitle', 300)->nullable();
            $t->longText('body')->nullable();
            $t->text('badges')->nullable();
            $t->string('meta_title', 70)->nullable();
            $t->string('meta_description', 170)->nullable();
            $t->string('image')->nullable();
            $t->string('guide_file')->nullable();
            $t->json('translations')->nullable();
            $t->timestamps();
        });

        Schema::create('hero_slides', function (Blueprint $t) {
            $t->id();
            $t->string('image');
            $t->string('caption')->nullable();
            $t->string('link_url')->nullable();
            $t->integer('sort_order')->default(0);
            $t->boolean('is_active')->default(true);
            $t->json('translations')->nullable();
            $t->timestamps();
        });

        Schema::create('route_stages', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tour_id')->constrained()->cascadeOnDelete();
            $t->unsignedSmallInteger('day')->default(1);
            $t->string('title');
            $t->text('description')->nullable();
            $t->string('komoot_url', 500)->nullable();
            $t->string('gpx_file')->nullable();
            $t->boolean('gpx_public')->default(false);
            $t->decimal('distance_km', 7, 1)->nullable();
            $t->unsignedInteger('ascent_m')->nullable();
            $t->unsignedInteger('descent_m')->nullable();
            $t->unsignedInteger('max_alt_m')->nullable();
            $t->unsignedInteger('min_alt_m')->nullable();
            $t->string('duration_label', 60)->nullable();
            $t->json('route')->nullable();
            $t->json('profile')->nullable();
            $t->boolean('profile_approximate')->default(false);
            $t->json('surfaces')->nullable();
            $t->json('pois')->nullable();
            $t->json('translations')->nullable();
            $t->timestamps();
            $t->index(['tour_id', 'day']);
        });

        Schema::create('departures', function (Blueprint $t) {
            $t->id();
            $t->foreignId('tour_id')->constrained()->cascadeOnDelete();
            $t->date('start_date');
            $t->date('end_date')->nullable();
            $t->unsignedSmallInteger('spots')->nullable();
            $t->unsignedSmallInteger('spots_taken')->default(0);
            $t->decimal('price', 10, 2)->nullable();
            $t->string('status', 20)->default('open');
            $t->string('note')->nullable();
            $t->timestamps();
            $t->index(['start_date', 'status']);
        });

        Schema::create('historic_sites', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('slug')->unique();
            $t->string('region')->nullable();
            $t->string('period')->nullable();
            $t->text('description')->nullable();
            $t->string('image')->nullable();
            $t->decimal('latitude', 9, 6)->nullable();
            $t->decimal('longitude', 9, 6)->nullable();
            $t->boolean('is_published')->default(true);
            $t->integer('sort_order')->default(0);
            $t->json('translations')->nullable();
            $t->timestamps();
        });

        Schema::create('gallery_images', function (Blueprint $t) {
            $t->id();
            $t->string('image');
            $t->string('caption')->nullable();
            $t->string('album')->nullable();
            $t->foreignId('tour_id')->nullable()->constrained()->nullOnDelete();
            $t->integer('sort_order')->default(0);
            $t->boolean('is_published')->default(true);
            $t->json('translations')->nullable();
            $t->timestamps();
        });

        Schema::create('team_members', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('role')->nullable();
            $t->text('bio')->nullable();
            $t->string('photo')->nullable();
            $t->string('languages')->nullable();
            $t->integer('sort_order')->default(0);
            $t->boolean('is_published')->default(true);
            $t->json('translations')->nullable();
            $t->timestamps();
        });

        Schema::create('bike_brands', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('logo')->nullable();
            $t->string('url')->nullable();
            $t->string('description')->nullable();
            $t->integer('sort_order')->default(0);
            $t->boolean('is_published')->default(true);
            $t->timestamps();
        });

        Schema::create('reviews', function (Blueprint $t) {
            $t->id();
            $t->string('name');
            $t->string('country')->nullable();
            $t->unsignedTinyInteger('rating')->default(5);
            $t->string('title')->nullable();
            $t->text('body');
            $t->foreignId('tour_id')->nullable()->constrained()->nullOnDelete();
            $t->string('source')->nullable();
            $t->date('reviewed_at')->nullable();
            $t->boolean('show_on_home')->default(false);
            $t->boolean('is_published')->default(true);
            $t->timestamps();
        });

        Schema::create('posts', function (Blueprint $t) {
            $t->id();
            $t->string('title');
            $t->string('slug')->unique();
            $t->string('excerpt', 300)->nullable();
            $t->longText('body')->nullable();
            $t->string('cover')->nullable();
            $t->string('author')->nullable();
            $t->dateTime('published_at')->nullable();
            $t->boolean('is_published')->default(true);
            $t->json('translations')->nullable();
            $t->timestamps();
        });

        Schema::create('faqs', function (Blueprint $t) {
            $t->id();
            $t->string('question');
            $t->text('answer');
            $t->string('group', 40)->default('general');
            $t->boolean('show_on_home')->default(false);
            $t->integer('sort_order')->default(0);
            $t->boolean('is_published')->default(true);
            $t->json('translations')->nullable();
            $t->timestamps();
        });

        Schema::create('events', function (Blueprint $t) {
            $t->id();
            $t->string('title');
            $t->string('slug')->unique();
            $t->date('starts_at');
            $t->date('ends_at')->nullable();
            $t->string('location')->nullable();
            $t->text('description')->nullable();
            $t->string('image')->nullable();
            $t->string('link_url')->nullable();
            $t->boolean('is_published')->default(true);
            $t->json('translations')->nullable();
            $t->timestamps();
        });

        Schema::create('leads', function (Blueprint $t) {
            $t->id();
            $t->string('type', 20)->default('enquiry');
            $t->string('name')->nullable();
            $t->string('email');
            $t->string('phone', 40)->nullable();
            $t->text('message')->nullable();
            $t->string('travel_date', 60)->nullable();
            $t->unsignedSmallInteger('group_size')->nullable();
            $t->foreignId('tour_id')->nullable()->constrained()->nullOnDelete();
            $t->string('locale', 5)->default('en');
            $t->string('status', 20)->default('new');
            $t->text('admin_notes')->nullable();
            $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach (['leads', 'events', 'faqs', 'posts', 'reviews', 'bike_brands', 'team_members', 'gallery_images',
                  'historic_sites', 'departures', 'route_stages', 'hero_slides', 'pages', 'categories'] as $table) {
            Schema::dropIfExists($table);
        }
        Schema::table('activities', fn (Blueprint $t) => $t->dropColumn('image'));
    }
};
