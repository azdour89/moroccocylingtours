<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('posts', function (Blueprint $t) {
            $t->string('focus_keyword', 120)->nullable()->after('slug');
            $t->string('topic', 40)->nullable()->after('focus_keyword');
            $t->text('summary')->nullable()->after('excerpt');          // quick answer shown at the top
            $t->json('faqs')->nullable()->after('body');               // [{q, a}]
            $t->string('meta_title', 70)->nullable()->after('faqs');
            $t->string('meta_description', 170)->nullable()->after('meta_title');
            $t->string('cover_alt', 200)->nullable()->after('cover');
            $t->text('author_bio')->nullable()->after('author');
        });
    }

    public function down(): void
    {
        Schema::table('posts', fn (Blueprint $t) => $t->dropColumn(['focus_keyword', 'topic', 'summary', 'faqs', 'meta_title', 'meta_description', 'cover_alt', 'author_bio']));
    }
};
