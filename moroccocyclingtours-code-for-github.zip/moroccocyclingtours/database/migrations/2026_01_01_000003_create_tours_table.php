<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tours', function (Blueprint $table) {
            $table->id();
            $table->foreignId('activity_id')->constrained()->restrictOnDelete();
            $table->string('title');
            $table->string('slug')->unique();
            $table->string('excerpt', 300);
            $table->longText('description')->nullable();
            $table->string('image')->nullable();
            $table->json('gallery')->nullable();

            $table->decimal('price', 10, 2)->default(0);
            $table->string('duration_label', 60);
            $table->decimal('duration_hours', 6, 2)->default(4);
            $table->decimal('distance_km', 7, 1)->nullable();
            $table->unsignedInteger('elevation_m')->nullable();
            $table->unsignedInteger('max_altitude_m')->nullable();
            $table->string('level', 20)->default('moderate');
            $table->string('terrain', 120)->nullable();
            $table->string('region', 120);
            $table->string('start_point', 160)->nullable();
            $table->decimal('latitude', 9, 6)->nullable();
            $table->decimal('longitude', 9, 6)->nullable();
            $table->json('route')->nullable();           // [[lat, lng], ...]
            $table->unsignedSmallInteger('capacity')->nullable();
            $table->unsignedTinyInteger('min_age')->nullable();
            $table->string('season', 120)->nullable();

            $table->json('highlights')->nullable();
            $table->json('itinerary')->nullable();       // [{time, text}]
            $table->json('included')->nullable();
            $table->json('not_included')->nullable();
            $table->json('what_to_bring')->nullable();

            $table->boolean('is_featured')->default(false);
            $table->boolean('is_published')->default(true);
            $table->integer('sort_order')->default(0);
            $table->timestamps();

            $table->index(['is_published', 'level']);
            $table->index('region');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tours');
    }
};
