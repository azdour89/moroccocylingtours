<?php

namespace Database\Seeders;

use App\Models\Tour;
use Illuminate\Database\Seeder;

/**
 * One-time update: applies the new titles and subtitles (all 6 languages)
 * to catalogue tours that were already imported.
 *   php artisan db:seed --class=CatalogueTitlesSeeder
 */
class CatalogueTitlesSeeder extends Seeder
{
    public function run(): void
    {
        $titles = json_decode(file_get_contents(database_path('seeders/data/catalogue-titles.json')), true, 512, JSON_THROW_ON_ERROR);

        foreach ($titles as $slug => $langs) {
            $tour = Tour::where('slug', $slug)->first();
            if (! $tour) {
                continue;
            }
            [$tour->title, $tour->subtitle] = $langs['en'];
            $translations = $tour->translations ?? [];
            foreach ($langs as $code => [$title, $subtitle]) {
                if ($code !== 'en') {
                    $translations[$code] = array_merge($translations[$code] ?? [], compact('title', 'subtitle'));
                }
            }
            $tour->translations = $translations;
            $tour->save();
        }
    }
}
