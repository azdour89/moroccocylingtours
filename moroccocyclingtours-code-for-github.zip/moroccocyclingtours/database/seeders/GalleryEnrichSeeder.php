<?php

namespace Database\Seeders;

use App\Models\Activity;
use App\Models\GalleryImage;
use App\Models\HeroSlide;
use App\Models\Tour;
use Illuminate\Database\Seeder;

/**
 * Batch 7: every gallery photo gets a bike type, SEO title, SEO description and alt text (six languages);
 * the new photos from your last upload are added (photos with identifiable guests stay UNPUBLISHED until you have their permission);
 * photos are attached to the matching tour pages; tours without a cover photo get one; five video clips are added
 * (two of them play in the home slider).
 *
 * Safe to run again: it only fills in what is still empty and never overwrites text or photos you changed yourself.
 *   php artisan db:seed --class=GalleryEnrichSeeder
 */
class GalleryEnrichSeeder extends Seeder
{
    private const FIELDS = ['seo_title', 'alt_text', 'description'];

    public function run(): void
    {
        $d = json_decode(file_get_contents(database_path('seeders/data/gallery7.json')), true, 512, JSON_THROW_ON_ERROR);
        $acts = Activity::pluck('id', 'slug');
        $tourIds = Tour::pluck('id', 'slug');
        $byTitle = Tour::pluck('id', 'title');
        $tourId = fn (string $slug) => $tourIds[$slug] ?? (isset($d['tour_titles'][$slug]) ? ($byTitle[$d['tour_titles'][$slug]] ?? null) : null);
        $disk = fn (string $p) => is_file(storage_path('app/public/'.$p));
        $next = (int) GalleryImage::max('sort_order') + 1;

        $stats = ['enriched' => 0, 'added' => 0, 'drafts' => 0, 'linked' => 0, 'videos' => 0, 'covers' => 0];

        foreach ($d['images'] as $e) {
            $g = GalleryImage::where('image', $e['path'])->first();
            if (! $g) {
                if (! $e['new'] || ! $disk($e['path'])) {
                    continue;
                }
                $g = new GalleryImage(['image' => $e['path'], 'album' => $e['album'], 'sort_order' => $next++, 'is_published' => $e['published'], 'caption' => $e['caption']['en'] ?? null]);
                $g->translations = collect($e['caption'])->except('en')->map(fn ($c) => ['caption' => $c])->all();
                $stats[$e['published'] ? 'added' : 'drafts']++;
            }
            $this->fill($g, $e, $acts);
            $g->save();
            $stats['enriched']++;

            $ids = collect($e['tours'])->map($tourId)->filter()->all();
            if ($ids) {
                $g->tours()->syncWithoutDetaching($ids);
                $stats['linked'] += count($ids);
            }
        }

        // gallery videos (the photo is the cover picture)
        foreach ($d['videos']['gallery'] as $e) {
            $g = GalleryImage::where('video', $e['video'])->first();
            if (! $g) {
                if (! $disk($e['video']) || ! $disk($e['poster'])) {
                    continue;
                }
                $g = new GalleryImage(['image' => $e['poster'], 'video' => $e['video'], 'album' => $e['album'], 'sort_order' => $next++, 'is_published' => true, 'caption' => $e['caption']['en']]);
                $g->translations = collect($e['caption'])->except('en')->map(fn ($c) => ['caption' => $c])->all();
                $this->fill($g, $e, $acts);
                $stats['videos']++;
            }
            $g->video_seconds = $g->video_seconds ?: ($e['seconds'] ?? null);
            $g->save();
            // show the clip on the tour pages it belongs to ("Watch the ride")
            $ids = collect($e['tours'] ?? [])->map($tourId)->filter()->all();
            if ($ids) {
                $g->tours()->syncWithoutDetaching($ids);
                $stats['linked'] += count($ids);
            }
        }

        // home slider: two looping videos, added after your existing slides (set "Order" to 0 to show one first)
        $nextSlide = (int) HeroSlide::max('sort_order') + 1;
        foreach ($d['videos']['hero'] as $h) {
            if (HeroSlide::where('video', $h['video'])->exists() || ! $disk($h['video']) || ! $disk($h['poster'])) {
                continue;
            }
            $s = new HeroSlide(['image' => $h['poster'], 'video' => $h['video'], 'caption' => $h['caption']['en'], 'sort_order' => $nextSlide++, 'is_active' => true]);
            $s->translations = collect($h['caption'])->except('en')->map(fn ($c) => ['caption' => $c])->all();
            $s->save();
            $stats['videos']++;
        }

        // tour cover photos (only for tours that have none yet)
        foreach ($d['tour_covers'] as $slug => $path) {
            $t = Tour::find($tourId($slug));
            if ($t && ! $t->image && $disk($path)) {
                $t->update(['image' => $path]);
                $stats['covers']++;
            }
        }

        $this->command?->info('Gallery: '.collect($stats)->map(fn ($v, $k) => "$v $k")->implode(', ').'.');
    }

    /** Fill bike type + SEO fields (English in the column, other languages in translations); keep anything already there */
    private function fill(GalleryImage $g, array $e, $acts): void
    {
        if (! $g->activity_id && ! empty($e['activity'])) {
            $g->activity_id = $acts[$e['activity']] ?? null;
        }
        $tr = $g->translations ?? [];
        foreach (self::FIELDS as $f) {
            foreach ($e[$f] ?? [] as $lang => $text) {
                if ($lang === 'en') {
                    $g->{$f} = $g->{$f} ?: $text;
                } elseif (empty($tr[$lang][$f])) {
                    $tr[$lang][$f] = $text;
                }
            }
        }
        $g->translations = $tr;
    }
}
