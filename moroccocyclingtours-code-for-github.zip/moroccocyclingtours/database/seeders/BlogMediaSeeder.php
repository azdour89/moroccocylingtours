<?php

namespace Database\Seeders;

use App\Models\GalleryImage;
use App\Models\Post;
use Illuminate\Database\Seeder;

/**
 * Puts photos and videos from the gallery inside the blog articles, spread between the sections, in every language.
 * In the article text each one is a line like  [[photo: gallery/xxx.webp]]  (alt text and caption come from the gallery
 * item in the visitor's language). Move or delete these lines in Admin → Blog posts as you like.
 * Articles that already contain a [[photo: ...]] line are left alone. Safe to run again.
 *   php artisan db:seed --class=BlogMediaSeeder
 */
class BlogMediaSeeder extends Seeder
{
    public function run(): void
    {
        $map = json_decode(file_get_contents(database_path('seeders/data/blog_media.json')), true, 512, JSON_THROW_ON_ERROR);
        $count = 0;
        foreach ($map as $slug => $paths) {
            $post = Post::where('slug', $slug)->first();
            $paths = array_values(array_filter($paths, fn ($p) => GalleryImage::where('image', $p)->exists()));
            if (! $post || ! $paths) {
                continue;
            }
            $post->body = $this->insert((string) $post->body, $paths);
            $tr = $post->translations ?? [];
            foreach ($tr as $lang => $fields) {
                if (! empty($fields['body'])) {
                    $tr[$lang]['body'] = $this->insert($fields['body'], $paths);
                }
            }
            $post->translations = $tr;
            $post->save();
            $count++;
        }
        $this->command?->info("Blog: photos and videos added to $count articles.");
    }

    /** Add the items after evenly spaced sections (a section starts at a "## " heading) */
    private function insert(string $body, array $paths): string
    {
        if ($body === '' || str_contains($body, '[[photo:')) {
            return $body;
        }
        $parts = preg_split('/^(?=## )/m', $body);
        $sections = count($parts) - 1;
        if ($sections < 1) {
            return rtrim($body)."\n\n".implode("\n\n", array_map(fn ($p) => "[[photo: $p]]", $paths))."\n";
        }
        $k = count($paths);
        foreach ($paths as $t => $path) {
            $at = min($sections, max(1, (int) floor(($t + 1) * $sections / ($k + 1))));
            $parts[$at] = rtrim($parts[$at])."\n\n[[photo: $path]]\n\n";
        }

        return implode('', $parts);
    }
}
