<?php

namespace Database\Seeders;

use App\Models\Activity;
use App\Models\Tour;
use Illuminate\Database\Seeder;

/**
 * French, Spanish, Italian, German and Dutch content for the demo bike types and tours.
 * Highlights and itineraries stay in English until you translate them in Admin → Tours → Translations.
 */
class TranslationSeeder extends Seeder
{
    public function run(): void
    {
        $activities = [
            'road-bike' => [
                'fr' => ['Vélo de route', 'Asphalte lisse, longues ascensions et cols de montagne sur des vélos de route légers.'],
                'es' => ['Bici de carretera', 'Asfalto liso, largas subidas y puertos de montaña con bicis de carretera ligeras.'],
                'it' => ['Bici da strada', 'Asfalto liscio, lunghe salite e passi di montagna su bici da strada leggere.'],
                'de' => ['Rennrad', 'Glatter Asphalt, lange Anstiege und Bergpässe auf leichten Rennrädern.'],
                'nl' => ['Racefiets', 'Glad asfalt, lange klimmen en bergpassen op lichte racefietsen.'],
            ],
            'gravel-bike' => [
                'fr' => ['Gravel', 'Pistes en terre et petites routes à travers le désert, les palmeraies et l’arganeraie.'],
                'es' => ['Gravel', 'Pistas de tierra y carreteras tranquilas entre desierto, palmerales y bosques de argán.'],
                'it' => ['Gravel', 'Sterrati e strade secondarie tra deserto, palmeti e foreste di argan.'],
                'de' => ['Gravelbike', 'Schotterpisten und ruhige Nebenstraßen durch Wüste, Palmenhaine und Arganwälder.'],
                'nl' => ['Gravelfiets', 'Gravelpaden en rustige binnenwegen door woestijn, palmbossen en arganland.'],
            ],
            'enduro' => [
                'fr' => ['Enduro', 'Descentes sur singletracks rocailleux de l’Atlas avec navette et vélos tout-suspendus.'],
                'es' => ['Enduro', 'Descensos por senderos rocosos del Atlas con remonte en vehículo y bicis de doble suspensión.'],
                'it' => ['Enduro', 'Discese su single track rocciosi dell’Atlante con navetta e bici biammortizzate.'],
                'de' => ['Enduro', 'Abfahrten auf felsigen Atlas-Singletrails mit Shuttle und vollgefederten Bikes.'],
                'nl' => ['Enduro', 'Afdalingen over rotsige singletracks in de Atlas met shuttle en volgeveerde fietsen.'],
            ],
            'cross-country' => [
                'fr' => ['Cross-country', 'Montées et descentes à la force des jambes sur les chemins muletiers entre villages berbères.'],
                'es' => ['Cross-country', 'Sube y baja por tus propios medios por caminos de mulas entre aldeas bereberes.'],
                'it' => ['Cross-country', 'Salite e discese con le tue gambe su mulattiere tra villaggi berberi.'],
                'de' => ['Cross-Country', 'Aus eigener Kraft bergauf und bergab auf Maultierpfaden zwischen Berberdörfern.'],
                'nl' => ['Cross-country', 'Op eigen kracht klimmen en dalen over muilezelpaden tussen Berberdorpen.'],
            ],
            'e-bike' => [
                'fr' => ['Vélo électrique', 'L’assistance électrique permet à tout le groupe d’atteindre le point de vue en gardant de l’énergie.'],
                'es' => ['Bici eléctrica', 'La asistencia eléctrica permite que todo el grupo llegue al mirador con energía de sobra.'],
                'it' => ['E-bike', 'La pedalata assistita porta tutto il gruppo al belvedere con energia da vendere.'],
                'de' => ['E-Bike', 'Mit elektrischer Unterstützung erreicht die ganze Gruppe den Aussichtspunkt mit Energie für mehr.'],
                'nl' => ['E-bike', 'Met elektrische ondersteuning bereikt de hele groep het uitzichtpunt met energie over.'],
            ],
            'city-bike' => [
                'fr' => ['Vélo de ville', 'Balades tranquilles dans la médina, les jardins et la Palmeraie.'],
                'es' => ['Bici urbana', 'Paseos tranquilos por la medina, los jardines y el Palmeral.'],
                'it' => ['Bici da città', 'Giri rilassati tra la medina, i giardini e il Palmeto.'],
                'de' => ['Stadtrad', 'Entspannte Fahrten durch die Medina, Gärten und die Palmeraie.'],
                'nl' => ['Stadsfiets', 'Ontspannen ritten door de medina, de tuinen en de Palmeraie.'],
            ],
        ];

        foreach ($activities as $slug => $langs) {
            if ($a = Activity::where('slug', $slug)->first()) {
                $a->update(['translations' => collect($langs)->map(fn ($v) => ['name' => $v[0], 'description' => $v[1]])->all()]);
            }
        }

        $common = [
            'fr' => [
                'body'  => "Votre guide adapte le rythme au groupe, avec des pauses régulières pour les photos, l’eau et des histoires sur les lieux traversés. L’itinéraire peut être raccourci ou prolongé le jour même.\n\nTous les vélos sont révisés après chaque sortie et réglés à votre taille avant le départ.",
                'season' => 'De septembre à juin. En été, départ au lever du soleil.',
                'included' => ['Prise en charge et retour à votre riad ou hôtel à Marrakech', 'Guide local certifié', 'Location du vélo et du casque', 'Eau et fruits de saison', 'Photos de la sortie'],
                'not_included' => ['Déjeuner sauf mention contraire', 'Assurance voyage personnelle', 'Pourboires pour votre guide'],
                'what_to_bring' => ['Chaussures fermées', 'Lunettes de soleil et crème solaire', 'Une couche légère pour la montagne', 'Petit sac à dos', 'Espèces pour les pourboires et souvenirs'],
            ],
            'es' => [
                'body'  => "Tu guía adapta el ritmo al grupo, con paradas frecuentes para fotos, agua e historias sobre los lugares que recorres. La ruta se puede acortar o alargar el mismo día.\n\nTodas las bicis se revisan después de cada salida y se ajustan a tu medida antes de empezar.",
                'season' => 'De septiembre a junio. En verano salimos al amanecer.',
                'included' => ['Recogida y regreso a tu riad u hotel en Marrakech', 'Guía local certificado', 'Alquiler de bici y casco', 'Agua y fruta de temporada', 'Fotos de la ruta'],
                'not_included' => ['Comida salvo que se indique', 'Seguro de viaje personal', 'Propinas para el guía'],
                'what_to_bring' => ['Calzado cerrado', 'Gafas de sol y protector solar', 'Una capa ligera para la montaña', 'Mochila pequeña', 'Efectivo para propinas y recuerdos'],
            ],
            'it' => [
                'body'  => "La guida adatta il ritmo al gruppo, con soste regolari per foto, acqua e racconti sui luoghi attraversati. Il percorso può essere accorciato o allungato il giorno stesso.\n\nTutte le bici vengono revisionate dopo ogni uscita e regolate su di te prima della partenza.",
                'season' => 'Da settembre a giugno. In estate si parte all’alba.',
                'included' => ['Prelievo e rientro al tuo riad o hotel a Marrakech', 'Guida locale certificata', 'Noleggio bici e casco', 'Acqua e frutta di stagione', 'Foto del giro'],
                'not_included' => ['Pranzo salvo indicazione', 'Assicurazione di viaggio personale', 'Mance per la guida'],
                'what_to_bring' => ['Scarpe chiuse', 'Occhiali da sole e crema solare', 'Uno strato leggero per la montagna', 'Zainetto', 'Contanti per mance e souvenir'],
            ],
            'de' => [
                'body'  => "Ihr Guide passt das Tempo an die Gruppe an, mit regelmäßigen Pausen für Fotos, Wasser und Geschichten über die Orte unterwegs. Die Route kann am Tag selbst verkürzt oder verlängert werden.\n\nAlle Räder werden nach jeder Tour gewartet und vor dem Start auf Sie eingestellt.",
                'season' => 'September bis Juni. Im Sommer starten wir bei Sonnenaufgang.',
                'included' => ['Abholung und Rücktransfer zu Ihrem Riad oder Hotel in Marrakesch', 'Zertifizierter lokaler Guide', 'Leihrad und Helm', 'Wasser und Obst der Saison', 'Fotos von der Tour'],
                'not_included' => ['Mittagessen, sofern nicht angegeben', 'Persönliche Reiseversicherung', 'Trinkgeld für den Guide'],
                'what_to_bring' => ['Geschlossene Schuhe', 'Sonnenbrille und Sonnencreme', 'Eine leichte Jacke für die Berge', 'Kleiner Rucksack', 'Bargeld für Trinkgeld und Souvenirs'],
            ],
            'nl' => [
                'body'  => "Je gids past het tempo aan de groep aan, met regelmatige stops voor foto’s, water en verhalen over de plekken onderweg. De route kan op de dag zelf worden ingekort of verlengd.\n\nAlle fietsen worden na elke rit onderhouden en voor vertrek op jou afgesteld.",
                'season' => 'September tot juni. In de zomer vertrekken we bij zonsopgang.',
                'included' => ['Ophalen en terugbrengen naar je riad of hotel in Marrakech', 'Gecertificeerde lokale gids', 'Huur van fiets en helm', 'Water en seizoensfruit', 'Foto’s van de rit'],
                'not_included' => ['Lunch tenzij vermeld', 'Persoonlijke reisverzekering', 'Fooi voor je gids'],
                'what_to_bring' => ['Dichte schoenen', 'Zonnebril en zonnebrandcrème', 'Een lichte laag voor de bergen', 'Kleine rugzak', 'Contant geld voor fooien en souvenirs'],
            ],
        ];

        // slug => [lang => [title, excerpt]]
        $tours = [
            'marrakech-medina-palmeraie' => [
                'fr' => ['Médina et Palmeraie de Marrakech', 'Faufilez-vous dans les souks, passez devant la Koutoubia et rejoignez les palmiers dattiers de la Palmeraie en vélo de ville.'],
                'es' => ['Medina y Palmeral de Marrakech', 'Recorre los zocos, pasa junto a la Kutubía y llega a las palmeras datileras del Palmeral en bici urbana.'],
                'it' => ['Medina e Palmeto di Marrakech', 'Tra i souk, davanti alla Koutoubia e fino alle palme da dattero del Palmeto, in bici da città.'],
                'de' => ['Medina & Palmeraie von Marrakesch', 'Durch die Souks, vorbei an der Koutoubia und hinaus zu den Dattelpalmen der Palmeraie auf dem Stadtrad.'],
                'nl' => ['Medina & Palmeraie van Marrakech', 'Slinger door de soeks, langs de Koutoubia en naar de dadelpalmen van de Palmeraie op een stadsfiets.'],
            ],
            'agafay-desert-gravel-loop' => [
                'fr' => ['Boucle gravel dans le désert d’Agafay', 'Pistes ondulantes dans le désert de pierre, l’Atlas enneigé à l’horizon, et déjeuner dans un camp du désert.'],
                'es' => ['Ruta gravel por el desierto de Agafay', 'Pistas onduladas por el desierto de piedra con el Atlas nevado en el horizonte y comida en un campamento.'],
                'it' => ['Anello gravel nel deserto di Agafay', 'Sterrati ondulati nel deserto di pietra con l’Atlante innevato all’orizzonte e pranzo in un campo tendato.'],
                'de' => ['Gravel-Runde in der Agafay-Wüste', 'Wellige Pisten durch die Steinwüste, der verschneite Atlas am Horizont und Mittagessen in einem Wüstencamp.'],
                'nl' => ['Gravelronde door de Agafay-woestijn', 'Glooiende paden door de steenwoestijn, de besneeuwde Atlas aan de horizon en lunch in een woestijnkamp.'],
            ],
            'ourika-valley-e-bike-adventure' => [
                'fr' => ['Aventure à vélo électrique dans la vallée de l’Ourika', 'Remontez l’oued Ourika jusque dans l’Atlas en VTT électrique, avec une maison berbère et une coopérative d’argan.'],
                'es' => ['Aventura en bici eléctrica por el valle del Ourika', 'Sigue el río Ourika hacia el Atlas en e-MTB, con visita a una casa bereber y a una cooperativa de argán.'],
                'it' => ['Avventura in e-bike nella valle dell’Ourika', 'Risali il fiume Ourika fino all’Atlante in e-MTB, visitando una casa berbera e una cooperativa di argan.'],
                'de' => ['E-Bike-Abenteuer im Ourika-Tal', 'Mit dem E-MTB am Ourika-Fluss entlang in den Atlas, mit Besuch eines Berberhauses und einer Argan-Kooperative.'],
                'nl' => ['E-bike-avontuur in de Ourika-vallei', 'Volg de Ourika-rivier de Atlas in op een e-MTB, met een bezoek aan een Berberhuis en een arganocoöperatie.'],
            ],
            'oukaimeden-enduro-descents' => [
                'fr' => ['Descentes enduro à Oukaïmeden', 'Navette jusqu’à 2 650 m puis plus de 1 600 m de descente technique sur les singletracks de l’Atlas.'],
                'es' => ['Descensos enduro en Oukaimeden', 'Remonte hasta 2.650 m y más de 1.600 m de descenso técnico por senderos del Atlas.'],
                'it' => ['Discese enduro a Oukaimeden', 'Navetta fino a 2.650 m e oltre 1.600 m di discesa tecnica sui single track dell’Atlante.'],
                'de' => ['Enduro-Abfahrten in Oukaimeden', 'Shuttle auf 2.650 m und dann über 1.600 Höhenmeter technischer Atlas-Singletrail bergab.'],
                'nl' => ['Enduro-afdalingen in Oukaimeden', 'Shuttle naar 2.650 m en daarna ruim 1.600 m technische afdaling over Atlas-singletracks.'],
            ],
            'tizi-ntest-pass-road-climb' => [
                'fr' => ['Ascension routière du col du Tizi n’Test', 'L’une des grandes montées d’Afrique : lacets, mosquée de Tinmel et sommet à 2 092 m, avec véhicule d’assistance.'],
                'es' => ['Subida en carretera al puerto de Tizi n’Test', 'Uno de los grandes puertos de África: curvas, la mezquita de Tinmel y cima a 2.092 m, con vehículo de apoyo.'],
                'it' => ['Salita su strada al passo Tizi n’Test', 'Una delle grandi salite d’Africa: tornanti, la moschea di Tinmel e vetta a 2.092 m, con mezzo al seguito.'],
                'de' => ['Rennrad-Anstieg zum Tizi-n’Test-Pass', 'Einer der großen Anstiege Afrikas: Serpentinen, die Moschee von Tinmel und Gipfel auf 2.092 m, mit Begleitfahrzeug.'],
                'nl' => ['Klim over de Tizi n’Test-pas', 'Een van de grote klimmen van Afrika: haarspeldbochten, de moskee van Tinmel en de top op 2.092 m, met volgauto.'],
            ],
            'imlil-toubkal-foothills-xc' => [
                'fr' => ['Imlil et contreforts du Toubkal en XC', 'Méritez la vue sous le Toubkal en grimpant les chemins muletiers entre noyers et villages berbères, puis descente rapide.'],
                'es' => ['Imlil y faldas del Toubkal en XC', 'Gánate las vistas bajo el Toubkal subiendo caminos de mulas entre nogales y aldeas bereberes antes de una bajada rápida.'],
                'it' => ['Imlil e pendici del Toubkal in XC', 'Guadagnati il panorama sotto il Toubkal salendo mulattiere tra noci e villaggi berberi, poi una discesa veloce.'],
                'de' => ['Imlil & Toubkal-Ausläufer (XC)', 'Erarbeiten Sie sich die Aussicht unter dem Toubkal auf Maultierpfaden zwischen Walnusshainen und Berberdörfern, dann schnell bergab.'],
                'nl' => ['Imlil & voet van de Toubkal (XC)', 'Verdien het uitzicht onder de Toubkal via muilezelpaden tussen walnootbomen en Berberdorpen, gevolgd door een snelle afdaling.'],
            ],
            'essaouira-coast-argan-gravel' => [
                'fr' => ['Gravel entre côte et arganiers à Essaouira', 'Vent de l’Atlantique, forêt d’arganiers et plages bordées de dunes sur une boucle gravel au sud d’Essaouira.'],
                'es' => ['Gravel por la costa y el argán de Esauira', 'Viento atlántico, bosque de argán y playas con dunas en una ruta gravel al sur de Esauira.'],
                'it' => ['Gravel tra costa e argan a Essaouira', 'Vento atlantico, foresta di argan e spiagge con dune in un anello gravel a sud di Essaouira.'],
                'de' => ['Gravel an der Küste von Essaouira', 'Atlantikwind, Arganwald und dünengesäumte Strände auf einer Gravel-Runde südlich von Essaouira.'],
                'nl' => ['Gravel langs de kust van Essaouira', 'Atlantische wind, arganbos en stranden met duinen op een gravelronde ten zuiden van Essaouira.'],
            ],
            'lalla-takerkoust-lake-e-bike' => [
                'fr' => ['Lac Lalla Takerkoust à vélo électrique', 'Un circuit facile autour du lac turquoise, l’Atlas en toile de fond, avec déjeuner au bord de l’eau.'],
                'es' => ['Lago Lalla Takerkoust en bici eléctrica', 'Un circuito fácil alrededor del embalse turquesa con el Atlas detrás y comida en la orilla.'],
                'it' => ['Lago Lalla Takerkoust in e-bike', 'Un facile giro del lago turchese con l’Atlante sullo sfondo e pranzo in riva.'],
                'de' => ['Lalla-Takerkoust-See mit dem E-Bike', 'Eine leichte Runde um den türkisfarbenen Stausee vor der Kulisse des Atlas, mit Mittagessen am Ufer.'],
                'nl' => ['Lalla Takerkoust-meer per e-bike', 'Een makkelijke ronde om het turquoise stuwmeer met de Atlas op de achtergrond en lunch aan de oever.'],
            ],
            'dades-gorges-road-odyssey' => [
                'fr' => ['Odyssée routière dans les gorges du Dadès', 'Les célèbres lacets de Tissadrine, des gorges de roche rouge et des villages de kasbahs pour une grande journée en selle.'],
                'es' => ['Odisea en carretera por las gargantas del Dadès', 'Las famosas curvas de Tissadrine, gargantas de roca roja y aldeas de kasbahs en una jornada completa sobre la bici.'],
                'it' => ['Odissea su strada nelle gole del Dadès', 'I celebri tornanti di Tissadrine, gole di roccia rossa e villaggi di kasbah in una giornata intera in sella.'],
                'de' => ['Rennrad-Odyssee durch die Dadès-Schlucht', 'Die berühmten Tissadrine-Serpentinen, rote Felsschluchten und Kasbah-Dörfer an einem vollen Tag im Sattel.'],
                'nl' => ['Racefiets-odyssee door de Dadès-kloof', 'De beroemde haarspeldbochten van Tissadrine, kloven van rode rots en kasbahdorpen tijdens een volle dag in het zadel.'],
            ],
            'anti-atlas-tafraoute-enduro' => [
                'fr' => ['Enduro dans l’Anti-Atlas à Tafraoute', 'Blocs de granit rose, amandiers et dalles de roche adhérentes dans la vallée des Ammeln.'],
                'es' => ['Enduro en el Anti-Atlas, Tafraout', 'Bloques de granito rosa, almendros y losas de roca con un agarre increíble en el valle de Ameln.'],
                'it' => ['Enduro nell’Anti-Atlante a Tafraoute', 'Massi di granito rosa, mandorli e placche di roccia aderenti nella valle degli Ameln.'],
                'de' => ['Enduro im Antiatlas bei Tafraoute', 'Rosa Granitblöcke, Mandelhaine und griffige Felsplatten im Ameln-Tal.'],
                'nl' => ['Enduro in de Anti-Atlas bij Tafraoute', 'Roze granietblokken, amandelbomen en grijpende rotsplaten in de Ameln-vallei.'],
            ],
        ];

        foreach (Tour::whereIn('slug', array_keys($tours))->get() as $tour) {
            $rows = [];
            foreach ($common as $code => $c) {
                [$title, $excerpt] = $tours[$tour->slug][$code] ?? [null, null];
                $label = $tour->duration_label === 'Full day'
                    ? __('Full day', [], $code)
                    : __(':count hours', ['count' => (int) $tour->duration_hours], $code);
                $rows[$code] = array_filter([
                    'title'          => $title,
                    'excerpt'        => $excerpt,
                    'description'    => $excerpt ? $excerpt."\n\n".$c['body'] : null,
                    'duration_label' => $label,
                    'season'         => $c['season'],
                    'included'       => $c['included'],
                    'not_included'   => $c['not_included'],
                    'what_to_bring'  => $c['what_to_bring'],
                ]);
            }
            // keep anything already translated by hand in the admin
            $existing = $tour->translations ?? [];
            $tour->update(['translations' => collect($rows)
                ->map(fn ($row, $code) => array_merge($row, $existing[$code] ?? []))
                ->all() + $existing]);
        }
    }
}
