<?php

namespace Database\Seeders;

use App\Models\Activity;
use App\Models\BikeBrand;
use App\Models\Category;
use App\Models\RentalBike;
use App\Models\RentalItem;
use Illuminate\Database\Seeder;

/**
 * Bike brands with a photo, the rental fleet with full specifications, the "Trekking tours" trip type and the
 * equipment guests can rent at checkout.
 *
 * Specifications come from the manufacturers' and retailers' published data for the model year shown. Prices are NOT
 * invented: bikes show "on request" until you enter a price, and equipment items are created switched off with price 0
 * (Admin → Rentals → Equipment to rent: set the price, tick "Available to rent").
 * Safe to run again: existing records are never overwritten.
 *   php artisan db:seed --class=FleetSeeder
 */
class FleetSeeder extends Seeder
{
    public function run(): void
    {
        $d = json_decode(file_get_contents(database_path('seeders/data/fleet7.json')), true, 512, JSON_THROW_ON_ERROR);
        $disk = fn (?string $p) => $p && is_file(storage_path('app/public/'.$p));
        $acts = Activity::pluck('id', 'slug');

        $brandIds = [];
        foreach ($d['brands'] as $b) {
            $brand = BikeBrand::firstOrNew(['name' => $b['name']]);
            if (! $brand->exists) {
                $brand->fill(['url' => $b['url'], 'description' => $b['description'], 'sort_order' => $b['sort_order'], 'is_published' => true]);
            }
            if (! $brand->image && $disk($b['image'])) {
                $brand->image = $b['image'];
            }
            $brand->save();
            $brandIds[$b['name']] = $brand->id;
        }

        foreach ($d['bikes'] as $b) {
            if (RentalBike::where('slug', $b['slug'])->exists()) {
                continue;
            }
            $bike = new RentalBike(collect($b)->only(['slug', 'name', 'model_year', 'sizes', 'rider_height', 'wheel_size', 'travel_front', 'travel_rear', 'frame_material',
                'weight_kg', 'motor', 'battery_wh', 'source_url', 'specs', 'sort_order'])->all());
            $bike->bike_brand_id = $brandIds[$b['brand']] ?? null;
            $bike->activity_id = $acts[$b['activity']] ?? null;
            $bike->description = $b['description']['en'];
            $bike->translations = collect($b['description'])->except('en')->map(fn ($t) => ['description' => $t])->all();
            $bike->image = $disk($b['image']) ? $b['image'] : null;
            $bike->quantity = 1;
            $bike->is_published = true;   // price stays empty: shown as "on request" until you enter one
            $bike->save();
        }

        // new trip type for trekking tours
        $t = $d['trekking'];
        Category::firstOrCreate(['slug' => $t['slug']], [
            'icon' => $t['icon'], 'color' => $t['color'], 'sort_order' => $t['sort_order'], 'name' => $t['name']['en'], 'description' => $t['description']['en'],
            'translations' => collect($t['name'])->except('en')->map(fn ($n, $l) => ['name' => $n, 'description' => $t['description'][$l]])->all(),
        ]);

        foreach ($d['items'] as $i) {
            if (RentalItem::where('slug', $i['slug'])->exists()) {
                continue;
            }
            RentalItem::create([
                'slug' => $i['slug'], 'name' => $i['name']['en'], 'category' => $i['category'], 'unit' => $i['unit'], 'applies_to' => $i['applies_to'], 'sort_order' => $i['sort_order'],
                'price' => 0, 'max_qty' => 10, 'is_published' => false,   // switched off until you set a price
                'translations' => collect($i['name'])->except('en')->map(fn ($n) => ['name' => $n])->all(),
            ]);
        }

        $this->command?->info('Fleet: '.RentalBike::count().' bikes, '.BikeBrand::count().' brands, '.RentalItem::count().' equipment items (switched off until you set prices).');
    }
}
