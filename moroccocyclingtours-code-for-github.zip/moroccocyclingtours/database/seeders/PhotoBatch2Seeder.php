<?php

namespace Database\Seeders;

use App\Models\GalleryImage;
use App\Models\HeroSlide;
use App\Models\Post;
use App\Support\Media;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

/**
 * Second batch of your own photos (e-bike rides, a tagine picnic, a paved mountain road):
 * 2 more slider photos, 17 more gallery photos (new albums "E-bike rides" and "Tour life") and better covers for three articles.
 *
 * The 3 blog covers are only replaced if the post still has the cover from the first batch, so a cover you chose yourself is never
 * touched. Safe to run again. Photos from the first batch (PhotoSeeder) stay in the gallery.
 *   php artisan db:seed --class=PhotoBatch2Seeder
 */
class PhotoBatch2Seeder extends Seeder
{
    private const LANGS = ['fr', 'es', 'it', 'de', 'nl'];

    /** data file of this batch (a later batch overrides these two) */
    protected string $dataFile = 'photos2.json';

    /** earlier batches: a blog cover is only replaced if it still is the one set by one of them */
    protected array $earlier = ['photos.json'];

    public function run(): void
    {
        $d = $this->load($this->dataFile);
        $first = [];   // slug => ['path' => …] from the earlier batches (later batches win)
        foreach ($this->earlier as $file) {
            $first = array_merge($first, $this->load($file)['blog'] ?? []);
        }
        $disk = Storage::disk('public');

        $paths = array_merge(array_column($d['hero'] ?? [], 'path'), array_column($d['gallery'] ?? [], 'path'), array_column($d['blog'] ?? [], 'path'));
        $missing = array_filter($paths, fn ($p) => ! $disk->exists($p));
        if ($missing) {
            $this->command?->error(count($missing).' photo files are missing from storage/app/public (copy the whole "storage" folder from the zip). Nothing was imported.');

            return;
        }

        $next = HeroSlide::exists() ? (int) HeroSlide::max('sort_order') + 1 : 0;
        foreach ($d['hero'] ?? [] as $i => $h) {
            if (! HeroSlide::where('image', $h['path'])->exists()) {
                HeroSlide::create(['image' => $h['path'], 'caption' => $h['caption']['en'], 'sort_order' => $next + $i, 'is_active' => true,
                    'translations' => $this->tr($h['caption'], 'caption')]);
            }
        }

        $next = GalleryImage::exists() ? (int) GalleryImage::max('sort_order') + 1 : 0;
        foreach ($d['gallery'] ?? [] as $i => $g) {
            if (! GalleryImage::where('image', $g['path'])->exists()) {
                GalleryImage::create(['image' => $g['path'], 'caption' => $g['caption']['en'], 'album' => $g['album'], 'sort_order' => $next + $i, 'is_published' => true,
                    'translations' => $this->tr($g['caption'], 'caption')]);
            }
        }

        foreach ($d['blog'] ?? [] as $slug => $b) {
            $post = Post::firstWhere('slug', $slug);
            $previous = $first[$slug]['path'] ?? null;
            // replace only the cover set by the first batch (or an empty one); never a cover you uploaded yourself
            if (! $post || (filled($post->cover) && $post->cover !== $previous)) {
                continue;
            }
            $translations = $post->translations ?? [];
            foreach ($this->tr($b['alt'], 'cover_alt') as $code => $fields) {
                $translations[$code] = array_merge($translations[$code] ?? [], $fields);
            }
            $post->forceFill(['cover' => $b['path'], 'cover_alt' => $b['alt']['en'], 'translations' => $translations])->save();
            if (filled($previous)) {
                Media::delete($previous);   // the old copy belonged to this post only
            }
        }
    }

    private function load(string $file): array
    {
        return json_decode(file_get_contents(database_path('seeders/data/'.$file)), true, 512, JSON_THROW_ON_ERROR);
    }

    private function tr(array $texts, string $field): array
    {
        $out = [];
        foreach (self::LANGS as $code) {
            if (filled($texts[$code] ?? null)) {
                $out[$code] = [$field => $texts[$code]];
            }
        }

        return $out;
    }
}
