<?php

namespace Database\Seeders;

/**
 * Fifth batch: 2 more slider photos, 14 more gallery photos (rocky desert tracks, mesas, yellow wildflowers, a tagine) and a
 * cleaner cover for the food article: the tagine in its clay pot.
 * Photos that show young riders' faces openly, a duplicate and a street scene with a phone number were left out.
 * Safe to run again; a cover you chose yourself is never replaced.
 *   php artisan db:seed --class=PhotoBatch5Seeder
 */
class PhotoBatch5Seeder extends PhotoBatch2Seeder
{
    protected string $dataFile = 'photos5.json';

    protected array $earlier = ['photos.json', 'photos2.json', 'photos3.json', 'photos4.json'];
}
