<?php

namespace Database\Seeders;

use App\Models\Post;
use Illuminate\Database\Seeder;

/**
 * Imports the blog articles from database/seeders/data/blog/*.json.
 *  - New articles are created.
 *  - Existing articles keep your edits; only languages that are still missing are added,
 *    so translation batches can be imported later with: php artisan db:seed --class=BlogSeeder
 */
class BlogSeeder extends Seeder
{
    /** Demo posts from the first version, replaced by the new articles */
    private const OLD_DEMO = ['best-time-to-cycle-in-morocco', 'gravel-mtb-or-e-bike-in-morocco'];

    public function run(): void
    {
        Post::whereIn('slug', self::OLD_DEMO)->whereColumn('updated_at', '<=', 'created_at')->delete();

        foreach (glob(database_path('seeders/data/blog/*.json')) as $file) {
            $d = json_decode(file_get_contents($file), true, 512, JSON_THROW_ON_ERROR);
            $post = Post::firstWhere('slug', $d['slug']);

            if (! $post) {
                Post::create(array_merge($d['base'], [
                    'slug' => $d['slug'], 'topic' => $d['topic'], 'author' => $d['author'], 'author_bio' => $d['author_bio'],
                    'published_at' => $d['published_at'], 'is_published' => true, 'translations' => $d['translations'] ?? [],
                ]));
                continue;
            }

            $translations = $post->translations ?? [];
            $added = false;
            foreach ($d['translations'] ?? [] as $code => $fields) {
                if (empty($translations[$code]['body'])) {
                    $translations[$code] = array_merge($fields, $translations[$code] ?? []);
                    $added = true;
                }
            }
            if ($added) {
                $post->translations = $translations;
                $post->saveQuietly();
            }
        }
    }
}
