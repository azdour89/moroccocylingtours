<?php

namespace Database\Seeders;

/**
 * Third batch: 1 more slider photo, 8 more gallery photos (e-bike rides, a flock of sheep on the track, the support vehicle,
 * a mountain-bike descent) and a better cover for the safety article: the support vehicle carrying a bike.
 * (Two files in this batch were identical to photos already imported, so they are not repeated.)
 *
 * Works like PhotoBatch2Seeder: safe to run again, and a cover you chose yourself is never replaced.
 *   php artisan db:seed --class=PhotoBatch3Seeder
 */
class PhotoBatch3Seeder extends PhotoBatch2Seeder
{
    protected string $dataFile = 'photos3.json';

    protected array $earlier = ['photos.json', 'photos2.json'];
}
