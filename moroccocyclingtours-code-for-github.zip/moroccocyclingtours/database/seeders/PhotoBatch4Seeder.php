<?php

namespace Database\Seeders;

/**
 * Fourth batch: one wide gravel-road photo (two riders on a long road through an acacia plain). It goes into the gallery
 * (album "Sahara & desert") and becomes the cover of the gravel-biking article, unless that article already has a cover you chose.
 *   php artisan db:seed --class=PhotoBatch4Seeder
 */
class PhotoBatch4Seeder extends PhotoBatch2Seeder
{
    protected string $dataFile = 'photos4.json';

    protected array $earlier = ['photos.json', 'photos2.json', 'photos3.json'];
}
