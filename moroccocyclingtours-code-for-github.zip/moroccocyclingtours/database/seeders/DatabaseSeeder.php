<?php

namespace Database\Seeders;

use App\Models\Activity;
use App\Models\Tour;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::updateOrCreate(
            ['email' => env('ADMIN_EMAIL', 'admin@moroccocyclingtours.com')],
            ['name' => 'Admin', 'password' => env('ADMIN_PASSWORD', 'change-me-now'), 'is_admin' => true],
        );

        $types = [
            ['Road bike',     'road-bike',     'road',          '#1B4F8C', 'Smooth tarmac, long climbs and mountain passes on lightweight drop-bar bikes.'],
            ['Gravel bike',   'gravel-bike',   'gravel',        '#A0712B', 'Mixed dirt tracks and quiet back roads through desert, palm groves and argan country.'],
            ['Enduro',        'enduro',        'enduro',        '#9B2C2C', 'Shuttle-assisted descents on rocky Atlas singletrack with full-suspension bikes.'],
            ['Cross-country', 'cross-country', 'cross-country', '#0E7A5F', 'Climb and descend under your own power on mule paths between Berber villages.'],
            ['E-bike',        'e-bike',        'ebike',         '#1F7A8C', 'Electric assistance so everyone in the group reaches the viewpoint with energy to spare.'],
            ['City bike',     'city-bike',     'city',          '#C0841A', 'Relaxed rides through the medina, gardens and the Palmeraie at an easy pace.'],
        ];
        $a = [];
        foreach ($types as $i => [$name, $slug, $icon, $color, $desc]) {
            $a[$slug] = Activity::updateOrCreate(['slug' => $slug], [
                'name' => $name, 'icon' => $icon, 'color' => $color, 'description' => $desc, 'sort_order' => $i,
            ]);
        }

        $commonIncluded = ['Pick-up and drop-off at your riad or hotel in Marrakech', 'Certified local guide', 'Bike and helmet rental', 'Water and seasonal fruit', 'Photos from the ride'];
        $commonBring    = ['Closed shoes', 'Sunglasses and sunscreen', 'Light layer for the mountains', 'Small backpack', 'Cash for tips and souvenirs'];

        $tours = [
            [
                'activity' => 'city-bike', 'title' => 'Marrakech Medina & Palmeraie', 'level' => 'easy',
                'region' => 'Marrakech', 'start_point' => 'Jemaa el-Fna, Marrakech', 'lat' => 31.6258, 'lng' => -7.9891,
                'price' => 45, 'duration_label' => '3 hours', 'hours' => 3, 'km' => 18, 'elev' => 60, 'alt' => 520,
                'terrain' => 'Asphalt, packed earth', 'capacity' => 12, 'age' => 8, 'featured' => true,
                'excerpt' => 'Weave through souks, past the Koutoubia and out to the date palms of the Palmeraie on a relaxed city bike.',
                'route' => [[31.6258, -7.9891], [31.6239, -7.9936], [31.6418, -8.0037], [31.6603, -7.9786], [31.6740, -7.9620], [31.6258, -7.9891]],
                'highlights' => ['Ride past the Koutoubia Mosque at golden hour', 'Hidden alleys of the Mellah and Kasbah', 'Mint tea stop in a Palmeraie garden', 'Majorelle Garden from the outside lanes'],
                'itinerary' => [['09:00', 'Hotel pick-up, bike fitting and safety briefing'], ['09:30', 'Medina ride via Koutoubia and the Kasbah'], ['10:30', 'Out through Bab Doukkala towards the Palmeraie'], ['11:15', 'Mint tea in a family garden'], ['12:00', 'Return to your riad']],
            ],
            [
                'activity' => 'gravel-bike', 'title' => 'Agafay Desert Gravel Loop', 'level' => 'moderate',
                'region' => 'Agafay', 'start_point' => 'Lalla Takerkoust road, Agafay', 'lat' => 31.4520, 'lng' => -8.1640,
                'price' => 89, 'duration_label' => '5 hours', 'hours' => 5, 'km' => 45, 'elev' => 520, 'alt' => 790,
                'terrain' => 'Gravel, hardpack, short sandy sections', 'capacity' => 8, 'age' => 14, 'featured' => true,
                'excerpt' => 'Rolling stone-desert tracks with the snow-capped High Atlas on the horizon, finishing with lunch in a desert camp.',
                'route' => [[31.4520, -8.1640], [31.4380, -8.1900], [31.4210, -8.2150], [31.4050, -8.1800], [31.4300, -8.1450], [31.4520, -8.1640]],
                'highlights' => ['Moon-like stone desert just 40 minutes from Marrakech', 'Flowing gravel descents with Atlas views', 'Lunch in a Berber desert camp', 'Optional sunset finish'],
                'itinerary' => [['08:30', 'Transfer from Marrakech to Agafay'], ['09:15', 'Gravel bike set-up and skills check'], ['09:30', 'Northern loop over the ridgelines'], ['11:30', 'Lunch and rest at a desert camp'], ['12:30', 'Southern loop towards Lalla Takerkoust'], ['14:00', 'Transfer back to Marrakech']],
            ],
            [
                'activity' => 'e-bike', 'title' => 'Ourika Valley E-Bike Adventure', 'level' => 'easy',
                'region' => 'Ourika Valley', 'start_point' => 'Tnine Ourika', 'lat' => 31.3600, 'lng' => -7.7800,
                'price' => 95, 'duration_label' => '6 hours', 'hours' => 6, 'km' => 35, 'elev' => 650, 'alt' => 1500,
                'terrain' => 'Asphalt, gravel, village tracks', 'capacity' => 10, 'age' => 14, 'featured' => true,
                'excerpt' => 'Follow the Ourika river into the Atlas on an e-MTB, visiting a Berber house and an argan cooperative along the way.',
                'route' => [[31.3600, -7.7800], [31.3300, -7.7700], [31.2900, -7.7550], [31.2550, -7.7400], [31.2100, -7.7200]],
                'highlights' => ['Riverside villages of the Ourika valley', 'Tea and bread in a Berber family home', 'Women-run argan oil cooperative', 'Short walk to the Setti Fatma cascades'],
                'itinerary' => [['08:30', 'Pick-up and drive to Tnine Ourika'], ['09:30', 'E-bike set-up and briefing'], ['10:00', 'Ride up the valley along the river'], ['11:30', 'Berber house visit and tea'], ['12:30', 'Lunch by the river in Setti Fatma'], ['14:00', 'Cascade walk, then ride back down'], ['15:30', 'Transfer to Marrakech']],
            ],
            [
                'activity' => 'enduro', 'title' => 'Oukaimeden Enduro Descents', 'level' => 'expert',
                'region' => 'High Atlas', 'start_point' => 'Oukaimeden ski station', 'lat' => 31.2050, 'lng' => -7.8600,
                'price' => 149, 'duration_label' => 'Full day', 'hours' => 8, 'km' => 30, 'elev' => 300, 'alt' => 2650,
                'terrain' => 'Rocky singletrack, scree, mule paths', 'capacity' => 6, 'age' => 16, 'featured' => false,
                'excerpt' => 'Shuttle to 2,650 m and drop over 1,600 m of technical Atlas singletrack to the valley floor.',
                'route' => [[31.2050, -7.8600], [31.2200, -7.8800], [31.2400, -7.8950], [31.2650, -7.9050], [31.2900, -7.9100]],
                'highlights' => ['Over 1,600 m of descending in one day', 'Shuttle-assisted, minimal climbing', 'Full-suspension enduro bikes and body armour', 'Lunch in a mountain village'],
                'itinerary' => [['07:30', 'Pick-up and shuttle to Oukaimeden'], ['09:00', 'Bike check, armour, first warm-up run'], ['10:00', 'Upper alpine descent'], ['12:30', 'Village lunch'], ['13:30', 'Lower forest and mule-path descent'], ['16:00', 'Pack up and transfer to Marrakech']],
            ],
            [
                'activity' => 'road-bike', 'title' => 'Tizi n\'Test Pass Road Climb', 'level' => 'challenging',
                'region' => 'High Atlas', 'start_point' => 'Ouirgane', 'lat' => 31.1720, 'lng' => -8.0790,
                'price' => 129, 'duration_label' => '7 hours', 'hours' => 7, 'km' => 95, 'elev' => 1850, 'alt' => 2092,
                'terrain' => 'Asphalt', 'capacity' => 8, 'age' => 16, 'featured' => true,
                'excerpt' => 'One of Africa\'s great road climbs: hairpins, the Tinmel mosque and a 2,092 m summit, with a support vehicle all day.',
                'route' => [[31.1720, -8.0790], [31.0900, -8.1400], [30.9950, -8.2300], [30.9500, -8.3300], [30.8700, -8.3800]],
                'highlights' => ['Summit of the Tizi n\'Test pass at 2,092 m', '12th-century Tinmel mosque', 'Support van with spares, food and water', 'Carbon road bikes or bring your own pedals'],
                'itinerary' => [['07:00', 'Transfer to Ouirgane, bike fitting'], ['08:00', 'Valley warm-up towards Ijoukak'], ['10:00', 'Tinmel mosque stop'], ['11:00', 'The main climb'], ['13:30', 'Summit lunch with views to the Souss'], ['15:00', 'Van transfer back to Marrakech']],
            ],
            [
                'activity' => 'cross-country', 'title' => 'Imlil & Toubkal Foothills XC', 'level' => 'challenging',
                'region' => 'High Atlas', 'start_point' => 'Imlil', 'lat' => 31.1370, 'lng' => -7.9190,
                'price' => 110, 'duration_label' => '6 hours', 'hours' => 6, 'km' => 32, 'elev' => 1100, 'alt' => 2300,
                'terrain' => 'Mule paths, singletrack, dirt road', 'capacity' => 8, 'age' => 15, 'featured' => false,
                'excerpt' => 'Earn your views below Toubkal, climbing mule paths between walnut groves and Berber villages before a fast descent.',
                'route' => [[31.1370, -7.9190], [31.1500, -7.9000], [31.1700, -7.8850], [31.1850, -7.9100], [31.1600, -7.9300], [31.1370, -7.9190]],
                'highlights' => ['Views to Toubkal, North Africa\'s highest peak', 'Walnut and apple orchards of the Mizane valley', 'Lunch on a village rooftop', 'Hardtail XC bikes with dropper posts'],
                'itinerary' => [['08:00', 'Transfer to Imlil'], ['09:15', 'Climb to the Tizi n\'Tamatert pass'], ['11:30', 'Ridge traverse'], ['12:30', 'Rooftop lunch'], ['13:30', 'Descent through the orchards'], ['15:30', 'Transfer to Marrakech']],
            ],
            [
                'activity' => 'gravel-bike', 'title' => 'Essaouira Coast & Argan Gravel', 'level' => 'moderate',
                'region' => 'Essaouira', 'start_point' => 'Essaouira medina', 'lat' => 31.5085, 'lng' => -9.7595,
                'price' => 85, 'duration_label' => '4 hours', 'hours' => 4, 'km' => 40, 'elev' => 380, 'alt' => 210,
                'terrain' => 'Gravel, coastal tracks, asphalt', 'capacity' => 8, 'age' => 14, 'featured' => false,
                'excerpt' => 'Atlantic wind, argan forest and dune-backed beaches on a coastal gravel loop south of Essaouira.',
                'route' => [[31.5085, -9.7595], [31.4800, -9.7600], [31.4400, -9.7550], [31.4300, -9.7200], [31.4700, -9.7100], [31.5085, -9.7595]],
                'highlights' => ['Argan trees and goats in the branches', 'Empty beaches at Diabat and Sidi Kaouki road', 'Fresh fish lunch option in the port', 'Steady Atlantic breeze, even in summer'],
                'itinerary' => [['09:00', 'Meet at Bab Sbaa, bike fitting'], ['09:30', 'Coastal track to Diabat'], ['10:45', 'Argan forest loop'], ['12:00', 'Return along the beach road'], ['13:00', 'Finish at the port']],
            ],
            [
                'activity' => 'e-bike', 'title' => 'Lalla Takerkoust Lake E-Bike', 'level' => 'easy',
                'region' => 'Agafay', 'start_point' => 'Lalla Takerkoust dam', 'lat' => 31.3630, 'lng' => -8.1350,
                'price' => 69, 'duration_label' => '4 hours', 'hours' => 4, 'km' => 30, 'elev' => 280, 'alt' => 720,
                'terrain' => 'Asphalt, gravel', 'capacity' => 10, 'age' => 12, 'featured' => false,
                'excerpt' => 'An easy e-bike circuit around the turquoise reservoir with the Atlas behind it, ending with lunch on the shore.',
                'route' => [[31.3630, -8.1350], [31.3500, -8.1200], [31.3420, -8.1500], [31.3550, -8.1700], [31.3630, -8.1350]],
                'highlights' => ['Lake views framed by the High Atlas', 'Village of Amizmiz road', 'Lunch on a lakeside terrace', 'Ideal for mixed-ability families'],
                'itinerary' => [['09:00', 'Pick-up in Marrakech'], ['09:45', 'E-bike set-up at the dam'], ['10:00', 'Lake circuit'], ['12:00', 'Lakeside lunch'], ['13:30', 'Return to Marrakech']],
            ],
            [
                'activity' => 'road-bike', 'title' => 'Dades Gorges Road Odyssey', 'level' => 'challenging',
                'region' => 'Dades Valley', 'start_point' => 'Boumalne Dades', 'lat' => 31.3710, 'lng' => -5.9940,
                'price' => 139, 'duration_label' => '8 hours', 'hours' => 8, 'km' => 110, 'elev' => 1600, 'alt' => 1950,
                'terrain' => 'Asphalt', 'capacity' => 8, 'age' => 16, 'featured' => false,
                'excerpt' => 'The famous Tissadrine switchbacks, red-rock gorges and kasbah villages on a full day in the saddle.',
                'route' => [[31.3710, -5.9940], [31.4300, -5.9700], [31.4800, -5.9400], [31.5300, -5.9300], [31.5700, -5.9100]],
                'highlights' => ['Tissadrine hairpins, one of Morocco\'s most photographed roads', 'Monkey Fingers rock formations', 'Kasbahs of the Valley of Roses', 'Support vehicle all day'],
                'itinerary' => [['07:30', 'Start in Boumalne Dades'], ['09:00', 'Into the gorge past the Monkey Fingers'], ['10:30', 'Tissadrine switchbacks'], ['12:30', 'Lunch in Msemrir'], ['14:00', 'Descent back down the gorge']],
            ],
            [
                'activity' => 'enduro', 'title' => 'Anti-Atlas Tafraoute Enduro', 'level' => 'challenging',
                'region' => 'Anti-Atlas', 'start_point' => 'Tafraoute', 'lat' => 29.7230, 'lng' => -8.9750,
                'price' => 135, 'duration_label' => 'Full day', 'hours' => 8, 'km' => 38, 'elev' => 700, 'alt' => 1700,
                'terrain' => 'Granite slabs, rocky singletrack', 'capacity' => 6, 'age' => 16, 'featured' => false,
                'excerpt' => 'Pink granite boulders, almond groves and grippy rock slabs in the Ameln valley.',
                'route' => [[29.7230, -8.9750], [29.7400, -8.9500], [29.7600, -8.9300], [29.7450, -8.9100], [29.7230, -8.9750]],
                'highlights' => ['Granite slab riding with unreal grip', 'Painted rocks of Tafraoute', 'Almond blossom season Feb–Mar', 'Shuttle on the biggest climbs'],
                'itinerary' => [['08:30', 'Meet in Tafraoute, bike check'], ['09:00', 'Ameln valley singletrack'], ['12:30', 'Lunch in an Amazigh village'], ['13:30', 'Painted rocks and slab descents'], ['16:00', 'Finish in Tafraoute']],
            ],
        ];

        foreach ($tours as $i => $t) {
            Tour::updateOrCreate(['slug' => \Illuminate\Support\Str::slug($t['title'])], [
                'activity_id'    => $a[$t['activity']]->id,
                'category'       => 'day',
                'title'          => $t['title'],
                'excerpt'        => $t['excerpt'],
                'description'    => $t['excerpt']."\n\nYour guide adapts the pace to the group, with regular stops for photos, water and stories about the places you ride through. The route can be shortened or extended on the day.\n\nAll bikes are serviced after every ride and fitted to you before the start.",
                'price'          => $t['price'],
                'duration_label' => $t['duration_label'],
                'duration_hours' => $t['hours'],
                'distance_km'    => $t['km'],
                'elevation_m'    => $t['elev'],
                'max_altitude_m' => $t['alt'],
                'level'          => $t['level'],
                'terrain'        => $t['terrain'],
                'region'         => $t['region'],
                'start_point'    => $t['start_point'],
                'latitude'       => $t['lat'],
                'longitude'      => $t['lng'],
                'route'          => $t['route'],
                'capacity'       => $t['capacity'],
                'min_age'        => $t['age'],
                'season'         => 'September to June. Summer rides start at sunrise.',
                'highlights'     => $t['highlights'],
                'itinerary'      => array_map(fn ($r) => ['time' => $r[0], 'text' => $r[1]], $t['itinerary']),
                'included'       => $commonIncluded,
                'not_included'   => ['Lunch unless stated', 'Personal travel insurance', 'Tips for your guide'],
                'what_to_bring'  => $commonBring,
                'is_featured'    => $t['featured'],
                'is_published'   => true,
                'sort_order'     => $i,
            ]);
        }
    
        $this->call(TranslationSeeder::class);
        $this->call(CatalogueSeeder::class);
        $this->call(ContentSeeder::class);
        $this->call(FaqSeeder::class);
        $this->call(BlogSeeder::class);
        $this->call(PhotoSeeder::class);
        $this->call(PhotoBatch2Seeder::class);
        $this->call(PhotoBatch3Seeder::class);
        $this->call(PhotoBatch4Seeder::class);
        $this->call(PhotoBatch5Seeder::class);
        $this->call(FleetSeeder::class);
        $this->call(GalleryEnrichSeeder::class);
        $this->call(HeroQualitySeeder::class);
        $this->call(BlogMediaSeeder::class);
    }
}
