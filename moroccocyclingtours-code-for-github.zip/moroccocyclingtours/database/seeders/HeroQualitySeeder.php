<?php

namespace Database\Seeders;

use App\Models\HeroSlide;
use App\Support\Media;
use Illuminate\Database\Seeder;

/**
 * Replaces the ten home-slider photos by high-quality versions (AVIF quality 68, WebP 90, up to 2560 px wide,
 * made from the original photos). A slide is only changed while it still uses the earlier version, so a photo you
 * uploaded yourself is never touched. The earlier files are removed once nothing uses them.
 *   php artisan db:seed --class=HeroQualitySeeder
 */
class HeroQualitySeeder extends Seeder
{
    public function run(): void
    {
        $map = json_decode(file_get_contents(database_path('seeders/data/hero_hq.json')), true, 512, JSON_THROW_ON_ERROR);
        $n = 0;
        foreach ($map as $old => $new) {
            if (! is_file(storage_path('app/public/'.$new))) {
                continue;
            }
            $slide = HeroSlide::where('image', $old)->first();
            if ($slide) {
                $slide->update(['image' => $new]);
                if (! HeroSlide::where('image', $old)->exists()) {
                    Media::delete($old);
                }
                $n++;
            }
        }
        $this->command?->info("Slider: $n photos upgraded to high quality.");
    }
}
