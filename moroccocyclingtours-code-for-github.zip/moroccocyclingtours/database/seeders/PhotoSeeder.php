<?php

namespace Database\Seeders;

use App\Models\GalleryImage;
use App\Models\HeroSlide;
use App\Models\Post;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

/**
 * Your own photos: 5 on the home page slider, 19 in the gallery (4 albums) and 12 blog covers,
 * each with captions / descriptions in all six languages.
 *
 * The optimised files (AVIF + WebP, 4 sizes each) are in storage/app/public/{slides,gallery,blog}.
 * Safe to run again: photos already imported are skipped, and a blog post that already has a cover keeps it.
 *   php artisan db:seed --class=PhotoSeeder
 */
class PhotoSeeder extends Seeder
{
    private const LANGS = ['fr', 'es', 'it', 'de', 'nl'];

    public function run(): void
    {
        $d = json_decode(file_get_contents(database_path('seeders/data/photos.json')), true, 512, JSON_THROW_ON_ERROR);
        $disk = Storage::disk('public');

        $paths = array_merge(array_column($d['hero'], 'path'), array_column($d['gallery'], 'path'), array_column($d['blog'], 'path'));
        $missing = array_filter($paths, fn ($p) => ! $disk->exists($p));
        if ($missing) {
            $this->command?->error(count($missing).' photo files are missing from storage/app/public (copy the whole "storage" folder from the zip, then run "php artisan storage:link"). Nothing was imported.');

            return;
        }

        // home page slider: added after any slides you already have
        $next = HeroSlide::exists() ? (int) HeroSlide::max('sort_order') + 1 : 0;
        foreach ($d['hero'] as $i => $h) {
            if (HeroSlide::where('image', $h['path'])->exists()) {
                continue;
            }
            HeroSlide::create([
                'image' => $h['path'], 'caption' => $h['caption']['en'], 'sort_order' => $next + $i, 'is_active' => true,
                'translations' => $this->tr($h['caption'], 'caption'),
            ]);
        }

        // gallery
        $next = GalleryImage::exists() ? (int) GalleryImage::max('sort_order') + 1 : 0;
        foreach ($d['gallery'] as $i => $g) {
            if (GalleryImage::where('image', $g['path'])->exists()) {
                continue;
            }
            GalleryImage::create([
                'image' => $g['path'], 'caption' => $g['caption']['en'], 'album' => $g['album'], 'sort_order' => $next + $i, 'is_published' => true,
                'translations' => $this->tr($g['caption'], 'caption'),
            ]);
        }

        // blog covers (only for posts that have no cover yet)
        foreach ($d['blog'] as $slug => $b) {
            $post = Post::firstWhere('slug', $slug);
            if (! $post || filled($post->cover)) {
                continue;
            }
            $translations = $post->translations ?? [];
            foreach ($this->tr($b['alt'], 'cover_alt') as $code => $fields) {
                $translations[$code] = array_merge($translations[$code] ?? [], $fields);
            }
            $post->forceFill(['cover' => $b['path'], 'cover_alt' => $b['alt']['en'], 'translations' => $translations])->save();
        }
    }

    /** {en, fr, …} → ['fr' => ['caption' => …], …] */
    private function tr(array $texts, string $field): array
    {
        $out = [];
        foreach (self::LANGS as $code) {
            if (filled($texts[$code] ?? null)) {
                $out[$code] = [$field => $texts[$code]];
            }
        }

        return $out;
    }
}
