<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Faq;
use App\Models\HistoricSite;
use App\Models\Page;
use App\Models\Post;
use App\Models\RouteStage;
use App\Models\Tour;
use Illuminate\Database\Seeder;

/**
 * Home page texts (from the SEO brief), page headings, FAQs, trip types, historic sites,
 * and Komoot-style route data for the luxury Atlas week.
 * Safe to re-run: existing records are never overwritten.
 */
class ContentSeeder extends Seeder
{
    public function run(): void
    {
        $d = json_decode(file_get_contents(database_path('seeders/data/content.json')), true, 512, JSON_THROW_ON_ERROR);

        foreach ($d['categories'] as $c) {
            Category::firstOrCreate(['slug' => $c['slug']], $c);
        }
        foreach ($d['pages'] as $p) {
            Page::firstOrCreate(['slug' => $p['slug']], $p);
        }
        foreach ($d['sites'] as $s) {
            HistoricSite::firstOrCreate(['slug' => $s['slug']], $s + ['is_published' => true]);
        }

        $tour = Tour::firstWhere('slug', $d['stages']['tour']);
        if ($tour && ! $tour->stages()->exists()) {
            foreach ($d['stages']['items'] as $s) {
                RouteStage::create($s + ['tour_id' => $tour->id]);
            }
        }
    }
}
