<?php

namespace Database\Seeders;

use App\Models\Activity;
use App\Models\Tour;
use Illuminate\Database\Seeder;

/**
 * Imports the Morocco Cycling Tours programmes from database/seeders/data/catalogue/*.json
 * (English base text + fr, es, it, de, nl translations).
 * Re-running is safe: tours that already exist (matched by slug) are left untouched,
 * so edits made in the admin are never overwritten.
 */
class CatalogueSeeder extends Seeder
{
    public function run(): void
    {
        $activities = Activity::pluck('id', 'slug');

        foreach (glob(database_path('seeders/data/catalogue/*.json')) as $file) {
            $d = json_decode(file_get_contents($file), true, 512, JSON_THROW_ON_ERROR);
            $tour = Tour::firstOrNew(['slug' => $d['slug']]);
            if ($tour->exists) {
                continue;
            }

            $tour->fill(array_merge($d['base'], [
                'activity_id'    => $d['activity'] ? ($activities[$d['activity']] ?? null) : null,
                'category'       => $d['category'],
                'level'          => $d['level'],
                'region'         => $d['region'],
                'start_point'    => $d['start_point'],
                'latitude'       => $d['latitude'],
                'longitude'      => $d['longitude'],
                'route'          => $d['route'],
                'price'          => $d['price'],
                'duration_hours' => $d['duration_hours'],
                'distance_km'    => $d['distance_km'],
                'elevation_m'    => $d['elevation_m'],
                'max_altitude_m' => $d['max_altitude_m'],
                'capacity'       => $d['capacity'],
                'min_age'        => $d['min_age'],
                'is_featured'    => $d['is_featured'],
                'is_published'   => true,
                'sort_order'     => $d['sort_order'],
                'translations'   => $d['translations'],
            ]));
            $tour->save();
        }
    }
}
