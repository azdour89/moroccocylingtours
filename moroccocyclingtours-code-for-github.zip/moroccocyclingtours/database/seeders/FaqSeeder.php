<?php

namespace Database\Seeders;

use App\Models\Faq;
use Illuminate\Database\Seeder;

/**
 * FAQs (pre-trip guide + general questions) in six languages, from database/seeders/data/faqs.json.
 * Never creates duplicates: each FAQ has a stable key. Existing FAQs you edited are left alone;
 * the two older FAQs that the guide replaces are updated only if you have not changed them.
 */
class FaqSeeder extends Seeder
{
    public function run(): void
    {
        $data = json_decode(file_get_contents(database_path('seeders/data/faqs.json')), true, 512, JSON_THROW_ON_ERROR);

        foreach ($data['faqs'] as $f) {
            $fields = ['question' => $f['question'], 'answer' => $f['answer'], 'group' => $f['group'],
                'show_on_home' => $f['show_on_home'], 'sort_order' => $f['sort_order'], 'translations' => $f['translations'], 'is_published' => true];

            $faq = Faq::firstWhere('key', $f['key']) ?? Faq::whereNull('key')->where('question', $f['question'])->first();
            if ($faq) {
                $faq->key ??= $f['key'];
                $faq->save();
                continue;
            }

            if (! empty($f['replaces'])) {
                $old = Faq::whereNull('key')->where('question', $f['replaces'])->first();
                if ($old) {
                    // update the older version only if it is still exactly as we seeded it
                    if ($old->answer === $f['replaces_answer']) {
                        $old->fill($fields + ['key' => $f['key']])->save();
                    } else {
                        $old->update(['key' => $f['key']]);
                    }
                    continue;
                }
            }

            Faq::create($fields + ['key' => $f['key']]);
        }

        // the "What is included" question now lives with booking questions
        Faq::where('key', 'included')->where('group', 'travel')->update(['group' => 'booking']);
    }
}
