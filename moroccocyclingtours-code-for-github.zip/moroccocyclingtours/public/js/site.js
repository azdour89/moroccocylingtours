/* Morocco Cycling Tours – hero slider, route stages (elevation profile, weather), small helpers */
window.MCT = window.MCT || {};

/**
 * Hero slider: photos and optional looping videos.
 * - autoplay 6.5 s per photo; a video slide stays for one play-through (6.5–15 s)
 * - videos load only when their slide is first shown and are skipped for reduced motion, data saver and slow connections (the photo stays)
 * - pauses on hover/focus, when the tab is hidden and when the hero is scrolled out of view; swipe and arrow keys work
 */
MCT.slider = function (root) {
    if (!root) return;
    const slides = [...root.querySelectorAll('.slide')];
    if (!slides.length) return;
    const dots = [...root.querySelectorAll('[data-dot]')];
    const cur = root.querySelector('[data-cur]'), cap = root.querySelector('[data-cap]');
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const net = navigator.connection || {};
    const lite = reduce || net.saveData === true || /^(slow-2g|2g|3g)$/.test(net.effectiveType || '');
    const pad = (n) => String(n).padStart(2, '0');
    let i = 0, timer = null, visible = true, hovering = false;

    const vid = (s) => s.querySelector('video');
    const playVideo = (s) => {
        const v = vid(s);
        if (!v || lite) return;
        if (!v.getAttribute('src') && v.dataset.src) v.src = v.dataset.src;   // first time: start loading now
        try { v.currentTime = 0; } catch (e) { /* not ready yet */ }
        v.addEventListener('playing', () => v.classList.add('is-playing'), { once: true });
        const p = v.play();
        if (p && p.catch) p.catch(() => {});
    };
    const pauseVideo = (s) => { const v = vid(s); if (v) v.pause(); };
    const hold = (s) => {
        const v = vid(s);
        if (!v || lite) return 6500;
        return v.duration && isFinite(v.duration) ? Math.min(15000, Math.max(6500, v.duration * 1000 + 250)) : 9000;
    };
    const showCaption = (s) => {
        if (!cap) return;
        const text = s.dataset.caption, link = s.dataset.link;
        cap.hidden = !text;
        cap.textContent = '';
        if (text && link) { const a = document.createElement('a'); a.href = link; a.textContent = text; cap.appendChild(a); }
        else if (text) cap.textContent = text;
    };
    const stop = () => { clearTimeout(timer); timer = null; };
    const schedule = () => {
        stop();
        if (reduce || document.hidden || !visible || hovering || slides.length < 2) return;
        const ms = hold(slides[i]);
        root.style.setProperty('--hold', ms + 'ms');
        timer = setTimeout(() => go(i + 1), ms);
    };
    const restartBar = () => {            // restart the CSS progress animation of the active bar
        const d = dots[i]; if (!d) return;
        d.classList.remove('is-active'); void d.offsetWidth; d.classList.add('is-active');
    };
    function go(n) {
        slides[i].classList.remove('is-active'); slides[i].setAttribute('aria-hidden', 'true'); dots[i]?.classList.remove('is-active');
        pauseVideo(slides[i]);
        i = (n + slides.length) % slides.length;
        slides[i].classList.add('is-active'); slides[i].setAttribute('aria-hidden', 'false');
        if (cur) cur.textContent = pad(i + 1);
        showCaption(slides[i]); playVideo(slides[i]);
        const next = slides[(i + 1) % slides.length].querySelector('img');
        if (next) next.loading = 'eager';   // preload the following photo only
        root.style.setProperty('--hold', hold(slides[i]) + 'ms'); restartBar();
        schedule();
    }

    // when a video's real length is known, use it for the progress bar and the hold time
    slides.forEach((s) => vid(s)?.addEventListener('loadedmetadata', () => { if (slides[i] === s) { root.style.setProperty('--hold', hold(s) + 'ms'); restartBar(); schedule(); } }));

    root.querySelector('[data-prev]')?.addEventListener('click', () => go(i - 1));
    root.querySelector('[data-next]')?.addEventListener('click', () => go(i + 1));
    dots.forEach((d, n) => d.addEventListener('click', () => go(n)));
    root.addEventListener('mouseenter', () => { hovering = true; root.classList.add('is-paused'); stop(); });
    root.addEventListener('mouseleave', () => { hovering = false; root.classList.remove('is-paused'); schedule(); });
    root.addEventListener('keydown', (e) => { if (e.key === 'ArrowRight') go(i + 1); else if (e.key === 'ArrowLeft') go(i - 1); });
    document.addEventListener('visibilitychange', () => { if (document.hidden) { stop(); pauseVideo(slides[i]); } else { playVideo(slides[i]); schedule(); } });
    if ('IntersectionObserver' in window) {
        new IntersectionObserver(([e]) => {
            visible = e.isIntersecting;
            if (visible) { playVideo(slides[i]); schedule(); } else { stop(); pauseVideo(slides[i]); }
        }, { threshold: 0.2 }).observe(root);
    }
    let x0 = null;
    root.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; }, { passive: true });
    root.addEventListener('touchend', (e) => { if (x0 === null) return; const dx = e.changedTouches[0].clientX - x0; if (Math.abs(dx) > 40) go(i + (dx < 0 ? 1 : -1)); x0 = null; });

    showCaption(slides[i]);
    window.addEventListener('load', () => { playVideo(slides[i]); root.style.setProperty('--hold', hold(slides[i]) + 'ms'); schedule(); }, { once: true });
    if (document.readyState === 'complete') { playVideo(slides[i]); schedule(); }
};

/** Elevation profile as SVG, with hover read-out; onHover(km) lets the map follow */
MCT.profile = function (el, pts, t, onHover) {
    if (!el || !pts || pts.length < 2) { if (el) el.hidden = true; return; }
    const W = 800, H = 190, P = { l: 48, r: 12, t: 14, b: 28 };
    const x0 = pts[0][0], x1 = pts[pts.length - 1][0];
    let y0 = Math.min(...pts.map((p) => p[1])), y1 = Math.max(...pts.map((p) => p[1]));
    const pad = Math.max(50, (y1 - y0) * .12);
    y0 = Math.max(0, Math.floor((y0 - pad) / 100) * 100); y1 = Math.ceil((y1 + pad) / 100) * 100;
    const X = (v) => P.l + (v - x0) / ((x1 - x0) || 1) * (W - P.l - P.r);
    const Y = (v) => H - P.b - (v - y0) / ((y1 - y0) || 1) * (H - P.t - P.b);
    const line = pts.map((p, n) => (n ? 'L' : 'M') + X(p[0]).toFixed(1) + ' ' + Y(p[1]).toFixed(1)).join(' ');
    const area = `${line} L${X(x1).toFixed(1)} ${H - P.b} L${X(x0).toFixed(1)} ${H - P.b} Z`;
    const yStep = [100, 200, 250, 500, 1000].find((s) => (y1 - y0) / s <= 5) || 1000;
    const xStep = [1, 2, 5, 10, 20, 25, 50].find((s) => (x1 - x0) / s <= 8) || 50;
    let grid = '';
    for (let v = Math.ceil(y0 / yStep) * yStep; v <= y1; v += yStep) grid += `<line x1="${P.l}" x2="${W - P.r}" y1="${Y(v)}" y2="${Y(v)}" class="pg"/><text x="${P.l - 6}" y="${Y(v) + 4}" text-anchor="end" class="pl">${v} m</text>`;
    for (let v = Math.ceil(x0 / xStep) * xStep; v <= x1; v += xStep) grid += `<text x="${X(v)}" y="${H - 8}" text-anchor="middle" class="pl">${v} km</text>`;
    el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="${t.profile}">
        <defs><linearGradient id="pgrad-${el.id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0E7A5F" stop-opacity=".55"/><stop offset="1" stop-color="#0E7A5F" stop-opacity=".05"/></linearGradient></defs>
        ${grid}<path d="${area}" fill="url(#pgrad-${el.id})"/><path d="${line}" fill="none" stroke="#0E7A5F" stroke-width="2.2" vector-effect="non-scaling-stroke"/>
        <line class="pguide" y1="${P.t}" y2="${H - P.b}" x1="-10" x2="-10"/><circle class="pdot" r="4.5" cx="-10" cy="-10"/>
        <rect x="${P.l}" y="0" width="${W - P.l - P.r}" height="${H}" fill="transparent" class="phit"/></svg><div class="ptip" hidden></div>`;
    const svg = el.querySelector('svg'), guide = el.querySelector('.pguide'), dot = el.querySelector('.pdot'), tip = el.querySelector('.ptip');
    const move = (clientX) => {
        const r = svg.getBoundingClientRect();
        const km = x0 + ((clientX - r.left) / r.width * W - P.l) / (W - P.l - P.r) * (x1 - x0);
        let best = pts[0];
        for (const p of pts) if (Math.abs(p[0] - km) < Math.abs(best[0] - km)) best = p;
        const x = X(best[0]), y = Y(best[1]);
        guide.setAttribute('x1', x); guide.setAttribute('x2', x); dot.setAttribute('cx', x); dot.setAttribute('cy', y);
        tip.hidden = false; tip.textContent = `${best[0].toFixed(1)} km · ${Math.round(best[1])} m`;
        tip.style.left = Math.min(r.width - 120, Math.max(0, (x / W) * r.width - 50)) + 'px';
        if (onHover) onHover(best[0], x1);
    };
    svg.addEventListener('mousemove', (e) => move(e.clientX));
    svg.addEventListener('touchmove', (e) => move(e.touches[0].clientX), { passive: true });
    svg.addEventListener('mouseleave', () => { tip.hidden = true; guide.setAttribute('x1', -10); guide.setAttribute('x2', -10); dot.setAttribute('cx', -10); if (onHover) onHover(null); });
};

/** Five-day forecast from Open-Meteo (free, no key) */
MCT.weather = function (el, lat, lng, t) {
    if (!el || lat == null) return;
    const icon = (c) => c === 0 ? 'sun' : c <= 3 ? 'cloud-sun' : c <= 48 ? 'cloud' : c <= 67 || (c >= 80 && c <= 82) ? 'rain' : c <= 77 || c === 85 || c === 86 ? 'snow' : 'storm';
    const label = (c) => t.codes[icon(c)];
    const svg = {
        'sun': '<circle cx="12" cy="12" r="4.5"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M18.7 5.3l-1.6 1.6M6.9 17.1l-1.6 1.6"/>',
        'cloud-sun': '<circle cx="8" cy="8" r="3.2"/><path d="M8 2v1.5M2 8h1.5M3.8 3.8l1 1M12.2 3.8l-1 1"/><path d="M9 19a4 4 0 0 1-.5-8 5.5 5.5 0 0 1 10.4 1.3A3.4 3.4 0 0 1 18.5 19z"/>',
        'cloud': '<path d="M7 18.5a4.5 4.5 0 0 1-.6-9A6 6 0 0 1 18 10.5a4 4 0 0 1-.5 8z"/>',
        'rain': '<path d="M7 15a4.5 4.5 0 0 1-.6-9A6 6 0 0 1 18 7a4 4 0 0 1-.5 8z"/><path d="M8 18l-1 3M12 18l-1 3M16 18l-1 3"/>',
        'snow': '<path d="M7 14.5a4.5 4.5 0 0 1-.6-9A6 6 0 0 1 18 6.5a4 4 0 0 1-.5 8z"/><path d="M8 18.5h.01M12 20.5h.01M16 18.5h.01" stroke-width="2.6"/>',
        'storm': '<path d="M7 14.5a4.5 4.5 0 0 1-.6-9A6 6 0 0 1 18 6.5a4 4 0 0 1-.5 8z"/><path d="M12.5 13l-2 4h3l-2 4"/>',
    };
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max&timezone=auto&forecast_days=5`;
    fetch(url).then((r) => r.json()).then((d) => {
        const D = d.daily, wd = new Intl.DateTimeFormat(document.documentElement.lang, { weekday: 'short', day: 'numeric' });
        el.innerHTML = D.time.map((day, n) => `<li><span class="wd">${wd.format(new Date(day + 'T12:00'))}</span>
            <svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${svg[icon(D.weather_code[n])]}</svg>
            <span class="wl">${label(D.weather_code[n])}</span>
            <span class="wt"><strong>${Math.round(D.temperature_2m_max[n])}°</strong> ${Math.round(D.temperature_2m_min[n])}°</span>
            <span class="wr">${t.rain} ${D.precipitation_probability_max[n] ?? 0}%</span>
            <span class="wr">${t.wind} ${Math.round(D.wind_speed_10m_max[n])} km/h</span></li>`).join('');
    }).catch(() => { el.innerHTML = `<li class="wfail">${t.unavailable}</li>`; });
};

/** Tour page: route stages with tabs, map, POIs, elevation profile, surfaces and weather */
MCT.stages = function (root, data, t) {
    if (!root || !window.L) return;
    const done = {};
    const init = (n) => {
        if (done[n]) { done[n].invalidateSize(); return; }
        const s = data[n], panel = root.querySelector(`[data-stage-panel="${n}"]`);
        const map = MCT.base(panel.querySelector('.stage-map'), { zoom: 11 });
        if (!map) return;
        done[n] = map;
        const layers = [];
        if (s.route && s.route.length > 1) {
            layers.push(L.polyline(s.route, { color: '#fff', weight: 8, opacity: .9 }).addTo(map));
            layers.push(L.polyline(s.route, { color: s.color, weight: 4.5 }).addTo(map));
            layers.push(L.marker(s.route[0], { icon: MCT.pin('#0E7A5F'), title: t.start }).addTo(map));
            const end = s.route[s.route.length - 1];
            layers.push(L.circleMarker(end, { radius: 7, color: '#fff', weight: 2, fillColor: '#9B2C2C', fillOpacity: 1 }).bindTooltip(t.finish).addTo(map));
        }
        (s.pois || []).forEach((p) => layers.push(L.circleMarker([p.lat, p.lng], { radius: 7, color: '#fff', weight: 2, fillColor: p.color, fillOpacity: 1 }).bindPopup(`<strong>${p.name}</strong><br>${p.label}`).addTo(map)));
        if (layers.length) map.fitBounds(L.featureGroup(layers).getBounds(), { padding: [30, 30], maxZoom: 13 });
        // map follows the elevation profile
        const cum = [0];
        for (let i = 1; i < (s.route || []).length; i++) cum[i] = cum[i - 1] + MCT.dist(s.route[i - 1][0], s.route[i - 1][1], s.route[i][0], s.route[i][1]);
        const follower = L.circleMarker([0, 0], { radius: 7, color: '#fff', weight: 3, fillColor: '#E0A526', fillOpacity: 1 });
        MCT.profile(panel.querySelector('.stage-profile'), s.profile, t, (km, total) => {
            if (km === null || !cum.length || cum.length < 2) { follower.remove(); return; }
            const target = km / total * cum[cum.length - 1];
            let i = cum.findIndex((c) => c >= target); if (i < 0) i = cum.length - 1;
            follower.setLatLng(s.route[i]).addTo(map);
        });
        const start = s.route && s.route[0] ? s.route[0] : s.start;
        if (start) MCT.weather(panel.querySelector('.stage-weather'), start[0], start[1], t);
    };
    const tabs = [...root.querySelectorAll('[data-stage-tab]')];
    const show = (n) => {
        tabs.forEach((b) => b.setAttribute('aria-selected', String(+b.dataset.stageTab === n)));
        root.querySelectorAll('[data-stage-panel]').forEach((p) => { p.hidden = +p.dataset.stagePanel !== n; });
        init(n);
    };
    tabs.forEach((b) => b.addEventListener('click', () => show(+b.dataset.stageTab)));
    tabs.forEach((b, i) => b.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { const n = (i + (e.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length; tabs[n].focus(); show(n); }
    }));
    // start once the section is near the viewport
    const io = new IntersectionObserver((e) => { if (e[0].isIntersecting) { io.disconnect(); show(0); } }, { rootMargin: '300px' });
    io.observe(root);
};
