/* Morocco Cycling Tours – map helpers (Leaflet 1.9) */
window.MCT = Object.assign(window.MCT || {}, (function () {
    const MOROCCO = [31.4, -7.6];
    const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

    function base(id, opts = {}) {
        const el = typeof id === 'string' ? document.getElementById(id) : id;
        if (!el || !window.L) return null;
        const map = L.map(el, { scrollWheelZoom: !!opts.scroll, zoomControl: true }).setView(opts.center || MOROCCO, opts.zoom || 6);
        L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/">CARTO</a>',
            subdomains: 'abcd', maxZoom: 19,
        }).addTo(map);
        return map;
    }

    /** 8-point zellige star pin in the bike-type colour */
    function pin(color) {
        return L.divIcon({
            className: 'mct-pin',
            html: '<svg viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">'
                + '<path d="M5.5 5.5h13v13h-13z" fill="' + color + '" stroke="#fff" stroke-width="1.4"/>'
                + '<path d="M12 2.8 21.2 12 12 21.2 2.8 12z" fill="' + color + '" stroke="#fff" stroke-width="1.4"/>'
                + '<path d="M5.5 5.5h13v13h-13z" fill="' + color + '"/>'
                + '<circle cx="12" cy="12" r="3.2" fill="#fff"/></svg>',
            iconSize: [32, 32], iconAnchor: [16, 16], popupAnchor: [0, -14],
        });
    }

    function popup(t) {
        return '<a class="mct-pop" href="' + esc(t.url) + '">'
            + (t.image ? '<img src="' + esc(t.image) + '" alt="">' : '')
            + '<span class="mct-pop-type" style="color:' + esc(t.color) + '">' + esc(t.activity) + ' · ' + esc(t.level) + '</span>'
            + '<strong>' + esc(t.title) + '</strong>'
            + (t.subtitle ? '<em class="mct-pop-sub">' + esc(t.subtitle) + '</em>' : '')
            + '<span>' + (t.km ? esc(t.km) + ' km · ' : '') + esc(t.duration) + ' · ' + esc(t.price) + '</span></a>';
    }

    /** Map with one star per tour start point. */
    function pointsMap(id, tours, opts = {}) {
        const map = base(id, opts);
        if (!map) return null;
        const markers = {}, pts = [];
        tours.forEach((t) => {
            if (t.lat == null || t.lng == null) return;
            const m = L.marker([t.lat, t.lng], { icon: pin(t.color), title: t.title, riseOnHover: true }).addTo(map);
            m.bindPopup(popup(t), { maxWidth: 240, minWidth: 220 });
            markers[t.id] = m; pts.push([t.lat, t.lng]);
        });
        if (pts.length) map.fitBounds(pts, { padding: [40, 40], maxZoom: 10 });

        if (opts.linkCards) {
            document.querySelectorAll('[data-tour-id]').forEach((card) => {
                const m = markers[card.dataset.tourId];
                if (!m) return;
                const on = (v) => { const e = m.getElement(); if (e) e.classList.toggle('is-active', v); m.setZIndexOffset(v ? 1000 : 0); };
                card.addEventListener('mouseenter', () => on(true));
                card.addEventListener('mouseleave', () => on(false));
                card.addEventListener('focusin', () => on(true));
                card.addEventListener('focusout', () => on(false));
            });
        }
        return map;
    }

    /** Finder: show/hide map, auto-submit filters. */
    function finderControls(map) {
        const btn = document.querySelector('[data-map-toggle]');
        if (btn) {
            const label = btn.querySelector('span');
            const sync = () => {
                const hidden = document.body.classList.contains('map-hidden');
                label.textContent = hidden ? (btn.dataset.showLabel || 'Show map') : (btn.dataset.hideLabel || 'Hide map');
                btn.setAttribute('aria-pressed', String(!hidden));
            };
            if (window.matchMedia('(max-width: 900px)').matches) document.body.classList.add('map-hidden');
            sync();
            btn.addEventListener('click', () => {
                document.body.classList.toggle('map-hidden'); sync();
                if (map) setTimeout(() => map.invalidateSize(), 60);
            });
        }
        document.querySelectorAll('[data-autosubmit]').forEach((el) => {
            el.addEventListener('change', () => (el.form || document.getElementById(el.getAttribute('form'))).submit());
        });
    }

    /** Tour page: start pin + route line. */
    function routeMap(id, t) {
        const map = base(id, { zoom: 11 });
        if (!map) return null;
        const layers = [];
        if (t.route && t.route.length > 1) {
            layers.push(L.polyline(t.route, { color: '#fff', weight: 8, opacity: .9 }).addTo(map));
            layers.push(L.polyline(t.route, { color: t.color, weight: 4.5 }).addTo(map));
        }
        if (t.lat != null) layers.push(L.marker([t.lat, t.lng], { icon: pin(t.color), title: t.title }).addTo(map));
        if (layers.length) map.fitBounds(L.featureGroup(layers).getBounds(), { padding: [30, 30], maxZoom: 13 });
        return map;
    }

    /** Admin: click to set the start, draw the route point by point. */
    function pickerMap(id, f) {
        const map = base(id, { scroll: true });
        if (!map) return null;
        const color = () => f.activity.selectedOptions[0]?.dataset.color || '#1B4F8C';
        let route = []; try { route = JSON.parse(f.route.value || '[]') || []; } catch (e) { route = []; }
        const line = L.polyline(route, { color: color(), weight: 4 }).addTo(map);
        let marker = null;
        const syncRoute = () => { f.route.value = JSON.stringify(route); line.setLatLngs(route); f.count.textContent = route.length ? route.length + ' route points' : 'No route yet'; };
        const setStart = (lat, lng, pan) => {
            lat = +(+lat).toFixed(6); lng = +(+lng).toFixed(6);
            f.lat.value = lat; f.lng.value = lng;
            if (!marker) {
                marker = L.marker([lat, lng], { draggable: true, icon: pin(color()) }).addTo(map);
                marker.on('dragend', (e) => { const p = e.target.getLatLng(); setStart(p.lat, p.lng); });
            } else marker.setLatLng([lat, lng]);
            if (pan) map.setView([lat, lng], Math.max(map.getZoom(), 10));
        };
        if (f.lat.value && f.lng.value) setStart(f.lat.value, f.lng.value, true);
        if (route.length > 1) map.fitBounds(line.getBounds(), { padding: [30, 30] });
        syncRoute();

        map.on('click', (e) => {
            const mode = document.querySelector('input[name="_mode"]:checked')?.value;
            if (mode === 'route') { route.push([+e.latlng.lat.toFixed(5), +e.latlng.lng.toFixed(5)]); syncRoute(); }
            else setStart(e.latlng.lat, e.latlng.lng);
        });
        f.undo.addEventListener('click', () => { route.pop(); syncRoute(); });
        f.clear.addEventListener('click', () => { if (!route.length || confirm('Clear the whole route?')) { route = []; syncRoute(); } });
        [f.lat, f.lng].forEach((i) => i.addEventListener('change', () => { if (f.lat.value && f.lng.value) setStart(f.lat.value, f.lng.value, true); }));
        f.activity.addEventListener('change', () => { line.setStyle({ color: color() }); if (marker) marker.setIcon(pin(color())); });
        return map;
    }

    const dist = (a, b, c, d) => {
        const R = 6371, r = Math.PI / 180, x = Math.sin((c - a) * r / 2) ** 2 + Math.cos(a * r) * Math.cos(c * r) * Math.sin((d - b) * r / 2) ** 2;
        return 2 * R * Math.asin(Math.min(1, Math.sqrt(x)));
    };

    /** Click on the map → circle of N km → only tours that start or pass inside it stay visible */
    function areaSearch(map, tours, o) {
        if (!map) return;
        let circle = null, dot = null, last = null;
        const items = () => document.querySelectorAll(o.items);
        const fmt = (str, v) => str.replace(':count', v.count).replace(':km', v.km);
        function run(ll) {
            const km = +(o.radius ? o.radius.value : 50);
            if (circle) circle.remove();
            if (dot) dot.remove();
            circle = L.circle(ll, { radius: km * 1000, color: '#E0A526', weight: 2, fillColor: '#E0A526', fillOpacity: .08 }).addTo(map);
            dot = L.circleMarker(ll, { radius: 7, color: '#fff', weight: 2, fillColor: '#E0A526', fillOpacity: 1 }).addTo(map);
            const ids = new Set();
            tours.forEach((t) => {
                const pts = [[t.lat, t.lng]].concat(t.route || []).filter((p) => p && p[0] != null);
                if (pts.length && Math.min(...pts.map((p) => dist(ll.lat, ll.lng, p[0], p[1]))) <= km) ids.add(String(t.id));
            });
            items().forEach((el) => el.classList.toggle('is-out', !ids.has(el.dataset.tourId)));
            if (o.status) o.status.textContent = fmt(ids.size ? o.text.found : o.text.none, { count: ids.size, km });
            if (o.clear) o.clear.hidden = false;
            map.fitBounds(circle.getBounds(), { padding: [20, 20] });
            last = ll;
            if (o.onChange) o.onChange(ids);
        }
        map.on('click', (e) => run(e.latlng));
        if (o.radius) o.radius.addEventListener('change', () => last && run(last));
        if (o.clear) o.clear.addEventListener('click', () => {
            if (circle) circle.remove();
            if (dot) dot.remove();
            circle = dot = last = null;
            items().forEach((el) => el.classList.remove('is-out'));
            if (o.status) o.status.textContent = o.text.all;
            o.clear.hidden = true;
            if (o.onChange) o.onChange(null);
        });
    }

    /** Admin: draw a stage route and add points of interest by clicking */
    function stageEditor(id, f) {
        const map = base(id, { scroll: true });
        if (!map) return null;
        let route = []; try { route = JSON.parse(f.route.value || '[]') || []; } catch (e) { route = []; }
        const line = L.polyline(route, { color: '#1B4F8C', weight: 4 }).addTo(map);
        const poiLayer = L.layerGroup().addTo(map);
        const drawPois = () => {
            poiLayer.clearLayers();
            f.pois.value.split(/\n/).forEach((l) => {
                const p = l.split('|').map((x) => x.trim()), m = (p[2] || '').match(/(-?\d+(?:\.\d+)?)\s*[,; ]\s*(-?\d+(?:\.\d+)?)/);
                if (m) L.circleMarker([+m[1], +m[2]], { radius: 6, color: '#fff', weight: 2, fillColor: '#E0A526', fillOpacity: 1 }).bindTooltip(p[0]).addTo(poiLayer);
            });
        };
        const sync = () => { f.route.value = JSON.stringify(route); line.setLatLngs(route); f.count.textContent = route.length ? route.length + ' points' : 'No route yet'; };
        if (route.length > 1) map.fitBounds(line.getBounds(), { padding: [30, 30] });
        sync(); drawPois();
        map.on('click', (e) => {
            const mode = document.querySelector('input[name="_mode"]:checked')?.value;
            const ll = [+e.latlng.lat.toFixed(5), +e.latlng.lng.toFixed(5)];
            if (mode === 'poi') {
                const name = prompt('Name of this point (e.g. Tizi n’Tamatert pass)');
                if (!name) return;
                const type = prompt('Type: viewpoint, pass, village, water, food, sleep, historic or info', 'viewpoint') || 'info';
                f.pois.value = (f.pois.value.trim() ? f.pois.value.trim() + '\n' : '') + `${name} | ${type} | ${ll[0]}, ${ll[1]}`;
                drawPois();
            } else { route.push(ll); sync(); }
        });
        f.pois.addEventListener('change', drawPois);
        f.undo.addEventListener('click', () => { route.pop(); sync(); });
        f.clear.addEventListener('click', () => { if (!route.length || confirm('Clear the whole route?')) { route = []; sync(); } });
        return map;
    }

    return { base, pin, pointsMap, finderControls, routeMap, pickerMap, areaSearch, stageEditor, dist };
})());
