# Morocco Cycling Tours – Laravel site

Public website + admin panel for **moroccocyclingtours.com**.

* **Zellige design**: cedar-green and cobalt palette, saffron accents, 8-point star tile pattern, arch-shaped photos, zellige frieze above the footer.
* **Bike types (activities)**: Road bike, Gravel bike, Enduro, Cross-country, E-bike, City bike – each with its own icon and colour.
* **Bike-tool labels**: difficulty = tyre-pressure gauge, distance = spoked wheel, duration = cycle computer, group size = helmet, included = wrench, bookings = pump, season = chainring.
* **Tour finder on a map** (like valais.ch): bike-type tabs, region / duration / price / level filters, card list linked to a Leaflet map with star-shaped pins, “Hide map” toggle.
* **Tour page** (like seekadventure.ch): hero with price and level, key-facts bar, highlights, description, timed itinerary, route map, included / not included, what to bring, sticky booking form with live total, related tours.
* **Tour card**: image, title, short description, price, bike type, level (+ distance, duration, elevation).
* **Admin** (`/admin`): dashboard (requests to confirm, upcoming rides, riders and revenue this month), tours CRUD with image + gallery upload and a **click-to-draw route map**, bike types CRUD with icon picker and colour, bookings with status tabs, search, notes, e-mail/WhatsApp shortcuts.

## Languages

The site runs in **English, French, Spanish, Italian, German and Dutch**:

* URLs carry the language: `/en`, `/fr/tours`, `/de/tours/agafay-desert-gravel-loop` … `/` sends visitors to their saved or browser language.
* Language menu in the header and footer, plus `hreflang` tags for Google.
* Interface text lives in `lang/fr.json`, `lang/es.json`, `lang/it.json`, `lang/de.json`, `lang/nl.json` (`lang/en.json` lists every key).
* Tour and bike-type content is translated per language in the admin (**Tours → edit → Translations**, **Bike types → edit**). Empty fields fall back to English. The tour list shows which languages are done.
* The seeder fills in names, titles, short descriptions, descriptions, durations, season and the included / not included / what to bring lists for all demo content. **Highlights and itineraries are still English** until you add them in the admin.
* Each booking stores the guest’s language so you can reply in it.
* To add a language, add it to `locales` in `config/site.php` and create `lang/xx.json`.
* Form-error messages (e.g. “The e-mail field is required”) come from Laravel’s own files. For translated versions: `composer require laravel-lang/common --dev && php artisan lang:add fr es it de nl` (commit `lang/` first and check the JSON files keep their keys).

## Website sections (v3)

**Home page** (in the order of the SEO brief): hero slider with H1, sub-heading, two buttons and trust badges → quick search
(riding style, duration, difficulty) → three featured bike types → most popular itineraries → all tours on an interactive map
where a click shows the adventures in that area → SEO text with internal links → “The Morocco Cycling Tours difference” →
trip types → testimonials → FAQ (with FAQPage schema) → bike brands → latest blog posts → route-guide download form.
Title, meta description, H1, sub-heading, trust badges and SEO text are edited in **Admin → Page content → Home page**.

**New pages:** /bikes (all bike types in one place) and /bikes/{type}, /trips/{category}, /about, /faq, /events,
/testimonials, /blog, /gallery, /historic-sites, /contact (private trip requests), plus /sitemap.xml.

**Map area search:** on the home page and the tour finder, click anywhere on the map, pick a radius (25–200 km) and only the
tours that start or pass inside it stay visible.

**Route details (Komoot ideas):** each tour can have riding days with route overview map, points of interest, types of paths
and surfaces, route details, ascents and descents (interactive elevation profile linked to the map) and a 5-day weather report
(Open-Meteo, free). In the admin you paste the Komoot link (shown as a preview iframe) and upload the GPX export; the numbers,
map line and profile are filled in automatically. The website shows everything in its own Zellige design. The luxury Atlas week
comes with six riding days built from your PDF (surfaces, highest/lowest points, approximate profiles).

**Admin sections:** Page content, Hero slider, Tours (+ route stages), Tour calendar (month view + fixed departures),
Historic sites (map picker; sites within 25 km show on tour pages), Activities (bike types, now with photos), Categories,
Gallery, Team, Bike brands, Reviews, Blog posts, FAQs, Events, Enquiries & leads. All content sections have translation tabs.

**Images:** every upload is resized and converted to WebP in 4 widths (1920/1280/800/480) and served with srcset and lazy
loading; the first hero image is preloaded. PHP needs the GD extension with WebP (standard in Herd).

**SEO:** per-page titles and descriptions, canonical and hreflang tags, Open Graph, JSON-LD for TravelAgency/LocalBusiness
(home), TouristTrip with offers and ratings (tours), FAQPage, Event, BlogPosting; sitemap.xml with all languages; robots.txt.
Set `SITE_OPENING_HOURS` in `.env` (default “Mo-Sa 09:00-19:00”) and replace the domain in `public/robots.txt` if needed.

**Not seeded on purpose:** reviews, team members, bike brands and events. Please add real ones, as invented testimonials
would mislead your guests and break review-platform rules.

## Group pricing (Admin → Group pricing)

Every tour has a **base price per person** (set on the tour). The site adjusts it by group size and shows the result
automatically. The default rules are:

| Group | Price per person |
|---|---|
| 1–2 people | on request (the booking arrives with a total of 0 so you can send a personal quote) |
| 3–5 people | base price **+10%** |
| 6–10 people | base price **−5%** |
| 11–20 people | base price **−15%** |
| more than 20 | please ask for a quote |

* **Tour page:** a price table by group size, a people field that shows the price per person and the total as the guest types,
  and the "from" price (the lowest price the tour can reach) on cards, maps and in Google data.
* **Capacity:** a tour only shows the group sizes it can take. A tour for 8 riders shows 1–2, 3–5 and 6–8; a private tour for 2
  is "price on request".
* **Admin → Group pricing** (also summarised on the Dashboard): edit the rows (from, to, adjustment in %, or "On request"),
  add or remove rows, choose rounding (€1, €5 or €10), switch the whole system off, and preview the result on any of your tours.
  The screen warns you when a group size is not covered by any row or when rows overlap.
* The server always recalculates the total when a booking is sent, so nobody can change the price in their browser.
* Tours with a base price of 0 stay "price on request". The tour finder's price filter and price sorting use the "from" price.

## FAQs

24 questions in six languages (database/seeders/data/faqs.json), merged from your pre-trip guide and the questions that were
already on the site: entry & visas, safety & insurance, culture & dress, customs & prohibited items, food & water, bikes,
e-bikes and the support van, booking and group prices. Questions that appeared twice were merged into one answer.
Each FAQ has a stable key, so importing never creates duplicates and never overwrites your own edits:
`php artisan migrate && php artisan db:seed --class=FaqSeeder` (safe to repeat). Links inside answers use
`/{lang}/...`, which becomes the visitor's language. Please check the visa, customs and drone answers against official sources
once a year: those rules change.

## Blog articles

12 articles are included (database/seeders/data/blog), rewritten for readers and search engines: quick answer at the top,
H1–H4 headings, tables, FAQ (sent to Google as FAQ data), author box, booking invitation, related articles and share buttons.
Internal links use `{lang}` and automatically point to the visitor’s language; links to atlasmountainbike.com,
marrakechbybike.com and outside sources open in a new tab.

* Import or update: `php artisan migrate` then `php artisan db:seed --class=BlogSeeder` (existing posts keep your edits;
  only missing languages are added, so translation batches can be imported the same way).
* **Guide notes:** write `[[note: …]]` anywhere in a post for reminders (a personal story, a price to check). Notes are never
  shown on the website. The **Publishing checklist** next to each post (Admin → Blog posts) checks the content guide
  automatically for every language: keyword in title, first paragraph and a heading, short URL, meta title/description
  length, keyword density, notes left, author and bio, cover photo with alt text, paragraph length, links to related posts,
  outside links, booking link and FAQ. The Dashboard lists posts with open notes and posts not updated for 12 months.
* Before publishing each post: replace the guide notes with your own stories, add your photos (cover + a few in the text),
  and set a real author name and bio (e.g. “Written by Rachid, guide since 2005”).

## Logo

The logo in `public/img/logo/` has the banner corrected to **CYCLING TOURS** (one bold style, evenly spaced, following the
curve) and is shown as a **round white badge**: the whole logo, handlebars included, fits inside the circle.
`morocco-cycling-tours-logo-round.png` is the round full-size master and `morocco-cycling-tours-logo.png` the flat one
(both transparent). The site uses AVIF, WebP and PNG versions at 160, 320, 640 and 1280 px through
`<x-logo :height="64" />` (round) or `<x-logo :height="64" :round="false" />` (flat), so phones load only a few KB.
The badge is used in the header, footer, admin sidebar and login, in Google's structured data (`logo`), in the default
share image (`public/img/og-default.png`, used when a page has no photo of its own) and in `apple-touch-icon.png`.
To replace the logo later, overwrite the `logo-round-*` / `logo-*` files keeping the names and proportions.

## For developers: Blade `@json`

Blade splits `@json(...)` at every comma, so an expression with four or more commas inside (for example a `map` that builds an
array with several keys) fails with *“Unclosed '[' does not match ')'”*. In views use `{{ \Illuminate\Support\Js::from($data) }}`
for anything more than a simple variable. `php artisan view:cache` compiles every view at once and shows any such error.

## Your photos (slider, gallery, blog covers)

`php artisan db:seed --class=PhotoSeeder` imports 19 of your own photos from `storage/app/public` (already converted to AVIF + WebP
in four sizes, black/green video-frame strips cropped off):

* **Home page slider:** 5 photos, added after any slides you already have (reorder or delete in Admin → Hero slider).
* **Gallery:** all 19, in four albums (Atlas gravel · Sahara & desert · Oases, gorges & kasbahs · Mountain biking), captions in six languages.
* **Blog covers:** one photo for each of the 12 articles, with a description (alt text) in six languages. A post that already has a
  cover keeps it. Swap any photo in Admin → Blog posts / Gallery / Hero slider. Each slot has its own file, so deleting one photo never
  affects another.

Safe to run again (nothing is duplicated). Needs `php artisan storage:link` once.

### Second batch (e-bike rides, picnic lunch, paved road)

`php artisan db:seed --class=PhotoBatch2Seeder` adds 2 more slider photos, 17 gallery photos (new albums **E-bike rides** and
**Tour life**) and swaps three article covers for better matches: a real e-bike photo for the e-bike article, the tagine and mint
tea picnic for the food article and a paved mountain road for the Tizi n'Tichka article. A cover you changed yourself is never
replaced, and the photos from the first batch stay in the gallery.

Three photos were deliberately left off the site: two show local children (one right beside the rider), and one has a phone
number painted on a wall. Before using photos of local people, ask them first, or crop them out. The same goes for guests:
make sure the riders shown are happy to appear on your website.

### Third batch (support vehicle, sheep on the track, canyon rides)

`php artisan db:seed --class=PhotoBatch3Seeder` adds 1 slider photo, 8 gallery photos (more **E-bike rides**, plus **Tour life**
and **Mountain biking**) and a better cover for the safety article: the support vehicle carrying a bike. Two files in this batch
were identical to photos already imported, so they were skipped. The licence plate of the support vehicle is blurred. A shepherd is
visible far away in the sheep photo: crop him out if you prefer.

### Fourth batch (one gravel-road photo)

`php artisan db:seed --class=PhotoBatch4Seeder` adds one gallery photo (album **Sahara & desert**) and makes it the cover of the
gravel-biking article, unless you already chose a cover there. The two video clips sent with this batch were not used (the site
shows photos only).

### Fifth batch (rocky desert tracks, mesas, wildflowers, a tagine)

`php artisan db:seed --class=PhotoBatch5Seeder` adds 2 slider photos, 14 gallery photos (mostly **Sahara & desert**, plus
**Tour life**) and a cleaner cover for the food article: the tagine in its clay pot, cropped to landscape. Left out on purpose:
a file identical to a photo already on the site, a village street with a phone number on a sign, and the photos in which young
riders' faces are fully visible (the lunch tables and the group photo). If those riders (or their parents) agree, they can be
added later.

## Photo uploads and PHP limits

The admin accepts photos up to 15 MB, but PHP decides what the server really allows: XAMPP's default is **2 MB**, which blocks most
camera photos. The upload forms show the real limit, and a bigger file gets a clear message. To raise it, run `php --ini` to see
which `php.ini` is used, set `upload_max_filesize = 20M` and `post_max_size = 25M`, then restart Apache (or stop and start
`php artisan serve`). A required photo (hero slider, gallery) can be replaced but not removed.

## Image optimisation (AVIF + WebP)

Every image uploaded in the admin (tours, gallery, slider, bike types, categories, pages, historic sites, team, brands,
blog, events) is converted automatically to **AVIF and WebP in four widths** (1920, 1280, 800, 480 px). Pages use a
`<picture>` element: browsers that support AVIF get it (usually 30–50 % smaller than WebP), the others get WebP. Images
also carry width/height (no layout shift), load lazily, and the first slider photo is preloaded.

The **Dashboard → Image optimisation** panel shows what your server can write. AVIF is created with the first encoder that
really works: PHP GD (`imageavif`), Imagick, or the `avifenc` command-line tool. Each one is tested with a real encode,
because many ImageMagick builds list AVIF but can only read it.

* **No AVIF on your computer or server?** Install libavif: `brew install libavif` (Mac), `sudo apt install libavif-bin`
  (Ubuntu/Debian), or download avifenc for Windows from github.com/AOMediaCodec/libavif/releases and set
  `SITE_AVIFENC=C:\path\to\avifenc.exe` in `.env`. WebP keeps working without it.
* **Convert images uploaded before this update:** `php artisan images:optimize` (add `--dry-run` to preview,
  `--keep-originals` to keep the JPG/PNG files). Run it again after installing AVIF support to add the AVIF versions.
* **Settings in `.env`:** `SITE_IMAGE_FORMATS=avif,webp`, `SITE_IMAGE_MAX_WIDTH=1920`, `SITE_AVIF_QUALITY=52`,
  `SITE_WEBP_QUALITY=80`, `SITE_AVIF_SPEED=6`.

## Speed checklist for the live server

* `public/.htaccess` (Apache/LiteSpeed) now adds AVIF/WebP types, gzip/brotli compression, one-year caching for images
  (optimised images are cached as immutable), CSS and JS, and basic security headers. CSS/JS links carry the file date, so
  updates show up straight away.
* On nginx, add: `location ~* \.(avif|webp|jpg|png|svg|css|js|woff2)$ { expires 1y; add_header Cache-Control "public, immutable"; }`,
  `gzip on; gzip_types text/css application/javascript image/svg+xml application/json;` and `types { image/avif avif; }`.
* Menus are cached for an hour (refreshed automatically when a bike type or trip type changes).
* Before going live run: `composer install --no-dev --optimize-autoloader`, `php artisan config:cache`,
  `php artisan route:cache`, `php artisan view:cache`, `php artisan storage:link`. Set `APP_ENV=production` and
  `APP_DEBUG=false`. After changing `.env` run `php artisan config:cache` again.

## Tour catalogue

`php artisan db:seed` (or `--class=CatalogueSeeder` on an existing site) imports 15 programmes from
`database/seeders/data/catalogue/*.json`, each in English, French, Spanish, Italian, German and Dutch.
Existing tours with the same slug are skipped, so admin edits are never overwritten.

Every catalogue tour has a short title and a descriptive **subtitle** (shown under the title, on the cards
and used as the Google description), in all six languages. If you imported the catalogue before this
change, run `php artisan migrate && php artisan db:seed --class=CatalogueTitlesSeeder` once to apply them.

Trip types (new **category** field, filter on the finder and home page):

| Trip type | Tours |
|---|---|
| Multi-day Atlas bike tours | 2-day Imlil · 3-day from Marrakech · 5-day private Amizmiz–Imlil · 6-day Atlas from Marrakech · 8-day Singletrack Week · Central Atlas Gravel (Bougmez–Imilchil) · Luxury 4★ Atlas Week |
| Atlas to Sahara bike tours | Bike & 4×4 Dadès to Merzouga · Luxury Atlas to Sahara via Saghro · Tessaout–Saghro–Draa expedition |
| Bike & ski touring | Toubkal ski + central Atlas MTB · Agafay to Tachdirt bike & ski |
| Desert & culture tours (no bike) | 4-day Marrakech–Merzouga · 8-day Casablanca–Chefchaouen · 8-day Casablanca–Fes–Marrakech |
| Day rides | the 10 demo day tours |

Tours without a bike (4×4 desert tours) leave **Bike type** empty in the admin. A price of **0** shows
“Price on request” and turns the booking form into a quote request.

**Please check before going live:** prices marked “on request” (2-day Imlil, 3-day MTB, Agafay–Tachdirt
bike & ski, both Casablanca tours); the 4-day desert tour was priced in US dollars ($330) and is entered as 330
in the site currency; map routes are approximate (redraw them in Admin → Tours → Location and route); add photos.

## Install (Laravel 11 or 12, PHP 8.2+)

```bash
composer create-project laravel/laravel moroccocyclingtours
cd moroccocyclingtours

# copy everything from this package into the project root (overwrite when asked)
cp -R /path/to/morocco-cycling-tours/* .

php artisan migrate --seed      # tables, bike types, 25 tours, pages, FAQs, sites, blog, admin user
php artisan storage:link        # makes uploaded tour photos public
php artisan serve
```

Open http://127.0.0.1:8000 (or /fr, /es, /it, /de, /nl) for the site and http://127.0.0.1:8000/admin for the admin.

### .env options

```
ADMIN_EMAIL=admin@moroccocyclingtours.com
ADMIN_PASSWORD=choose-a-strong-password     # set BEFORE running --seed
SITE_NAME="Morocco Cycling Tours"
SITE_EMAIL=hello@moroccocyclingtours.com
SITE_PHONE="+212 600 000 000"
SITE_WHATSAPP=212600000000
SITE_CURRENCY=€
SITE_HERO_IMAGE=img/hero.jpg               # optional photo behind the home hero (put it in /public/img)
```

If you seeded without setting a password, the default is `change-me-now` – change it right away.

## Files

```
app/Models/{Activity,Tour,Booking,User}.php
app/Http/Controllers/{Home,Tour,Booking}Controller.php
app/Http/Controllers/Admin/{Dashboard,Tour,Activity,Booking}Controller.php
app/Http/Controllers/Auth/LoginController.php
app/Http/Middleware/EnsureUserIsAdmin.php
app/Providers/AppServiceProvider.php     (shares bike types with the menu)
bootstrap/app.php                         (registers the "admin" middleware)
config/site.php
database/migrations/*  database/seeders/DatabaseSeeder.php
routes/web.php
resources/views/{home,tours/*,auth/login,layouts/*,components/*,admin/*}
public/css/{site,admin}.css  public/js/maps.js  public/img/*.svg
```

## Next steps you may want

* Photos: upload a main image and gallery for each tour in Admin → Tours (placeholders use the bike-type colour until then).
* E-mails: add a Mailable in `BookingController@store` (a comment marks the spot) to notify you and the guest.
* Payments / deposits: connect Stripe or CMI after a booking is confirmed.

---

## Update v16: gallery SEO, rental fleet, equipment rental, new home slider

**Install (copy the files over your project, then):**
```
php artisan migrate
php artisan db:seed --class=FleetSeeder
php artisan db:seed --class=GalleryEnrichSeeder
php artisan storage:link        # only if not done yet
php artisan view:cache          # checks every page template
```
Both seeders are safe to repeat and never overwrite text or photos you changed.

**Gallery**
- Admin → Gallery: every photo has bike type, caption, SEO title, alt text and description (6 languages). Bike types: Gravel, Cross-country, Road, E-bike, Enduro.
- 11 photos with identifiable guests (some young people) are imported **unpublished**, English text only. Publish them once you have permission and translate their text.
- Admin → Tours → edit → **Photos & equipment**: tick which photos belong to the tour (a photo can be on several tours).
- Tours without a cover photo received one. Road tours have only 2 photos, the Marrakech city tour none: upload more.
- /sitemap.xml now lists gallery and tour images with title and caption.

**Rentals (new admin group)**
- Rental bikes: Rockrider XC 100 S, Cube Stereo Hybrid 140 HPC ABS 750 (2023), Giant Talon E+ 2 (2023), Cube Cross Race (2023). Specifications come from manufacturer/retailer data for those model years; check them against your actual bikes. **Enter the price per day**, deposit and quantity (empty price shows "On request").
- Four catalogue pictures could not be identified (353100_light_zoom, 5371805, dx704_srs_n1, images.jfif): send the models.
- Equipment to rent: 17 items created **switched off at price 0**. Set a price and tick "Available to rent". Items with "Shown automatically on trip types" appear on every tour of that type (trekking items on Trekking tours); others can be ticked per tour.
- To add trekking tours: Admin → Tours → new tour → trip type "Trekking tours". The trip type only appears in menus once it has a published tour.
- Public page: /{lang}/bike-rental. Bookings store the rented equipment and total; see Admin → Bookings.

**Home slider**
- New design with route map overlay (coastlines only, pins = tour start points).
- Slides can play a short silent video (Admin → Hero slider → Looping video). Two clips were added after your existing slides; set a slide's Order to 0 to show it first. Visitors with reduced motion or data saver see the photo only.
- Gallery items can also hold a video (opens in the pop-up).

---

## Update v17: slider quality, mountain-trails map, videos for SEO, photos in blog posts

**Install (on top of v16):**
```
php artisan migrate                              # adds video length to gallery items
php artisan db:seed --class=GalleryEnrichSeeder  # two road videos, clips linked to tours, video lengths
php artisan db:seed --class=HeroQualitySeeder    # the ten slider photos replaced by high-quality versions
php artisan db:seed --class=BlogMediaSeeder      # photos and videos placed in the 12 articles
php artisan view:cache
```
- **Slider photos:** AVIF quality 68 / WebP 90, up to 2560 px wide, made from the original photos (about 0.5 MB at full size; phones get 480–1280 px versions). New slider uploads in the admin use the same high quality (`.env`: `SITE_AVIF_QUALITY_HERO`, `SITE_WEBP_QUALITY_HERO`, `SITE_IMAGE_MAX_WIDTH_HERO`).
- **Map:** centred mountain-trails map (contour rings around Toubkal, M'Goun, Ayyachi, Siroua, Saghro, Jbel Lekst; dashed trails; tour pins). Decorative, not a survey map.
- **Videos (SEO):** seven clips are linked to the tour pages they belong to ("Watch the ride" section with VideoObject structured data), listed in `/sitemap.xml` with `<video:video>` entries, and shown in the Gallery pop-up. Tip: write a sentence or two about the ride under each tour video; text next to a video helps it rank.
- **Blog:** each article got 3 photos/videos from the gallery. In the article text they are lines like `[[photo: gallery/xxx.webp]]`. You can move, delete or add such lines (any gallery photo's file path works; use the `[[note: …]]` form only for private reminders).
- **Images:** all pictures on the site are AVIF + WebP. Only the favicon (apple-touch-icon.png) and the social-share image (og-default.png) stay PNG on purpose, because Facebook, WhatsApp and Google do not read WebP/AVIF there.
- The 98-second street clip and the 0.25-second medina clip were not used. The medina still frame is in the gallery as an unpublished draft (recognisable local people).
