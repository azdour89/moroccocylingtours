<?php

return [
    'name'       => env('SITE_NAME', 'Morocco Cycling Tours'),
    'tagline'    => 'Guided bike adventures from the medina to the High Atlas',
    'email'      => env('SITE_EMAIL', 'hello@moroccocyclingtours.com'),
    'phone'      => env('SITE_PHONE', '+212 600 000 000'),
    'whatsapp'   => env('SITE_WHATSAPP', '212600000000'),
    'address'    => env('SITE_ADDRESS', 'Gueliz, Marrakech, Morocco'),
    // Site languages (first one is the fallback). Codes are used in URLs: /en, /fr, …
    'locales'    => [
        'en' => 'English',
        'fr' => 'Français',
        'es' => 'Español',
        'it' => 'Italiano',
        'de' => 'Deutsch',
        'nl' => 'Nederlands',
    ],
    'currency'   => env('SITE_CURRENCY', '€'),
    'currency_code' => env('SITE_CURRENCY_CODE', 'EUR'),

    // Image optimisation for admin uploads (see App\Support\Media)
    'image_formats'   => explode(',', env('SITE_IMAGE_FORMATS', 'avif,webp')),
    'image_max_width' => (int) env('SITE_IMAGE_MAX_WIDTH', 1920),
    'image_quality_hq' => ['avif' => (int) env('SITE_AVIF_QUALITY_HERO', 68), 'webp' => (int) env('SITE_WEBP_QUALITY_HERO', 90)],   // home slider photos
    'image_max_width_hq' => (int) env('SITE_IMAGE_MAX_WIDTH_HERO', 2560),
    'image_quality'   => ['avif' => (int) env('SITE_AVIF_QUALITY', 52), 'webp' => (int) env('SITE_WEBP_QUALITY', 80)],
    'avif_speed'      => (int) env('SITE_AVIF_SPEED', 6),          // 0 = smallest/slowest … 10 = fastest
    'avifenc_path'    => env('SITE_AVIFENC'),                      // optional full path to avifenc
    // schema.org format, e.g. "Mo-Sa 09:00-19:00"
    'opening_hours' => env('SITE_OPENING_HOURS', 'Mo-Sa 09:00-19:00'),
    // Optional full-bleed hero photo, e.g. "img/hero.jpg" placed in /public
    'hero_image' => env('SITE_HERO_IMAGE'),
];
